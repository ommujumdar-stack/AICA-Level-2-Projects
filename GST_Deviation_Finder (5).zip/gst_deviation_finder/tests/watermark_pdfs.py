"""Replica GSTR-3B PDFs with the watermark styles seen on downloaded / stamped returns."""
import io

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

GSTIN = "27AABCK4821M1ZD"
LINES = [
    "Form GSTR-3B", "Year 2025-26", "Period August", f"GSTIN of the supplier {GSTIN}",
    "3.1 Details of Outward supplies and inward supplies liable to reverse charge",
    "(a) Outward taxable supplies (other than zero rated, nil rated and exempted) 2,52,35,000.00 18,16,920.00 13,62,690.00 13,62,690.00 0.00",
    "(b) Outward taxable supplies (zero rated) 0.00 0.00 0.00",
    "(c) Other outward supplies (Nil rated, exempted) 4,80,000.00",
    "(d) Inward supplies (liable to reverse charge) 2,77,778.00 0.00 25,000.00 25,000.00 0.00",
    "(e) Non-GST outward supplies 0.00",
    "4. Eligible ITC", "(A) ITC Available (whether in full or part)",
    "(1) Import of goods 0.00 0.00 0.00 0.00", "(2) Import of services 0.00 0.00 0.00 0.00",
    "(3) Inward supplies liable to reverse charge (other than 1 & 2 above) 0.00 25,000.00 25,000.00 0.00",
    "(4) Inward supplies from ISD 0.00 0.00 0.00 0.00", "(5) All other ITC 14,88,182.40 9,28,883.00 9,28,883.00 0.00",
    "(B) ITC Reversed", "(1) As per rules 38,42 & 43 of CGST Rules and section 17(5) 0.00 0.00 0.00 0.00", "(2) Others 0.00 0.00 0.00 0.00",
]
EXPECTED = {
    "G3B_OUT_TXVAL": 2523500000, "G3B_OUT_IGST": 181692000, "G3B_OUT_CGST": 136269000, "G3B_OUT_SGST": 136269000,
    "G3B_RCM_CGST": 2500000, "G3B_ITC_AVL_IGST": 148818240, "G3B_ITC_AVL_CGST": 95388300, "G3B_EXEMPT": 48000000,
}


def _body(c):
    c.setFillColorRGB(0, 0, 0)
    y = 800
    for ln in LINES:
        c.setFont("Helvetica", 7)
        c.drawString(30, y, ln)
        y -= 14


def make(style: str, watermark_first: bool = False) -> bytes:
    bio = io.BytesIO()
    c = canvas.Canvas(bio, pagesize=A4)

    def wm():
        c.saveState()
        if style == "diagonal":            # classic grey rotated stamp
            c.setFillColorRGB(0.82, 0.82, 0.82)
            c.setFont("Helvetica-Bold", 60)
            for y in (300, 600):
                c.saveState(); c.translate(300, y); c.rotate(40); c.drawCentredString(0, 0, "DRAFT 2025-26"); c.restoreState()
        elif style == "transparent":       # black, 20% opacity, horizontal, over the table, contains digits
            c.setFillColorRGB(0, 0, 0)
            c.setFillAlpha(0.2)
            c.setFont("Helvetica-Bold", 7)
            for y in (730, 702, 576, 548):
                c.drawString(250, y + 1, "FILED 12,34,567.00 ARN AA2708250012345")
        elif style == "oversize":          # huge horizontal text, mid grey
            c.setFillColorRGB(0.5, 0.5, 0.5)
            c.setFont("Helvetica-Bold", 48)
            c.drawString(60, 700, "1,00,000.00 COPY")
        elif style == "image":             # raster stamp (logo / scanned seal) over the page
            from PIL import Image
            from reportlab.lib.utils import ImageReader
            img = Image.new("RGBA", (400, 160), (200, 30, 30, 70))
            c.drawImage(ImageReader(img), 150, 520, 300, 120, mask="auto")
        elif style == "disguised":         # opaque black, body font and size, horizontal: invisible to appearance rules
            c.setFillColorRGB(0, 0, 0)
            c.setFont("Helvetica", 7)
            c.drawString(262, 731, "9")
            c.drawString(355, 717, "7")
        elif style == "tiled":             # small light-grey horizontal text tiled everywhere
            c.setFillColorRGB(0.75, 0.75, 0.75)
            c.setFont("Helvetica", 7)
            for y in range(520, 820, 14):
                c.drawString(420, y + 3, f"Downloaded {GSTIN} 30-10-2026 99,999.00")
        c.restoreState()

    if style == "all":
        def wm():  # noqa: F811 - every detectable style at once
            for s in ("diagonal", "transparent", "oversize", "tiled", "image"):
                _draw(c, s)
    if watermark_first:
        wm(); _body(c)
    else:
        _body(c); wm()
    c.save()
    return bio.getvalue()


def _draw(c, style):
    """Draw one watermark style onto canvas c (used by the 'all' style)."""
    c.saveState()
    if style == "diagonal":
        c.setFillColorRGB(0.82, 0.82, 0.82); c.setFont("Helvetica-Bold", 60)
        for y in (300, 600):
            c.saveState(); c.translate(300, y); c.rotate(40); c.drawCentredString(0, 0, "DRAFT 2025-26"); c.restoreState()
    elif style == "transparent":
        c.setFillColorRGB(0, 0, 0); c.setFillAlpha(0.2); c.setFont("Helvetica-Bold", 7)
        for y in (730, 702, 576, 548):
            c.drawString(250, y + 1, "FILED 12,34,567.00 ARN AA2708250012345")
    elif style == "oversize":
        c.setFillColorRGB(0.5, 0.5, 0.5); c.setFont("Helvetica-Bold", 48); c.drawString(60, 700, "1,00,000.00 COPY")
    elif style == "tiled":
        c.setFillColorRGB(0.75, 0.75, 0.75); c.setFont("Helvetica", 7)
        for y in range(520, 820, 14):
            c.drawString(420, y + 3, f"Downloaded {GSTIN} 30-10-2026 99,999.00")
    elif style == "image":
        from PIL import Image
        from reportlab.lib.utils import ImageReader
        c.drawImage(ImageReader(Image.new("RGBA", (400, 160), (200, 30, 30, 70))), 150, 520, 300, 120, mask="auto")
    c.restoreState()


STYLES = ["diagonal", "transparent", "oversize", "tiled", "image", "all"]
