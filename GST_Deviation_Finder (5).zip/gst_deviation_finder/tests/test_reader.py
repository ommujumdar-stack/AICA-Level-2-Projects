"""Reader accuracy on hostile portal-style replicas: every figure the reader returns must be exactly right.
A figure it is unsure of may be left blank ("Type it") - that is allowed; a wrong figure is not.
Run:  python -m pytest -q tests/test_reader.py"""
import itertools
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from engine import finder as Fd  # noqa: E402
import portal_pdfs as P  # noqa: E402

WMS = list(P.WATERMARKS)
LAYOUTS = [dict(), dict(squeeze=0.8), dict(rules=False), dict(squeeze=0.85, rules=False)]


def cases():
    for wm, lay in itertools.product(WMS, LAYOUTS):
        yield f"3B-{wm}-{lay}", (lambda wm=wm, lay=lay: P.gstr3b(watermark=wm, **lay))
        yield f"1-{wm}-{lay}", (lambda wm=wm, lay=lay: P.gstr1(watermark=wm, **lay))
        yield f"9-{wm}-{lay}", (lambda wm=wm, lay=lay: P.gstr9(watermark=wm, f=P.G9_DEFAULT, **lay))
    for wm in ("all", "diagonal"):
        yield f"3B-short-{wm}", (lambda wm=wm: P.gstr3b(watermark=wm, short_header=True))
        yield f"3B-polluted-{wm}", (lambda wm=wm: P.gstr3b(watermark=wm, pollute=True))
        yield f"1-reordered-{wm}", (lambda wm=wm: P.gstr1(watermark=wm, reorder=True))


CASES = list(cases())
KIND = {"3B": "GSTR3B", "1-": "GSTR1", "9-": "GSTR9"}


@pytest.mark.parametrize("name,make", CASES, ids=[c[0] for c in CASES])
def test_no_wrong_figure(name, make):
    pdf, expected = make()
    f = Fd.read_pdf(pdf, name + ".pdf")
    assert f["type"] == KIND[name[:2]]
    wrong = {k: (v, expected.get(k)) for k, v in f["fields"].items() if k in expected and v != expected[k]}
    assert not wrong, wrong
    # most figures must actually be read, not left blank
    assert len([k for k in expected if k in f["fields"]]) >= 0.8 * len(expected)
