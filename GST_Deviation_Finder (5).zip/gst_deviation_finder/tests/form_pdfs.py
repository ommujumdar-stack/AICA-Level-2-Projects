"""Replica GSTR-9 and GSTR-1 PDFs laid out like the notified forms (column order as printed)."""
import io

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

GSTIN = "27AABCK4821M1ZD"


def _fmt(paise: int) -> str:
    """Indian grouping with 2 decimals, as the portal prints."""
    neg = paise < 0
    r, p = divmod(abs(paise), 100)
    s = str(r)
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts) + "," + tail
    return ("-" if neg else "") + f"{s}.{p:02d}"


# GSTR-9 figures in paise: row -> (value, central, state, integrated, cess) or (central, state, integrated, cess)
G9 = {
    "4N": (25_48_85_000_00, 9_90_120_00, 9_90_120_00, 3_08_53_375_00, 1_98_828_00),
    "5N": (25_55_46_300_00, 9_90_120_00, 9_90_120_00, 3_08_53_375_00, 1_98_828_00),
    "6A": (6_91_706_00, 6_91_706_00, 18_06_293_00, 2_02_944_00),
    "7I": (0, 0, 0, 0),
    "8A": (6_50_000_00, 6_50_000_00, 18_40_000_00, 2_02_944_00),
    "8B": (6_24_708_50, 6_24_708_50, 18_06_293_00, 2_02_944_00),
    "8C": (10_000_00, 10_000_00, 0, 0),
    "10": (2_00_000_00, 18_000_00, 18_000_00, 0, 0),
    "11": (50_000_00, 0, 0, 9_000_00, 0),
}
G9["8D"] = tuple(G9["8A"][i] - G9["8B"][i] - G9["8C"][i] for i in range(4))
# Table 9: head -> (payable, cash, ITC central, ITC state, ITC integrated, ITC cess)
T9 = {
    "IGST": (30_85_375_00, 12_79_082_00, 0, 0, 18_06_293_00, 0),
    "CGST": (6_60_128_00, 0, 6_60_128_00, 0, 0, 0),
    "SGST": (6_60_128_00, 0, 0, 6_60_128_00, 0, 0),
    "CESS": (1_98_828_00, 0, 0, 0, 0, 1_98_828_00),
}
LABEL = {"IGST": "Integrated Tax", "CGST": "Central Tax", "SGST": "State/UT Tax", "CESS": "Cess"}


def gstr9_pdf(blank_8c: bool = False, watermark: bool = False, break_8d: bool = False, fy: str = "2025-26") -> bytes:
    bio = io.BytesIO()
    c = canvas.Canvas(bio, pagesize=A4)
    y = [810]

    def ln(text, size=7):
        if y[0] < 40:
            c.showPage()
            y[0] = 810
        c.setFillColorRGB(0, 0, 0)
        c.setFont("Helvetica", size)
        c.drawString(25, y[0], text)
        y[0] -= 12

    def row(letter, label, key):
        vals = G9[key]
        if key == "8C" and blank_8c:
            ln(f"{letter} {label}")
            return
        if key == "8D" and break_8d:
            vals = (vals[0] + 5_000_00,) + vals[1:]
        ln(f"{letter} {label} " + " ".join(_fmt(v) for v in vals))

    ln("FORM GSTR-9 Annual Return", 10)
    ln(f"Financial Year {fy}")
    ln(f"GSTIN {GSTIN}")
    ln("Legal name of the registered person Kalpataru Precision Components Pvt Ltd")
    ln("Pt. II Details of Outward and inward supplies made during the financial year")
    ln("Nature of Supplies Taxable Value Central Tax State Tax / UT Tax Integrated Tax Cess")
    ln("4 Details of advances, inward and outward supplies made during the financial year on which tax is payable")
    ln("G Inward supplies on which tax is to be paid on reverse charge basis 2,77,778.00 25,000.00 25,000.00 0.00 0.00")
    ln("H Sub-total (A to G above) 25,18,85,000.00 9,40,120.00 9,40,120.00 3,08,53,375.00 1,98,828.00")
    row("N", "Supplies and advances on which tax is to be paid (H + M) above", "4N")
    ln("5 Details of Outward supplies made during the financial year on which tax is not payable")
    row("N", "Total Turnover (including advances) (4N + 5M - 4G above)", "5N")
    ln("Pt. III Details of ITC for the financial year")
    ln("Description Type Central Tax State Tax / UT Tax Integrated Tax Cess")
    row("A", "Total amount of input tax credit availed through FORM GSTR-3B (sum total of Table 4A of FORM GSTR-3B)", "6A")
    ln("B Inward supplies (other than imports and inward supplies liable to reverse charge but includes services received from SEZs) Inputs 5,90,000.00 5,90,000.00 12,00,000.00 2,02,944.00")
    row("I", "Total ITC Reversed (Sum of A to H above)", "7I")
    ln("8 Other ITC related information")
    row("A", "ITC as per GSTR-2B (Table 3 & 5 thereof)", "8A")
    row("B", "ITC as per sum total of 6(B) and 6(H) above", "8B")
    row("C", "ITC on inward supplies (other than imports and inward supplies liable to reverse charge but includes services received from SEZs) received during 2025-26 but availed during April 2026 to October 2026", "8C")
    row("D", "Difference [A-(B+C)]", "8D")
    ln("E ITC available but not availed 0.00 0.00 0.00 0.00")
    ln("Pt. IV Details of tax paid as declared in returns filed during the financial year")
    ln("9 Details of tax paid as declared in returns filed during the financial year")
    ln("Description Tax Payable Paid through cash Paid through ITC Central Tax State Tax / UT Tax Integrated Tax Cess")
    for h in ("IGST", "CGST", "SGST", "CESS"):
        c.setFont("Helvetica", 7)
        ln(f"{LABEL[h]} " + " ".join(_fmt(v) for v in T9[h]))
    ln("Interest 0.00 0.00")
    ln("Late fee 0.00 0.00")
    ln("Pt. V Particulars of the transactions for the previous FY declared in returns of April to September of current FY")
    ln("Description Taxable Value Central Tax State Tax / UT Tax Integrated Tax Cess")
    ln("10 Supplies / tax declared through Amendments (+) (net of debit notes) " + " ".join(_fmt(v) for v in G9["10"]))
    ln("11 Supplies / tax reduced through Amendments (-) (net of credit notes) " + " ".join(_fmt(v) for v in G9["11"]))
    ln("12 Reversal of ITC availed during previous financial year 0.00 0.00 0.00 0.00")
    if watermark:
        c.saveState()
        c.setFillColorRGB(0.82, 0.82, 0.82)
        c.setFont("Helvetica-Bold", 54)
        c.translate(300, 450)
        c.rotate(35)
        c.drawCentredString(0, 0, "SYSTEM COMPUTED 2025-26")
        c.restoreState()
    c.save()
    return bio.getvalue()


# GSTR-1 summary: Value, Integrated, Central, State/UT, Cess (IGST first)
G1_TOTAL = (2_52_35_000_00, 18_16_920_00, 13_62_690_00, 13_62_690_00, 0)


def gstr1_pdf(watermark: bool = False, month: str = "August") -> bytes:
    bio = io.BytesIO()
    c = canvas.Canvas(bio, pagesize=A4)
    y = 800
    lines = [
        "FORM GSTR-1 Details of outward supplies of goods or services",
        "Financial Year 2025-26", f"Tax Period {month}", f"GSTIN {GSTIN}",
        "Description No. of records Document Type Value Integrated Tax Central Tax State/UT Tax Cess",
        "4A - Taxable outward supplies made to registered persons 41 Invoice 1,92,10,000.00 7,55,820.00 13,62,690.00 13,62,690.00 0.00",
        "5 - Taxable outward inter-state supplies to un-registered persons 6 Invoice 60,25,000.00 10,61,100.00 0.00 0.00 0.00",
        "9B - Credit / Debit Notes (Registered) 0 Note 0.00 0.00 0.00 0.00 0.00",
        "Total Liability (Outward supplies other than Reverse charge) " + " ".join(_fmt(v) for v in G1_TOTAL),
    ]
    for ln in lines:
        c.setFont("Helvetica", 7)
        c.drawString(25, y, ln)
        y -= 14
    if watermark:
        c.saveState()
        c.setFillColorRGB(0, 0, 0)
        c.setFillAlpha(0.18)
        c.setFont("Helvetica-Bold", 7)
        c.drawString(230, y + 15, "FILED 99,99,999.00 ARN AA270825001")
        c.restoreState()
    c.save()
    return bio.getvalue()
