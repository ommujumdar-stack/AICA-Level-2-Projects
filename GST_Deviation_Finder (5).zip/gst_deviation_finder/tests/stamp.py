"""Overlay extra watermarks (diagonal, transparent numbers, tiled grey, giant digit) on any PDF."""
import io, sys, random
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.lib.colors import Color

def stamp(data, kind):
    rd = PdfReader(io.BytesIO(data)); wr = PdfWriter()
    for i, pg in enumerate(rd.pages):
        w, h = float(pg.mediabox.width), float(pg.mediabox.height)
        b = io.BytesIO(); c = canvas.Canvas(b, pagesize=(w, h))
        random.seed(i)
        if kind in ("diagonal", "all"):
            c.saveState(); c.setFillColor(Color(0.75, 0.75, 0.75)); c.setFont("Helvetica-Bold", 70)
            c.translate(w / 2, h / 2); c.rotate(35); c.drawCentredString(0, 0, "CONFIDENTIAL 99,99,999.00"); c.restoreState()
        if kind in ("transparent", "all"):
            c.setFillColor(Color(0, 0, 0, alpha=0.25)); c.setFont("Helvetica", 9)
            for k in range(12):
                c.drawString(random.uniform(300, 780), random.uniform(40, h - 40), f"{random.randint(1,99)},{random.randint(10,99)},{random.randint(100,999)}.00")
        if kind in ("tiled", "all"):
            c.setFillColor(Color(0.85, 0.85, 0.85)); c.setFont("Helvetica", 8)
            for y in range(30, int(h), 60):
                c.drawString(20, y, ("Downloaded 27AAAAA0000A1Z5 12,34,567.00   ") * 4)
        if kind in ("big", "all"):
            c.setFillColor(Color(0, 0, 0)); c.setFont("Helvetica-Bold", 240); c.drawString(300, 150, "8")
        c.save()
        ov = PdfReader(io.BytesIO(b.getvalue())).pages[0]
        pg.merge_page(ov); wr.add_page(pg)
    o = io.BytesIO(); wr.write(o); return o.getvalue()

