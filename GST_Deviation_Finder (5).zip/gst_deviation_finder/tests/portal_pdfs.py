"""Portal-style replicas: ruled tables, labels wrapped inside narrow cells, column headings, several pages,
and hostile watermarks. Figures in paise. Used to prove the reader before real PDFs are available."""
import io

from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import simpleSplit
from reportlab.pdfgen import canvas

GSTIN = "27AAFCS4417K1Z5"
W, H = A4


def fmt(p):
    neg = p < 0
    r, ps = divmod(abs(int(p)), 100)
    s = str(r)
    if len(s) > 3:
        head, tail, parts = s[:-3], s[-3:], []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts) + "," + tail
    return ("-" if neg else "") + f"{s}.{ps:02d}"


class Doc:
    def __init__(self, squeeze=1.0, rules=True):
        self.squeeze, self.rules = squeeze, rules
        self.bio = io.BytesIO()
        self.c = canvas.Canvas(self.bio, pagesize=A4)
        self.y = H - 40
        self.marks = []

    def need(self, h):
        if self.y - h < 50:
            self.page()

    def page(self):
        for wm in self.marks:
            wm(self.c)
        self.c.showPage()
        self.y = H - 40

    def text(self, s, size=8, bold=False, dy=12):
        self.need(dy)
        self.c.setFillColorRGB(0, 0, 0)
        self.c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
        self.c.drawString(30, self.y, s)
        self.y -= dy

    def table(self, header, rows, widths, size=6.6):
        """header: list of str; rows: list of lists (first cell = label, may wrap). Draws cell borders."""
        x0 = 30
        lead = size + 1.6
        if self.squeeze != 1.0:
            extra = widths[0] * (1 - self.squeeze)
            widths = [widths[0] * self.squeeze] + [w + extra / (len(widths) - 1) for w in widths[1:]]

        def row_h(cells):
            n = max(len(simpleSplit(str(t), "Helvetica", size, w - 6)) or 1 for t, w in zip(cells, widths))
            return n * lead + 6

        def draw(cells, bold=False):
            h = row_h(cells)
            self.need(h)
            x = x0
            self.c.setLineWidth(0.4)
            self.c.setStrokeColorRGB(0.55, 0.55, 0.55)
            for t, w in zip(cells, widths):
                if self.rules:
                    self.c.rect(x, self.y - h, w, h)
                lines = simpleSplit(str(t), "Helvetica", size, w - 6)
                self.c.setFillColorRGB(0, 0, 0)
                self.c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
                num = bool(lines) and lines[0].replace(",", "").replace(".", "").replace("-", "").isdigit()
                for k, ln in enumerate(lines):
                    yy = self.y - 3 - size - k * lead
                    if num:
                        self.c.drawRightString(x + w - 3, yy, ln)
                    else:
                        self.c.drawString(x + 3, yy, ln)
                x += w
            self.y -= h

        draw(header, bold=True)
        for r in rows:
            draw(r)
        self.y -= 8

    def save(self):
        for wm in self.marks:
            wm(self.c)
        self.c.save()
        return self.bio.getvalue()


# ------------------------------------------------------------------ watermarks
def wm_diagonal(c):
    c.saveState(); c.setFillColorRGB(0.85, 0.85, 0.85); c.setFont("Helvetica-Bold", 64)
    c.translate(W / 2, H / 2); c.rotate(42); c.drawCentredString(0, 0, "FILED RETURN"); c.restoreState()


def wm_transparent_numbers(c):
    c.saveState(); c.setFillColorRGB(0, 0, 0); c.setFillAlpha(0.15); c.setFont("Helvetica", 6.6)
    for y in range(120, int(H) - 60, 26):
        c.drawString(200, y, "ARN AA270825012345 dated 20-09-2025 Rs 9,99,999.00")
    c.restoreState()


def wm_image(c):
    from PIL import Image
    from reportlab.lib.utils import ImageReader
    img = Image.new("RGBA", (500, 200), (30, 60, 160, 60))
    c.drawImage(ImageReader(img), 120, 300, 360, 150, mask="auto")


def wm_vector(c):
    """Watermark drawn as outlines (no text): what many 'print to PDF' stamps produce."""
    c.saveState(); c.setStrokeColorRGB(0.8, 0.8, 0.8); c.setLineWidth(3)
    p = c.beginPath()
    for k in range(6):
        p.moveTo(100 + k * 70, 250); p.lineTo(130 + k * 70, 420); p.lineTo(160 + k * 70, 250)
    c.drawPath(p, stroke=1, fill=0); c.restoreState()


def wm_tiled_grey(c):
    c.saveState(); c.setFillColorRGB(0.72, 0.72, 0.72); c.setFont("Helvetica", 6.6)
    for y in range(80, int(H) - 40, 18):
        for x in (40, 300):
            c.drawString(x, y, f"Downloaded {GSTIN} 01-11-2026 12,34,567.00")
    c.restoreState()


def wm_same_style_margin(c):
    """Opaque black, body size, upright - indistinguishable by appearance; sits in the margin (outside tables)."""
    c.saveState(); c.setFillColorRGB(0, 0, 0); c.setFont("Helvetica", 6.6)
    c.drawString(30, 22, "System generated copy - 4,56,789.00 - page footer")
    c.drawString(450, H - 20, "COPY 1,00,000.00")
    c.restoreState()


WATERMARKS = {"none": [], "diagonal": [wm_diagonal], "transparent": [wm_transparent_numbers], "image": [wm_image],
              "vector": [wm_vector], "tiled": [wm_tiled_grey], "margin": [wm_same_style_margin],
              "all": [wm_diagonal, wm_transparent_numbers, wm_image, wm_vector, wm_tiled_grey, wm_same_style_margin]}

# ------------------------------------------------------------------ GSTR-3B
B3_DEFAULT = dict(out=(2_52_35_000_00, 18_16_920_00, 13_62_690_00, 13_62_690_00, 0), zero=(0, 0, 0), exempt=4_80_000_00,
                  rcm=(2_77_778_00, 0, 25_000_00, 25_000_00, 0), nongst=0,
                  itc={"imp_goods": (2_10_000_00, 0, 0, 0), "imp_serv": (0, 0, 0, 0), "rcm": (0, 25_000_00, 25_000_00, 0),
                       "isd": (0, 0, 0, 0), "other": (12_78_182_40, 9_03_883_00, 9_03_883_00, 0)},
                  rev={"r42": (0, 12_000_00, 12_000_00, 0), "oth": (0, 0, 0, 0)},
                  paid_cash=(4_50_000_00, 3_10_000_00, 3_10_000_00, 0))


def gstr3b(month="August", fy="2025-26", watermark="none", v=None, short_header=False, squeeze=1.0, rules=True, pollute=False):
    v = {**B3_DEFAULT, **(v or {})}
    d = Doc(squeeze, rules)
    d.marks = WATERMARKS[watermark]
    d.text("Form GSTR-3B", 11, True, 16)
    d.text("[See rule 61(5)]", 7)
    d.text(f"Year {fy}          Period {month}", 8)
    d.text(f"1. GSTIN of the supplier   {GSTIN}", 8)
    d.text("2(a). Legal name of the registered person   Sahyadri Trading Co Pvt Ltd", 8)
    d.text("2(d). ARN   AA270925123456          Date of ARN   20/09/2025", 8, dy=18)
    d.text("3.1 Details of Outward supplies and inward supplies liable to reverse charge (other than those covered by Table 3.1.1)", 8, True)
    hdr = (["Nature of Supplies", "Total taxable value", "Integrated tax", "Central tax", "State/UT tax", "Cess"]
           if not short_header else ["Nature of Supplies", "Taxable value", "IGST", "CGST", "SGST/UTGST", "Cess"])
    w = [170, 75, 75, 70, 70, 60]
    o, z, r = v["out"], v["zero"], v["rcm"]
    d.table(hdr, [
        ["(a) Outward taxable supplies (other than zero rated, nil rated and exempted)", fmt(o[0]),
         (fmt(o[1]) + " COPY") if pollute else fmt(o[1]), fmt(o[2]), fmt(o[3]), fmt(o[4])],
        ["(b) Outward taxable supplies (zero rated)", fmt(z[0]), fmt(z[1]), "-", "-", fmt(z[2])],
        ["(c) Other outward supplies (Nil rated, exempted)", fmt(v["exempt"]), "-", "-", "-", "-"],
        ["(d) Inward supplies (liable to reverse charge)", fmt(r[0]), fmt(r[1]), fmt(r[2]), fmt(r[3]), fmt(r[4])],
        ["(e) Non-GST outward supplies", fmt(v["nongst"]), "-", "-", "-", "-"],
    ], w)
    d.text("3.2 Of the supplies shown in 3.1 (a) above, details of inter-State supplies made", 8, True)
    d.table(["Nature of Supplies", "Place of Supply (State/UT)", "Total taxable value", "Amount of Integrated tax"],
            [["Supplies made to Unregistered Persons", "29-Karnataka", fmt(40_00_000_00), fmt(7_20_000_00)]], [170, 120, 115, 115])
    d.text("4. Eligible ITC", 8, True)
    it, rv = v["itc"], v["rev"]
    a = [sum(it[k][i] for k in it) for i in range(4)]
    b = [sum(rv[k][i] for k in rv) for i in range(4)]
    cnet = [a[i] - b[i] for i in range(4)]
    w4 = [220, 80, 80, 80, 60]
    d.table(["Details", "Integrated tax", "Central tax", "State/UT tax", "Cess"], [
        ["A. ITC Available (whether in full or part)", "", "", "", ""],
        ["(1) Import of goods"] + [fmt(x) for x in it["imp_goods"]],
        ["(2) Import of services"] + [fmt(x) for x in it["imp_serv"]],
        ["(3) Inward supplies liable to reverse charge (other than 1 & 2 above)"] + [fmt(x) for x in it["rcm"]],
        ["(4) Inward supplies from ISD"] + [fmt(x) for x in it["isd"]],
        ["(5) All other ITC"] + [fmt(x) for x in it["other"]],
        ["B. ITC Reversed", "", "", "", ""],
        ["(1) As per rules 38,42 & 43 of CGST Rules and section 17(5)"] + [fmt(x) for x in rv["r42"]],
        ["(2) Others"] + [fmt(x) for x in rv["oth"]],
        ["C. Net ITC Available (A) - (B)"] + [fmt(x) for x in cnet],
        ["D. Other Details", "", "", "", ""],
        ["(1) ITC reclaimed which was reversed under Table 4(B)(2) in earlier tax period"] + [fmt(0)] * 4,
    ], w4)
    d.text("5. Values of exempt, nil-rated and non-GST inward supplies", 8, True)
    d.table(["Nature of supplies", "Inter-State supplies", "Intra-State supplies"],
            [["From a supplier under composition scheme, Exempt and Nil rated supply", fmt(0), fmt(1_20_000_00)]], [260, 120, 120])
    d.text("6.1 Payment of tax", 8, True)
    pc = v["paid_cash"]
    d.table(["Description", "Total tax payable", "Tax paid through ITC", "Tax paid in cash", "Interest", "Late fee"], [
        ["Integrated Tax", fmt(o[1] + r[1]), fmt(o[1] + r[1] - pc[0]), fmt(pc[0]), fmt(0), fmt(0)],
        ["Central Tax", fmt(o[2] + r[2]), fmt(o[2] + r[2] - pc[1]), fmt(pc[1]), fmt(0), fmt(0)],
        ["State/UT Tax", fmt(o[3] + r[3]), fmt(o[3] + r[3] - pc[2]), fmt(pc[2]), fmt(0), fmt(0)],
        ["Cess", fmt(o[4] + r[4]), fmt(0), fmt(o[4] + r[4]), fmt(0), fmt(0)],
    ], [130, 85, 85, 85, 70, 65])
    d.text("Verification: I hereby solemnly affirm and declare that the information given herein above is true and correct.", 7)
    exp = {"G3B_OUT_TXVAL": o[0] + z[0], "G3B_OUT_IGST": o[1] + z[1], "G3B_OUT_CGST": o[2], "G3B_OUT_SGST": o[3], "G3B_OUT_CESS": o[4] + z[2],
           "G3B_EXEMPT": v["exempt"] + v["nongst"]}
    for i, h in enumerate(["IGST", "CGST", "SGST", "CESS"]):
        exp[f"G3B_RCM_{h}"] = r[1 + i]
        exp[f"G3B_ITC_AVL_{h}"] = a[i]
        exp[f"G3B_ITC_REV_{h}"] = b[i]
    return d.save(), exp


# ------------------------------------------------------------------ GSTR-1
def gstr1(month="August", fy="2025-26", watermark="none", total=(2_52_35_000_00, 18_16_920_00, 13_62_690_00, 13_62_690_00, 0),
          squeeze=1.0, rules=True, reorder=False):
    d = Doc(squeeze, rules)
    d.marks = WATERMARKS[watermark]
    d.text("FORM GSTR-1", 11, True, 16)
    d.text("[See rule 59(1)]  Details of outward supplies of goods or services", 7)
    d.text(f"Financial Year {fy}          Tax Period {month}", 8)
    d.text(f"1. GSTIN   {GSTIN}", 8)
    d.text("2(a). Legal name of the registered person   Sahyadri Trading Co Pvt Ltd", 8, dy=18)
    w = [190, 50, 60, 75, 70, 65, 65, 50]
    hdr = ["Description", "No. of records", "Document type", "Taxable value", "Integrated tax", "Central tax", "State/UT tax", "Cess"]
    b2b = (total[0] - 60_25_000_00, total[1] - 10_61_100_00, total[2], total[3], total[4])
    rows = [
        ["4A - Taxable outward supplies made to registered persons (other than reverse charge supplies)", "41", "Invoice"] + [fmt(x) for x in b2b],
        ["5 - Taxable outward inter-state supplies to un-registered persons where invoice value is more than Rs 1 lakh", "6", "Invoice",
         fmt(60_25_000_00), fmt(10_61_100_00), fmt(0), fmt(0), fmt(0)],
        ["7 - Taxable supplies (Net of debit/credit notes) to unregistered persons other than the supplies covered in Table 5", "0", "Net value"] + [fmt(0)] * 5,
        ["9B - Credit / Debit Notes (Registered)", "0", "Note"] + [fmt(0)] * 5,
        ["12 - HSN-wise summary of outward supplies", "14", "-", fmt(total[0]), fmt(total[1]), fmt(total[2]), fmt(total[3]), fmt(total[4])],
        ["13 - Documents issued", "47", "-", "-", "-", "-", "-", "-"],
        ["Total Liability (Outward supplies other than Reverse charge)", "", ""] + [fmt(x) for x in total],
    ]
    if reorder:   # columns printed in a different order: Central, State, Integrated
        idx = [0, 1, 2, 3, 5, 6, 4, 7]
        hdr = [hdr[i] for i in idx]
        rows = [[r[i] for i in idx] for r in rows]
    d.table(hdr, rows, w)
    return d.save(), dict(zip(["G1_TXVAL", "G1_IGST", "G1_CGST", "G1_SGST", "G1_CESS"], total))


# ------------------------------------------------------------------ GSTR-9 (several pages, wrapped labels)
def gstr9(fy="2025-26", watermark="none", f=None, squeeze=1.0, rules=True):
    """f: dict row -> tuple. 4/5/10/11 = (value, central, state, integrated, cess); 6A/7I/8A-8D = (central, state, integrated, cess);
    T9 head -> (payable, cash, itc central, itc state, itc integrated, itc cess)."""
    f = f or {}
    d = Doc(squeeze, rules)
    d.marks = WATERMARKS[watermark]
    d.text("FORM GSTR-9", 11, True, 16)
    d.text("(See rule 80)  Annual Return", 7)
    d.text(f"Pt. I Basic Details     1 Financial Year {fy}", 8)
    d.text(f"2 GSTIN   {GSTIN}", 8)
    d.text("3A Legal Name   Sahyadri Trading Co Pvt Ltd", 8, dy=18)
    d.text("Pt. II Details of Outward and inward supplies made during the financial year", 8, True)
    w5 = [200, 75, 70, 70, 75, 50]
    h5 = ["Nature of Supplies", "Taxable Value", "Central Tax", "State Tax / UT Tax", "Integrated Tax", "Cess"]
    F = lambda k: [fmt(x) for x in f[k]]  # noqa: E731
    cat = f.get("cat") or {"4A": (40_00_000_00, 0, 0, 7_20_000_00, 0), "4G": (33_33_336_00, 3_00_000_00, 3_00_000_00, 0, 0),
                           "5D": (57_60_000_00,)}
    rows4 = [["4 Details of advances, inward and outward supplies made during the financial year on which tax is payable", "", "", "", "", ""]]
    for k, lab in G9_T4_LABELS:
        if k in cat:
            rows4.append([lab] + [fmt(x) for x in cat[k]])
        elif k == "H":
            rows4.append(["H Sub-total (A to G above)", "", "", "", "", ""])
    rows4.append(["N Supplies and advances on which tax is to be paid (H + M) above"] + F("4N"))
    rows4.append(["5 Details of Outward supplies made during the financial year on which tax is not payable", "", "", "", "", ""])
    for k, lab in G9_T5_LABELS:
        if k in cat:
            rows4.append([lab, fmt(cat[k][0]), "", "", "", ""])
    rows4.append(["N Total Turnover (including advances) (4N + 5M - 4G above)"] + F("5N"))
    d.table(h5, rows4, w5)
    d.text("Pt. III Details of ITC for the financial year", 8, True)
    w6 = [235, 60, 70, 70, 70, 45]
    d.table(["Description", "Type", "Central Tax", "State Tax / UT Tax", "Integrated Tax", "Cess"], [
        ["A Total amount of input tax credit availed through FORM GSTR-3B (sum total of Table 4A of FORM GSTR-3B)", ""] + F("6A"),
        ["B Inward supplies (other than imports and inward supplies liable to reverse charge but includes services received from SEZs)",
         "Inputs"] + [fmt(x) for x in (9_00_00_000, 9_00_00_000, 15_00_00_000, 0)],
        ["7 Details of ITC Reversed and Ineligible ITC for the financial year", "", "", "", "", ""],
        ["I Total ITC Reversed (Sum of A to H above)", ""] + F("7I"),
        ["8 Other ITC related information", "", "", "", "", ""],
        ["A ITC as per GSTR-2B (Table 3 & 5 thereof)", ""] + F("8A"),
        ["B ITC as per sum total of 6(B) and 6(H) above", ""] + F("8B"),
        ["C ITC on inward supplies (other than imports and inward supplies liable to reverse charge but includes services received from SEZs) "
         f"received during {fy} but availed during April {int(fy[:4]) + 1} to October {int(fy[:4]) + 1}", ""] + F("8C"),
        ["D Difference [A-(B+C)]", ""] + F("8D"),
        ["E ITC available but not availed", ""] + [fmt(0)] * 4,
    ], w6)
    d.text("Pt. IV Details of tax paid as declared in returns filed during the financial year", 8, True)
    d.text("9 Details of tax paid as declared in returns filed during the financial year", 8)
    t9 = f["T9"]
    lab = {"IGST": "Integrated Tax", "CGST": "Central Tax", "SGST": "State/UT Tax", "CESS": "Cess"}
    d.table(["Description", "Tax Payable", "Paid through cash", "Paid through ITC Central Tax", "Paid through ITC State Tax / UT Tax",
             "Paid through ITC Integrated Tax", "Paid through ITC Cess"],
            [[lab[h]] + [fmt(x) for x in t9[h]] for h in ("IGST", "CGST", "SGST", "CESS")]
            + [["Interest", fmt(0), fmt(0), "", "", "", ""], ["Late fee", fmt(0), fmt(0), "", "", "", ""]],
            [90, 72, 72, 72, 72, 72, 62])
    d.text("Pt. V Particulars of the transactions for the previous FY declared in returns of April to September of current FY", 8, True)
    d.table(h5, [
        ["10 Supplies / tax declared through Amendments (+) (net of debit notes)"] + F("10"),
        ["11 Supplies / tax reduced through Amendments (-) (net of credit notes)"] + F("11"),
        ["12 Reversal of ITC availed during previous financial year", "", fmt(0), fmt(0), fmt(0), fmt(0)],
    ], w5)
    d.text("Pt. VI Other Information", 8, True)
    d.text("17 HSN Wise Summary of outward supplies - details not reproduced in this replica", 7)
    exp = {}
    for k, v in cat.items():
        for c, x in zip(["TXVAL", "CGST", "SGST", "IGST", "CESS"], v):
            exp[f"G9FILED_{k}_{c}"] = x
    for row in ("4N", "5N", "10", "11"):
        for c, x in zip(["TXVAL", "CGST", "SGST", "IGST", "CESS"], f[row]):
            exp[f"G9FILED_{row}_{c}"] = x
    for row in ("6A", "7I", "8A", "8B", "8C", "8D"):
        for c, x in zip(["CGST", "SGST", "IGST", "CESS"], f[row]):
            exp[f"G9FILED_{row}_{c}"] = x
    for h in ("IGST", "CGST", "SGST", "CESS"):
        exp[f"G9FILED_9P_{h}"] = t9[h][0]
        exp[f"G9FILED_9D_{h}"] = sum(t9[h][1:])
    return d.save(), exp


G9_T4_LABELS = [
    ("4A", "A Supplies made to un-registered persons (B2C)"), ("4B", "B Supplies made to registered persons (B2B)"),
    ("4C", "C Zero rated supply (Export) on payment of tax (except supplies to SEZs)"), ("4D", "D Supply to SEZs on payment of tax"),
    ("4E", "E Deemed Exports"), ("4F", "F Advances on which tax has been paid but invoice has not been issued (not covered under (A) to (E) above)"),
    ("4G", "G Inward supplies on which tax is to be paid on reverse charge basis"), ("H", ""),
    ("4I", "I Credit Notes issued in respect of transactions specified in (B) to (E) above (-)"),
    ("4J", "J Debit Notes issued in respect of transactions specified in (B) to (E) above (+)"),
    ("4K", "K Supplies / tax declared through Amendments (+)"), ("4L", "L Supplies / tax reduced through Amendments (-)"),
]
G9_T5_LABELS = [
    ("5A", "A Zero rated supply (Export) without payment of tax"), ("5B", "B Supply to SEZs without payment of tax"),
    ("5C", "C Supplies on which tax is to be paid by the recipient on reverse charge basis"), ("5D", "D Exempted"), ("5E", "E Nil Rated"),
    ("5F", "F Non-GST supply (includes 'no supply')"), ("5H", "H Credit Notes issued in respect of transactions specified in A to F above (-)"),
    ("5I", "I Debit Notes issued in respect of transactions specified in A to F above (+)"),
    ("5J", "J Supplies declared through Amendments (+)"), ("5K", "K Supplies reduced through Amendments (-)"),
]

G9_DEFAULT = {
    "4N": (25_48_85_000_00, 9_90_120_00, 9_90_120_00, 3_08_53_375_00, 1_98_828_00),
    "5N": (26_06_45_000_00, 9_90_120_00, 9_90_120_00, 3_08_53_375_00, 1_98_828_00),
    "6A": (1_08_00_000_00, 1_08_00_000_00, 1_80_00_000_00, 0),
    "7I": (1_44_000_00, 1_44_000_00, 0, 0),
    "8A": (1_06_80_000_00, 1_06_80_000_00, 1_52_00_000_00, 0),
    "8B": (1_05_00_000_00, 1_05_00_000_00, 1_52_00_000_00, 0),
    "8C": (30_000_00, 30_000_00, 0, 0),
    "10": (2_00_000_00, 18_000_00, 18_000_00, 0, 0),
    "11": (50_000_00, 0, 0, 9_000_00, 0),
    "T9": {"IGST": (3_08_53_375_00, 1_28_53_375_00, 0, 0, 1_80_00_000_00, 0), "CGST": (9_90_120_00, 0, 9_90_120_00, 0, 0, 0),
           "SGST": (9_90_120_00, 0, 0, 9_90_120_00, 0, 0), "CESS": (1_98_828_00, 0, 0, 0, 0, 1_98_828_00)},
}
G9_DEFAULT["8D"] = tuple(G9_DEFAULT["8A"][i] - G9_DEFAULT["8B"][i] - G9_DEFAULT["8C"][i] for i in range(4))
