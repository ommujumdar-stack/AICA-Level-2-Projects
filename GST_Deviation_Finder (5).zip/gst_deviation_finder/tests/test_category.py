"""GSTR-1 category-wise (12 portal-layout GSTR-1s) vs GSTR-9 Table 4 / 5 category-wise."""
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from engine import category as CT  # noqa: E402
from engine import finder as Fd  # noqa: E402
import g1_portal_pdfs as GP  # noqa: E402
import portal_pdfs as P  # noqa: E402

MONTHS = ["April", "May", "June", "July", "August", "September", "October", "November", "December", "January", "February", "March"]
FY = "2024-25"


def _sum(exps, key, head):
    return sum((e["tables"][key].get(head) or 0) for e in exps)


def build(folder=None):
    """12 portal-layout GSTR-1 + a GSTR-9 with planted category differences. Writes the PDFs to folder if given."""
    files, exps = [], []
    for i, m in enumerate(MONTHS):
        pdf, exp = GP.gstr1(seed=10 + i, month=m, fy=FY, gstin=P.GSTIN)
        if folder:
            open(os.path.join(folder, f"GSTR1_{m}_{FY}.pdf"), "wb").write(pdf)
        files.append(Fd.read_pdf(pdf, f"GSTR1_{m}.pdf"))
        exps.append(exp)
    S = lambda k, h: _sum(exps, k, h)  # noqa: E731
    t4 = lambda keys, signs=None: tuple(sum((signs or [1] * len(keys))[j] * S(k, h) for j, k in enumerate(keys))  # noqa: E731
                                        for h in ("VALUE", "CGST", "SGST", "IGST", "CESS"))
    cat = {
        "4A": t4(["5", "7", "10"]), "4B": t4(["4A"]), "4C": t4(["6A"]), "4D": t4(["6B"]), "4E": t4(["6C"]),
        "4F": t4(["11A", "11B"], [1, -1]),
        "4I": tuple(-x for x in t4(["9B_CDNR", "9B_CDNUR"])), "4J": (0, 0, 0, 0, 0),
        "4K": t4(["9A_B2B"]), "4L": (0, 0, 0, 0, 0),
        "5A": (0,), "5B": (0,), "5C": (S("4B", "VALUE"),), "5D": (0,), "5E": (S("8", "VALUE"),), "5F": (0,),
    }
    # planted: 1,00,000 + tax moved from B2B (4B) to B2C (4A); 50,000 more nil-rated in 5E
    b = list(cat["4B"]); a = list(cat["4A"])
    b[0] -= 1_00_000_00; b[1] -= 9_000_00; b[2] -= 9_000_00
    a[0] += 1_00_000_00; a[1] += 9_000_00; a[2] += 9_000_00
    cat["4B"], cat["4A"] = tuple(b), tuple(a)
    cat["5E"] = (cat["5E"][0] + 50_000_00,)
    f = dict(P.G9_DEFAULT, cat=cat)
    pdf, exp9 = P.gstr9(fy=FY, f=f, watermark="all")
    if folder:
        open(os.path.join(folder, f"GSTR9_FY{FY}.pdf"), "wb").write(pdf)
    g9file = Fd.read_pdf(pdf, "GSTR9.pdf")
    return files + [g9file], exp9


@pytest.fixture(scope="module")
def year():
    return build()


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "sample_pdfs_gstr1_vs_gstr9"
    os.makedirs(out, exist_ok=True)
    build(out)


def test_gstr9_category_rows_read(year):
    files, exp9 = year
    g9 = files[-1]
    for k, v in exp9.items():
        if k.split("_")[1][:1] in "45" and k in g9["fields"]:
            assert g9["fields"][k] == v, k
    assert g9["fields"]["G9FILED_4K_TXVAL"] == exp9["G9FILED_4K_TXVAL"]          # 4K not confused with Table 10
    assert g9["fields"]["G9FILED_10_TXVAL"] == exp9["G9FILED_10_TXVAL"]
    missing = [k for k in exp9 if k.split("_")[1][:1] in "45" and k not in g9["fields"]]
    assert not missing, missing


def test_category_deviations(year):
    files, _ = year
    g1, b3, g9 = Fd.build_tables(files, FY)
    dev = Fd.find_deviations(g1, b3, g9, 1.0, files, FY)
    c = dev[(dev["code"] == "C") & (dev["Result"] == "Deviation")]
    got = {(r["Check"].split(": ")[1], r["Head"]): r["A - B (Rs)"] for _, r in c.iterrows()}
    assert got == {("B2B (registered)", "Taxable value"): -100000, ("B2B (registered)", "CGST"): -9000, ("B2B (registered)", "SGST/UTGST"): -9000,
                   ("B2C (unregistered)", "Taxable value"): 100000, ("B2C (unregistered)", "CGST"): 9000, ("B2C (unregistered)", "SGST/UTGST"): 9000,
                   ("Nil rated", "Taxable value"): 50000}
    matched = dev[(dev["code"] == "C") & (dev["Result"] == "Matches")]
    assert {"SEZ supplies with payment of tax", "Credit / debit notes (net)", "Amendments (net)", "Exports with payment of tax", "Advances - tax paid, invoice not issued"} <= \
        {x.split(": ")[1] for x in matched["Check"]}
    from datetime import date

    from engine import analysis as A
    an = A.analyse(dev, g1, b3, g9, FY, files, date(2025, 11, 1))
    b2b = next(i for i in an["items"] if i["code"] == "C" and "B2B" in i["check"] and i["head"] == "Taxable value")
    assert b2b["severity"] == "Low" and any("classification difference" in l for l in b2b["links"])
    table, _, info = CT.reconcile(files, g9, FY)
    assert info["complete"] and len(table) == len(CT.CATS)


def test_category_waits_for_full_year(year):
    files, _ = year
    part = files[1:]
    g1, b3, g9 = Fd.build_tables(part, FY)
    dev = Fd.find_deviations(g1, b3, g9, 1.0, part, FY)
    assert not (dev["code"] == "C").any()
