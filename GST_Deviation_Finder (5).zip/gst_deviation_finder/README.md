# GST Deviation Finder (v2.3)

Finds deviations between **GSTR-1, GSTR-3B and GSTR-9** using only the **filed PDFs** downloaded from the GST portal, and explains every deviation in detail. One screen, offline.

## Start
Windows: double-click `run_app.bat`. Python 3.10 or later is needed (python.org, tick "Add python.exe to PATH").
- Every start checks that all libraries are present; if anything is missing (e.g. an earlier install was interrupted) it repairs itself. First setup takes 3-8 minutes and needs internet.
- If setup fails, the window shows the last lines of `setup_log.txt` - usually no internet or an office proxy blocking pip.
- `repair_app.bat` deletes the private library folder (`.venv`) and installs it again. Saved reports are not touched.
- Close the black window to stop the app.

## Use
1. **Upload** all PDFs for one GSTIN and one year together - 12 GSTR-1, 12 GSTR-3B, 1 GSTR-9. The tool recognises each return and its month.
2. **Check what was read** - each figure has a status:
   - *Verified* - two readers read the same amount, or the return's own arithmetic proves it.
   - *Read* - read by one reader from the cell under its column heading.
   - *Check* - the readers differed; the table value is used. Confirm it against the picture shown.
   - *Type it* - not read with certainty (e.g. a watermark printed inside the cell). Left blank: type it from the picture.
   Every figure needing attention is shown with a picture of that part of the PDF. Anything you type is listed in the report.
3. **Deviations** - every difference above the tolerance (default Rs 1).
4. **Detailed analysis** - for each deviation: severity, how it links to other deviations (monthly rows behind a year total, timing differences that reverse in a later month, tax paid under the wrong head, GSTR-9 differences split into their GSTR-1 and GSTR-3B parts), likely causes, how to verify, action, indicative interest @18% to the date you choose, the law, and key deadlines.
5. **Report** - download the PDF and Excel reports, or **Save both on this computer**: they go into the `reports` folder next to the app (`GST_Deviation_Report_<GSTIN>_FY<year>_<date_time>.pdf / .xlsx`). Saved reports are listed in the app with download buttons; *Open reports folder* opens the folder.

Try it with the 25 PDFs in `sample_pdfs/` (hypothetical data with planted deviations).

## GSTR-1: read table by table
The portal's GSTR-1 PDF is read table by table - 4A, 4B, 5, 6A/6B/6C, 7, 8 (Nil / Exempted / Non-GST), every 9A amendment, 9B CDNR/CDNUR, 9C, 10, 11A/11B, 12 HSN, 13, 14, 15 and the Total Liability line. Each amount is placed by its column's right edge, so blank columns (e.g. Central/State for B2CL, exports, SEZ) never shift figures.
- The portal's **Total Liability value includes Table 8** (nil / exempt / non-GST). The tool uses *taxable value = Total Liability value - Table 8* for the GSTR-3B comparison, and compares Table 8 with GSTR-3B 3.1(c)+(e) separately.
- The Total Liability is proved against the sum of the tables (4 to 11, net of credit notes and amendments); when it agrees the figures show *Verified*.
- Extra checks: GSTR-1 Table 12 (HSN) vs Total Liability, and GSTR-1 Table 8 vs GSTR-3B 3.1(c)+(e).
- In the app: *GSTR-1 table-wise* shows the year total of every table and any month in full; both are in the Excel report.

## GSTR-1 vs GSTR-9 by category
With all 12 GSTR-1 PDFs and the GSTR-9 uploaded, each GSTR-9 Table 4 / Table 5 row is compared with the year total of the GSTR-1 tables that auto-populate it (GSTN mapping):

| GSTR-9 | GSTR-1 (12 months) |
|---|---|
| 4A B2C | 5 (B2CL) + 7 (B2CS) + 9A (B2CL amendments) + 10 |
| 4B B2B | 4A |
| 4C / 4D / 4E | 6A EXPWP / 6B SEZWP / 6C |
| 4F Advances | 11A - 11B (incl. amendments) |
| (4J - 4I) + (5I - 5H) credit/debit notes | 9B CDNR + CDNUR (net) |
| (4K - 4L) + (5J - 5K) amendments | 9A (except B2CL) + 9C net differentials |
| 5A / 5B / 5C | 6A EXPWOP / 6B SEZWOP / 4B |
| 5D / 5E / 5F | Table 8 Exempted / Nil / Non-GST |

Credit/debit notes and amendments are compared net because the filed GSTR-1 PDF prints them net. Equal and opposite differences between two categories are flagged as a classification difference (total matches). Try it with `sample_pdfs_gstr1_vs_gstr9/` (planted: Rs 1 lakh moved from 4B to 4A; Rs 50,000 extra in 5E).

## How watermarks are handled
Watermark characters are removed before reading: rotated text, transparent text, oversized text, light-grey text, and characters only one of the two PDF engines draws (image / vector stamps). Figures are then read twice - from the table cells (column found from the ruled lines or from the column alignment) and from the text stream - and used only when they agree, or when the table cell or the return's arithmetic (GSTR-3B 4C = 4A - 4B, GSTR-9 8D = 8A - (8B + 8C)) settles them. CGST and SGST on the same line must be equal. A cell that still contains foreign text is never guessed - it is marked *Type it*.

Tested on 102 hostile replica PDFs (7 watermark types x 4 layouts x 3 returns, plus short headers, polluted cells and reordered columns): **0 wrong figures**; where unsure, figures are left blank or flagged *Check*.

## Checks
| Check | Compares |
|---|---|
| GSTR-1 vs GSTR-3B (monthly) | GSTR-1 total liability vs GSTR-3B 3.1(a)+(b), taxable value and each head |
| GSTR-1 vs GSTR-3B (year) | the same, added up over the months present in both |
| GSTR-9 vs GSTR-3B (tax) | GSTR-9 Table 4N vs GSTR-3B 3.1(a)+(b)+(d) for the year |
| GSTR-9 vs GSTR-1 (tax) | GSTR-9 Table 4N vs GSTR-1 + GSTR-3B 3.1(d); Tables 10/11 shown as explanation |
| GSTR-9 vs GSTR-3B (ITC) | GSTR-9 Table 6A vs GSTR-3B 4A for the year |
| GSTR-9 Table 9 | tax payable vs tax paid |
| GSTR-9 Table 8D | ITC in GSTR-2B vs ITC availed |

GSTR-9 checks against GSTR-1 / GSTR-3B run only when all 12 months are uploaded, so a missing month never shows as a false deviation.

## Limits
- The readers follow the portal's printed wording and were tested on replica PDFs, not yet on live portal PDFs. If the portal layout differs, figures come out blank (*Type it*), not wrong.
- Scanned / photographed PDFs cannot be read.
- Interest is indicative: simple 18% p.a. from the day after the GSTR-3B due date (20th, monthly filer) to the chosen date, assuming the amount is unpaid. DRC-03 payments, QRMP dates and cash-ledger balances are not known to the tool.
- Rule 88C (DRC-01B) and Rule 88D (DRC-01C) thresholds are not notified; the report says so.
- Results are a working paper for internal review, not a legal opinion.

Tests: `python -m pytest -q`
