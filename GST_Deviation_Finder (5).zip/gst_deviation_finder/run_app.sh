#!/usr/bin/env bash
# GST Deviation Finder - start the app. Libraries are checked on every start and installed/repaired if missing.
cd "$(dirname "$0")"
CHECK="import streamlit, numpy, pandas, pyarrow, plotly, pdfplumber, pypdfium2, xlsxwriter, openpyxl, reportlab"
if ! .venv/bin/python -c "$CHECK" >/dev/null 2>&1; then
  echo "Setting up the libraries (needs internet)..."
  [ -x .venv/bin/python ] || python3 -m venv .venv || exit 1
  .venv/bin/python -m pip install --upgrade pip >setup_log.txt 2>&1
  .venv/bin/python -m pip install --prefer-binary -r requirements.txt >>setup_log.txt 2>&1
  .venv/bin/python -c "$CHECK" || { echo "Install failed - see setup_log.txt"; tail -20 setup_log.txt; exit 1; }
fi
.venv/bin/python -m streamlit run app.py
