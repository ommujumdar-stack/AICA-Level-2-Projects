"""GST Deviation Finder - one screen.  Run:  streamlit run app.py
Upload filed GSTR-1, GSTR-3B and GSTR-9 PDFs -> check what was read -> see deviations with detailed analysis ->
download the report and/or save it in the 'reports' folder next to the app.
Uploaded PDFs are not stored; only reports you choose to save are written to disk."""
import hashlib
import html
from datetime import date

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from engine import analysis as A
from engine import finder as Fd
from engine import report as RP
from engine import schema as S

st.set_page_config(page_title="GST Deviation Finder", page_icon=":material/compare_arrows:", layout="wide")

# Orange & beige theme. NAVY = ink (headings), GOLD = amber (notes/medium), RED/GREEN = risk only.
ORANGE, ORANGE_D, BEIGE, CARD, LINE = "#E8590C", "#C2410C", "#F6EFE3", "#FFFCF7", "#EADCC8"
NAVY, GOLD, RED, GREEN, MUTED = "#3A2414", "#B45309", "#B42318", "#2F6B3B", "#7A6650"
st.markdown(f"""<style>
#MainMenu, footer, [data-testid="stDeployButton"] {{visibility:hidden}}
.stApp {{background:{BEIGE}}}
[data-testid="stHeader"] {{background:transparent}}
.block-container {{max-width:1280px; padding-top:1.4rem}}
h1,h2,h3 {{font-family: Georgia, serif; color:{NAVY}}}
.hero {{background:linear-gradient(120deg,{ORANGE} 0%,{ORANGE_D} 62%,#9A3412 100%); color:#fff; border-radius:16px; padding:24px 28px;
        margin-bottom:18px; box-shadow:0 6px 18px rgba(194,65,12,.18); position:relative; overflow:hidden}}
.hero:after {{content:""; position:absolute; right:-60px; top:-60px; width:240px; height:240px; border-radius:50%;
              background:radial-gradient(circle, rgba(255,237,213,.35) 0%, rgba(255,237,213,0) 70%)}}
.hero .k {{color:#FFE8CC; font-size:.72rem; letter-spacing:.18em; text-transform:uppercase; font-weight:700}}
.hero .t {{font-family:Georgia,serif; font-size:1.75rem; margin:4px 0}}
.hero .s {{color:#FFF1E2; font-size:.95rem; max-width:900px}}
.step {{display:flex; gap:12px; align-items:center; margin:26px 0 10px 0; padding-bottom:8px; border-bottom:2px solid {LINE}}}
.step .n {{width:32px; height:32px; border-radius:50%; background:{ORANGE}; color:#fff; display:flex; align-items:center;
          justify-content:center; font-weight:700; box-shadow:0 2px 6px rgba(232,89,12,.35)}}
.step .t {{font-family:Georgia,serif; font-size:1.3rem; color:{NAVY}}}
.step .s {{color:{MUTED}; font-size:.88rem}}
.kpi {{background:{CARD}; border:1px solid {LINE}; border-left:5px solid var(--a); border-radius:12px; padding:12px 16px; height:100%}}
.kpi .l {{font-size:.7rem; letter-spacing:.12em; text-transform:uppercase; color:{MUTED}; font-weight:700}}
.kpi .v {{font-family:Georgia,serif; font-size:1.7rem; color:{NAVY}}}
.kpi .x {{font-size:.8rem; color:{MUTED}}}
.verdict {{background:{CARD}; border:1px solid {LINE}; border-left:6px solid var(--a); border-radius:12px; padding:14px 18px; margin:8px 0 14px 0;
           font-size:.98rem; color:{NAVY}}}
.sev {{display:inline-block; padding:1px 10px; border-radius:10px; font-size:.75rem; font-weight:700}}
.sec {{font-weight:700; color:{ORANGE_D}; margin:10px 0 2px 0; font-size:.8rem; letter-spacing:.06em; text-transform:uppercase}}
.note {{border-left:4px solid {ORANGE}; background:#FFF4E6; padding:9px 14px; border-radius:8px; color:#5B3A1E; font-size:.88rem; margin:6px 0 10px 0}}
[data-testid="stExpander"] details {{background:{CARD}; border:1px solid {LINE}; border-radius:12px}}
[data-testid="stExpander"] summary:hover {{color:{ORANGE_D}}}
[data-testid="stFileUploaderDropzone"] {{background:{CARD}; border:2px dashed #F0B98F}}
[data-testid="stMetricValue"] {{font-family:Georgia,serif; color:{NAVY}}}
.stTabs [aria-selected="true"] {{color:{ORANGE_D}}}
</style>""", unsafe_allow_html=True)


def step(n, title, sub=""):
    st.markdown(f'<div class="step"><div class="n">{n}</div><div><div class="t">{html.escape(title)}</div>'
                f'<div class="s">{sub}</div></div></div>', unsafe_allow_html=True)


def kpi(col, label, value, sub, accent=ORANGE):
    col.markdown(f'<div class="kpi" style="--a:{accent}"><div class="l">{label}</div><div class="v">{value}</div><div class="x">{sub}</div></div>',
                 unsafe_allow_html=True)


def inr(r):
    v = abs(r)
    s = "-" if r < 0 else ""
    if v >= 1e7:
        return f"{s}₹{v / 1e7:,.2f} Cr"
    if v >= 1e5:
        return f"{s}₹{v / 1e5:,.2f} L"
    return f"{s}₹{S.fmt_inr(v, paise=False)}"


@st.cache_data(show_spinner=False, max_entries=500)
def read_cached(digest: str, data: bytes, name: str):
    return Fd.read_pdf(data, name)


@st.cache_data(show_spinner=False, max_entries=300)
def crop_png(digest: str, data: bytes, page: int, bbox):
    """Picture of where a figure sits on the PDF page (with the watermark, exactly as printed)."""
    import io

    import pypdfium2 as pdfium

    pdf = pdfium.PdfDocument(data)
    pg = pdf[min(page, len(pdf) - 1)]
    scale = 2.2
    img = pg.render(scale=scale).to_pil()
    if bbox:
        x0, top, x1, bottom = bbox
        pad = 10
        img = img.crop((max(0, (x0 - pad) * scale), max(0, (top - 3 * pad) * scale), min(img.width, (x1 + pad) * scale),
                        min(img.height, (bottom + pad) * scale)))
    bio = io.BytesIO()
    img.save(bio, format="PNG")
    return bio.getvalue()


SEV_STYLE = {"High": f"background:#FDE4E1;color:{RED}", "Medium": f"background:#FCEBD2;color:{GOLD}", "Low": f"background:#E6F0E2;color:{GREEN}"}


st.markdown('<div class="hero"><div class="k">GST Deviation Finder</div>'
            '<div class="t">GSTR-1 vs GSTR-3B vs GSTR-9 - deviation analysis from the filed PDFs</div>'
            '<div class="s">Drop in the filed PDFs, check what was read, and get a detailed analysis of every deviation. Works offline; '
            'uploaded PDFs are never stored - only reports you save.</div></div>',
            unsafe_allow_html=True)

# ------------------------------------------------------------------------------- 1. upload
step(1, "Upload the filed PDFs", "All at once: 12 GSTR-1, 12 GSTR-3B and the GSTR-9 for one GSTIN and one year. "
     "The tool works out which return each PDF is, and its month.")
ups = st.file_uploader("Filed PDFs", type=["pdf"], accept_multiple_files=True, label_visibility="collapsed")
if not ups:
    st.markdown('<div class="note">Download the filed returns from the GST portal (Returns > View e-Filed Returns > Download PDF). '
                "Watermarked PDFs are fine. Scanned or photographed PDFs cannot be read.</div>", unsafe_allow_html=True)
    st.stop()

files, raw = [], {}
prog = st.progress(0.0, text=f"Reading {len(ups)} PDF(s)...")
for n, up in enumerate(ups):
    data = up.getvalue()
    dg = hashlib.sha256(data).hexdigest()
    files.append(read_cached(dg, data, up.name))
    raw[up.name] = (dg, data)
    prog.progress((n + 1) / len(ups), text=f"Read {n + 1} of {len(ups)}: {up.name}")
prog.empty()

fy_guess = Fd.guess_fy(files)
c1, c2 = st.columns([1, 3])
fy = c1.selectbox("Financial year", S.fy_list(), index=S.fy_list().index(fy_guess) if fy_guess in S.fy_list() else 2)
cov = Fd.coverage(files, fy)

# ------------------------------------------------------------------------------- 2. what was read
step(2, "Check what was read", "Every figure comes from the PDFs. A blank cell means it could not be read - "
     "type it from the PDF. Corrections apply to the comparison immediately.")
summary = pd.DataFrame([{"File": f["name"], "Return": Fd.TYPE_LABEL.get(f.get("type"), "-"),
                         "Period": Fd.label(f["period"]) if f.get("period") else ("Year" if f.get("type") == "GSTR9" else "-"),
                         "GSTIN": f.get("gstin") or "-", "Status": f["status"]} for f in files])
order = {"-": 0, "GSTR-1": 1, "GSTR-3B": 2, "GSTR-9": 3}
summary = summary.assign(_o=summary["Return"].map(order)).sort_values(["_o", "File"]).drop(columns="_o")
problems = []
if len(cov["gstins"]) > 1:
    problems.append(f"PDFs from <b>{len(cov['gstins'])} different GSTINs</b> ({', '.join(cov['gstins'])}) - remove the ones that do not belong.")
if len(cov["fys"]) > 1:
    problems.append(f"PDFs from more than one financial year ({', '.join(cov['fys'])}) - only FY {fy} is compared.")
for k, names in cov["duplicates"].items():
    problems.append(f"{k} uploaded twice ({', '.join(names)}) - the last one read is used.")
bad = summary[summary["Return"] == "-"]
if len(bad):
    problems.append(f"{len(bad)} PDF(s) not recognised - see the table below.")
for t, ms in cov["missing"].items():
    if ms and len(ms) < 12:
        problems.append(f"{Fd.TYPE_LABEL[t]} missing for {', '.join(ms)} - those months are not compared.")
    elif len(ms) == 12:
        problems.append(f"No {Fd.TYPE_LABEL[t]} uploaded.")
if not cov["has9"]:
    problems.append("No GSTR-9 uploaded - annual checks against GSTR-9 are skipped.")
elif cov["missing"]["GSTR3B"] or cov["missing"]["GSTR1"]:
    problems.append("GSTR-9 is compared with the full year only, so the GSTR-9 vs GSTR-1 / GSTR-3B checks wait until all 12 months "
                    "are uploaded. Table 8 and Table 9 checks still run.")
for p in problems:
    st.markdown(f'<div class="note">{p}</div>', unsafe_allow_html=True)

q = RP.read_quality(files)
k = st.columns(5)
kpi(k[0], "PDFs read", f"{(summary['Return'] != '-').sum()} / {len(summary)}", "recognised as GSTR-1 / 3B / 9")
kpi(k[1], "Months", f"{12 - len(cov['missing']['GSTR1'])} / {12 - len(cov['missing']['GSTR3B'])}", "GSTR-1 / GSTR-3B, of 12")
kpi(k[2], "Figures verified", str(q["Verified"] + q["Read"]), f"{q['Verified']} confirmed twice, {q['Read']} by one reader", GREEN)
kpi(k[3], "To glance at", str(q["Check"]), "readers differed - value used, confirm", GOLD if q["Check"] else GREEN)
withheld = q["Type it"]
kpi(k[4], "Figures to type", str(withheld), "left blank - not read with certainty", RED if withheld else GREEN)

with st.expander("Files and their status", expanded=bool(len(bad))):
    st.dataframe(summary, hide_index=True, width="stretch")
    wm = [f["name"] for f in files if (f.get("watermark") or {}).get("chars_removed")]
    if wm:
        st.caption(f"Watermark detected and removed before reading in {len(wm)} PDF(s): " + ", ".join(wm))

attention = [(f, code, stt) for f in files for code, stt in (f.get("fstatus") or {}).items() if stt.get("status") in ("Check", "Type it")]
if attention:
    with st.expander(f"Figures needing your attention ({len(attention)}) - each shown with the picture from the PDF", expanded=True):
        st.caption("'Type it' = left blank; read the amount from the picture and type it in the table below. "
                   "'Check' = the two readers differed; the value shown was used - confirm it against the picture.")
        for f, code, stt in attention[:60]:
            per = Fd.label(f["period"]) if f.get("period") else ("FY " + (f.get("fy") or ""))
            c1_, c2_ = st.columns([2, 3])
            used = f["fields"].get(code)
            c1_.markdown(f"**{html.escape(Fd.field_label(code))}** - {Fd.TYPE_LABEL.get(f['type'], '')} {per}  \n"
                         f"<span class='sev' style='{SEV_STYLE['Medium'] if stt['status'] == 'Check' else SEV_STYLE['High']}'>{stt['status']}</span> "
                         f"{html.escape(stt.get('note', ''))}  \n"
                         + (f"Value used: **{S.fmt_inr(used)}**" if used is not None else "Value: **blank**")
                         + (f" | other reading: {S.fmt_inr(stt['alt'])}" if stt.get("alt") is not None else "")
                         + f"  \n<span style='color:{MUTED};font-size:.8rem'>{html.escape(f['name'])}</span>", unsafe_allow_html=True)
            ev = stt.get("ev") or {}
            dg, data = raw.get(f["name"], (None, None))
            if data is not None:
                try:
                    c2_.image(crop_png(dg, data, ev.get("page", 0), ev.get("bbox")), width="stretch",
                              caption=None if ev.get("bbox") else "Exact position not located - page 1 shown")
                except Exception:  # noqa: BLE001
                    c2_.caption("Picture not available for this PDF.")
            st.divider()
        if len(attention) > 60:
            st.caption(f"{len(attention) - 60} more not shown - see the 'Files read' sheet of the Excel report.")

g1, b3, g9 = Fd.build_tables(files, fy)
g1_0, b3_0, g9_0 = g1.copy(), b3.copy(), g9.copy()
money = lambda cols: {c: st.column_config.NumberColumn(c, format="localized") for c in cols}  # noqa: E731
t1, t2, t3 = st.tabs(["GSTR-1 (monthly)", "GSTR-3B (monthly)", "GSTR-9 (annual)"])
with t1:
    g1 = st.data_editor(g1, width="stretch", column_config=money(Fd.G1_COLS), key=f"e1_{fy}", num_rows="fixed", height=480)
with t2:
    b3 = st.data_editor(b3, width="stretch", column_config=money(Fd.B3_COLS), key=f"e3_{fy}", num_rows="fixed", height=480)
with t3:
    st.caption("GSTR-9 prints Central, State/UT, Integrated, Cess; the tool has already placed each figure under the right head.")
    g9 = st.data_editor(g9, width="stretch", column_config=money(Fd.G9_COLS), key=f"e9_{fy}", num_rows="fixed", height=440)

from engine import g1_portal as G1P  # noqa: E402

g1_long, g1_year = G1P.year_tables(files, fy)
if not g1_long.empty:
    with st.expander("GSTR-1 table-wise - every table as printed on the filed PDF", expanded=False):
        st.caption("Read from the portal's GSTR-1 layout. 'Taxable value' in the GSTR-1 table above = Total Liability value "
                   "less Table 8 (the portal's Total Liability value includes nil-rated / exempted / non-GST supplies).")
        vt1, vt2 = st.tabs(["Year total by table", "One month in full"])
        with vt1:
            st.dataframe(g1_year, hide_index=True, width="stretch", height=min(42 + 35 * len(g1_year), 640),
                         column_config=money(["Value", "IGST", "CGST", "SGST/UTGST", "Cess"]))
        with vt2:
            g1_files = sorted([f for f in files if f.get("g1_rows") and f.get("period")], key=lambda f: f["period"])
            pick = st.selectbox("Month", [Fd.label(f["period"]) for f in g1_files], key="g1_month")
            fsel = next(f for f in g1_files if Fd.label(f["period"]) == pick)
            st.dataframe(G1P.table_frame({"rows": fsel["g1_rows"]}), hide_index=True, width="stretch", height=560,
                         column_config=money(["Value", "IGST", "CGST", "SGST/UTGST", "Cess"]))

edits = []
for name, t0, t1_ in (("GSTR-1", g1_0, g1), ("GSTR-3B", b3_0, b3), ("GSTR-9", g9_0, g9)):
    for r in t0.index:
        for c in t0.columns:
            a_, b_ = t0.loc[r, c], t1_.loc[r, c]
            if not (pd.isna(a_) and pd.isna(b_)) and (pd.isna(a_) or pd.isna(b_) or abs(float(a_) - float(b_)) > 0.004):
                edits.append(f"{name} {r} / {c}: {'-' if pd.isna(a_) else S.fmt_inr(a_, paise=False)} -> "
                             f"{'-' if pd.isna(b_) else S.fmt_inr(b_, paise=False)}")
if edits:
    st.markdown(f'<div class="note"><b>{len(edits)} figure(s) typed or changed by you</b> - they are used in the comparison and listed in the report.</div>',
                unsafe_allow_html=True)

# ------------------------------------------------------------------------------- 3. deviations
step(3, "Deviations", "Every comparison made between the returns. Only differences above the tolerance are shown as deviations.")
tol = st.columns([1, 3])[0].number_input("Tolerance (₹) - differences up to this are rounding", 0.0, 10000.0, 1.0, step=1.0)
dev = Fd.find_deviations(g1, b3, g9, tol, files, fy)
from engine import category as CT  # noqa: E402

cat_table, _, cat_info = CT.reconcile(files, g9, fy)
if cov["has9"] and cat_info["months"]:
    with st.expander("GSTR-1 vs GSTR-9 by category (Table 4 / Table 5)", expanded=bool(cat_info["complete"])):
        if not cat_info["complete"]:
            st.markdown(f'<div class="note">Only {cat_info["months"]} of 12 GSTR-1 PDFs were read table-wise. The category figures below are '
                        "partial and are <b>not</b> reported as deviations until all 12 months are uploaded.</div>", unsafe_allow_html=True)
        st.caption("GSTR-1 year total of the source tables vs the GSTR-9 row it auto-populates. Credit/debit notes and amendments are "
                   "compared net, because the filed GSTR-1 PDF prints them net. Edit GSTR-9 figures in the GSTR-9 table above if needed.")
        num = [c for c in cat_table.columns if c.startswith(("GSTR-1 ", "GSTR-9 ", "Difference "))]

        def _hl(v):
            return f"color:{RED};font-weight:700" if isinstance(v, (int, float)) and not pd.isna(v) and abs(v) > tol else ""
        st.dataframe(cat_table.style.map(_hl, subset=[c for c in num if c.startswith("Difference")]), hide_index=True, width="stretch",
                     column_config=money(num), height=min(42 + 35 * len(cat_table), 560))
if dev.empty:
    st.info("Nothing to compare yet - upload GSTR-1 and GSTR-3B for the same months, and the GSTR-9.")
    st.stop()
devs = dev[dev["Result"] == "Deviation"]
higher = devs[devs["Risk"] == "Higher"]
header = f"GSTIN {', '.join(cov['gstins']) or '-'} | FY {fy}"

if devs.empty:
    st.markdown(f'<div class="verdict" style="--a:{GREEN}"><b>No deviations.</b> All {len(dev)} comparisons agree within ₹{tol:,.0f}.</div>',
                unsafe_allow_html=True)
else:
    m1 = devs[devs["code"] == "M1"]
    tax_devs = devs[devs["Head"] != "Taxable value"]
    worst = (tax_devs[tax_devs["Risk"] == "Higher"] if (tax_devs["Risk"] == "Higher").any() else (tax_devs if len(tax_devs) else devs)).iloc[0]
    st.markdown(
        f'<div class="verdict" style="--a:{RED if len(higher) else GOLD}"><b>{len(devs)} deviation(s)</b> in {len(dev)} comparisons. '
        f'{len(higher)} point to tax possibly short-paid or ITC over-claimed. '
        f'Largest: <b>{html.escape(worst["Check"])}</b>, {html.escape(worst["Period"])}, {html.escape(worst["Head"])}: {inr(worst["A - B (Rs)"])}. '
        + (f'Monthly GSTR-1 vs GSTR-3B differences in {m1["Period"].nunique()} month(s).' if len(m1) else
           ("Monthly GSTR-1 and GSTR-3B agree." if (dev["code"] == "M1").any() else "GSTR-1 vs GSTR-3B not compared - upload both for the same months."))
        + "</div>", unsafe_allow_html=True)

show_all = st.toggle("Show matching comparisons too", value=False)
cols = ["Check", "Period", "Head", "A - B (Rs)", "Risk", "What it means", "Source A", "A (Rs)", "Source B", "B (Rs)"]
view = (dev if show_all else devs)[(["Result"] if show_all else []) + cols]


def colour(v):
    return {"Deviation": f"background-color:#FDE4E1;color:{RED};font-weight:700", "Matches": f"background-color:#E6F0E2;color:{GREEN}",
            "Higher": f"color:{RED};font-weight:700"}.get(v, "")


st.dataframe(view.style.map(colour, subset=[c for c in ("Result", "Risk") if c in view.columns]), hide_index=True, width="stretch",
             height=min(42 + 35 * len(view), 560),
             column_config={**money(["A (Rs)", "B (Rs)", "A - B (Rs)"]), "What it means": st.column_config.TextColumn(width="large"),
                            "Check": st.column_config.TextColumn(width="medium")})
st.caption("Risk 'Higher' = the direction that can cost tax (GSTR-1 above GSTR-3B, GSTR-9 above what was paid, ITC claimed above "
           "GSTR-2B). 'Lower' = excess paid or credit left unclaimed. Hover over 'What it means' to read it in full.")

m = dev[dev["code"] == "M1"]
if not m.empty:
    tax = m[m["Head"] != "Taxable value"].groupby("Period", sort=False)["A - B (Rs)"].sum()
    tax = tax.reindex([Fd.label(p) for p in Fd.months(fy)]).dropna()
    st.markdown(f"**GSTR-1 minus GSTR-3B tax, month by month** - bars above the line: GSTR-1 higher (possible short payment); below: GSTR-3B higher.")
    fig = go.Figure(go.Bar(x=tax.index, y=tax.values, marker_color=[RED if v > tol else (ORANGE if v < -tol else "#D9C9B3") for v in tax.values],
                           hovertemplate="%{x}: ₹%{y:,.0f}<extra></extra>", text=[inr(v) if abs(v) > tol else "" for v in tax.values],
                           textposition="outside", cliponaxis=False))
    fig.add_hline(y=0, line_color=NAVY, line_width=1.2)
    lim = max(abs(tax).max() * 1.35, 100)
    fig.update_layout(height=280, margin=dict(l=8, r=8, t=10, b=8), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      yaxis=dict(title="Rs", range=[-lim, lim], gridcolor="#EADCC8", zeroline=False), font=dict(family="Segoe UI, Arial", color=NAVY))
    st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})

# ------------------------------------------------------------------------------- 4. detailed analysis
step(4, "Detailed analysis of every deviation", "Severity, how deviations link to each other, likely causes, how to verify, "
     "action, indicative interest and the law - for each deviation.")
ca, cb = st.columns([1, 3])
as_of = ca.date_input("Interest up to", value=date.today(), format="DD-MM-YYYY",
                      help="Indicative interest @18% p.a. is computed to this date, assuming the amount is still unpaid.")
an = A.analyse(dev, g1, b3, g9, fy, files, as_of)
sm = an["summary"]
if an["items"]:
    k = st.columns(5)
    kpi(k[0], "High / Medium / Low", f"{sm['severity']['High']} / {sm['severity']['Medium']} / {sm['severity']['Low']}", "deviations by severity",
        RED if sm["severity"]["High"] else GOLD)
    kpi(k[1], "Monthly short payment", inr(sm["monthly_short"] / 100), "GSTR-1 above GSTR-3B (tax)", RED if sm["monthly_short"] else GREEN)
    kpi(k[2], "Indicative interest", inr((sm["interest_monthly"] + sm["interest_gstr9"]) / 100), f"to {as_of:%d-%m-%Y}, @18% p.a.",
        RED if sm["interest_monthly"] else GREEN)
    kpi(k[3], "Added in GSTR-9", inr(sm["gstr9_added"] / 100), "beyond GSTR-1 and GSTR-3B", GOLD if sm["gstr9_added"] else GREEN)
    kpi(k[4], "ITC: lapse / excess", f"{inr(sm['itc_lapse'] / 100)} / {inr(sm['itc_excess'] / 100)}", "8D: in 2B not availed / availed above 2B",
        GOLD if sm["itc_lapse"] or sm["itc_excess"] else GREEN)
    soon = [f"<b>{n}</b>: {d:%d-%m-%Y} ({left} days left)" for n, d, left in sm["dates"] if 0 <= left <= 90]
    if soon:
        st.markdown('<div class="note">' + "<br>".join(soon) + "</div>", unsafe_allow_html=True)
    if sm.get("turnover_note"):
        st.caption(sm["turnover_note"])
    sev_f = st.multiselect("Show severity", ["High", "Medium", "Low"], default=["High", "Medium", "Low"])
    for it in an["items"]:
        if it["severity"] not in sev_f:
            continue
        title = f"#{it['no']}  [{it['severity']}]  {it['check']} - {it['head']}, {it['period']}  |  {inr(it['diff'] / 100)}"
        with st.expander(title, expanded=(it["severity"] == "High")):
            st.markdown(f"<span class='sev' style='{SEV_STYLE[it['severity']]}'>{it['severity']}</span> &nbsp; {html.escape(it['headline'])}",
                        unsafe_allow_html=True)
            fcols = st.columns(4)
            fcols[0].metric(it["a_name"], inr(it["a"] / 100))
            fcols[1].metric(it["b_name"], inr(it["b"] / 100))
            fcols[2].metric("Difference (A - B)", inr(it["diff"] / 100), f"{it['pct']:+.2f}%" if it["pct"] is not None else None,
                            delta_color="inverse" if it["risk"] == "Higher" else "off")
            if it["interest"]:
                fcols[3].metric("Indicative interest", inr(it["interest"]["amount"] / 100))
            for ttl, lines in (("What it means", [it["meaning"]] if it["meaning"] else []), ("How it links", it["links"]),
                               ("Likely causes", it["causes"]), ("How to verify", it["verify"]), ("Action", it["action"]),
                               ("Interest basis", [it["interest"]["basis"]] if it["interest"] else []),
                               ("Law", [", ".join(it["legal"])] if it["legal"] else []), ("Notes", it["notes"])):
                if lines:
                    st.markdown(f"<div class='sec'>{ttl}</div>", unsafe_allow_html=True)
                    st.markdown("\n".join(f"- {html.escape(x)}" for x in lines) if len(lines) > 1 else html.escape(lines[0]))
else:
    st.markdown(f'<div class="verdict" style="--a:{GREEN}">No deviation to analyse.</div>', unsafe_allow_html=True)

# ------------------------------------------------------------------------------- 5. report
step(5, "Report - download or save on this computer", "PDF with the summary, register and detailed analysis, and Excel with every "
     "comparison and figure. 'Save' writes both into the reports folder next to the app.")
gst_id = cov["gstins"][0] if len(cov["gstins"]) == 1 else ("MIXED" if cov["gstins"] else "")
xlsx = Fd.to_excel(dev, g1, b3, g9, files, header, an, extra=[("GSTR-1 vs GSTR-9 categories", cat_table), ("GSTR-1 tables (year)", g1_year),
                                                                       ("GSTR-1 tables (monthly)", g1_long)])
pdf = RP.build_pdf(an, files, gst_id, fy, tol, edits)
stem = f"GST_Deviation_Report_{gst_id or 'NA'}_FY{fy}"
d1, d2, d3, d4 = st.columns(4)
d1.download_button("Download PDF report", pdf, file_name=stem + ".pdf", mime="application/pdf", type="primary", width="stretch")
d2.download_button("Download Excel report", xlsx, file_name=stem + ".xlsx", width="stretch")
if d3.button("Save both on this computer", width="stretch"):
    try:
        paths = RP.save(pdf, xlsx, gst_id, fy)
        st.session_state["saved_msg"] = "Saved: " + " and ".join(p.name for p in paths) + f" in {paths[0].parent}"
    except Exception as e:  # noqa: BLE001
        st.session_state["saved_msg"] = f"Could not save: {e}"
if d4.button("Open reports folder", width="stretch"):
    if not RP.open_folder():
        st.info(f"Reports folder: {RP.reports_dir()}")
if st.session_state.get("saved_msg"):
    st.success(st.session_state["saved_msg"])

saved = RP.list_saved()
with st.expander(f"Saved reports ({len(saved)}) - folder: {RP.reports_dir()}", expanded=False):
    if not saved:
        st.caption("Nothing saved yet.")
    for i, r in enumerate(saved[:40]):
        c1_, c2_, c3_ = st.columns([5, 2, 1.4])
        c1_.markdown(f"{html.escape(r['name'])}")
        c2_.caption(f"{r['saved']:%d-%m-%Y %H:%M} | {r['size_kb']} KB")
        c3_.download_button("Download", r["path"].read_bytes(), file_name=r["name"], key=f"dl_{i}_{r['name']}")
st.caption("Figures come from the PDFs you uploaded plus any you typed. Interest is indicative. The analysis is a working paper for "
           "internal review, not a legal opinion.")
