"""
GSTR-1 category-wise (annual, from the table-wise read of the 12 GSTR-1 PDFs) vs GSTR-9 Table 4 / Table 5 category-wise.

Mapping follows GSTN's auto-population of GSTR-9 from GSTR-1 (GSTN presentation on GSTR-9):
  4A B2C          <- GSTR-1 5 (B2CL) + 7 (B2CS) + 9A (B2CL amendments) + 10 (B2C amendments)
  4B B2B          <- GSTR-1 4A
  4C Exports WP   <- GSTR-1 6A EXPWP          4D SEZ WP <- 6B SEZWP          4E Deemed exports <- 6C
  4F Advances     <- GSTR-1 11A - 11B (and their amendments)
  4I/4J, 5H/5I    <- GSTR-1 9B credit / debit notes
  4K/4L, 5J/5K    <- GSTR-1 9A / 9C amendments
  5A <- 6A EXPWOP   5B <- 6B SEZWOP   5C <- 4B (reverse charge supplies)   5D/5E/5F <- Table 8 exempted / nil / non-GST
The filed GSTR-1 PDF prints credit/debit notes and amendments only NET, so those are compared as one net figure:
  GSTR-9 (4J - 4I) + (5I - 5H)  vs  GSTR-1 9B (registered + unregistered), and
  GSTR-9 (4K - 4L) + (5J - 5K)  vs  GSTR-1 9A + 9C net differentials.
All amounts in paise.
"""
from __future__ import annotations

import pandas as pd

from . import g1_portal as G
from . import schema as S

HEADS = ["VALUE", "IGST", "CGST", "SGST", "CESS"]
G9COL = {"VALUE": "TXVAL", "IGST": "IGST", "CGST": "CGST", "SGST": "SGST", "CESS": "CESS"}
HEAD_NAME = {"VALUE": "Taxable value", "IGST": "IGST", "CGST": "CGST", "SGST": "SGST/UTGST", "CESS": "Cess"}

# key, GSTR-9 row(s) with sign, GSTR-1 tables with sign, description, value-only?
CATS = [
    ("4A", [("4A", 1)], [("5", 1), ("7", 1), ("9A_B2CL", 1), ("10", 1)], "B2C (unregistered)", "GSTR-1 5 + 7 + 9A(B2CL) + 10", False),
    ("4B", [("4B", 1)], [("4A", 1)], "B2B (registered)", "GSTR-1 4A", False),
    ("4C", [("4C", 1)], [("6A_EXPWP", 1)], "Exports with payment of tax", "GSTR-1 6A EXPWP", False),
    ("4D", [("4D", 1)], [("6B_SEZWP", 1)], "SEZ supplies with payment of tax", "GSTR-1 6B SEZWP", False),
    ("4E", [("4E", 1)], [("6C", 1)], "Deemed exports", "GSTR-1 6C", False),
    ("4F", [("4F", 1)], [("11A", 1), ("11B", -1), ("11A_AMD", 1), ("11B_AMD", -1)], "Advances - tax paid, invoice not issued",
     "GSTR-1 11A - 11B (incl. amendments)", False),
    ("CDN", [("4J", 1), ("4I", -1), ("5I", 1), ("5H", -1)], [("9B_CDNR", 1), ("9B_CDNUR", 1)], "Credit / debit notes (net)",
     "GSTR-1 9B CDNR + CDNUR (net)", False),
    ("AMD", [("4K", 1), ("4L", -1), ("5J", 1), ("5K", -1)],
     [("9A_B2B", 1), ("9A_B2BRC", 1), ("9A_EXP", 1), ("9A_SEZ", 1), ("9A_DE", 1), ("9C_CDNRA", 1), ("9C_CDNURA", 1)],
     "Amendments (net)", "GSTR-1 9A (except B2CL) + 9C net differentials", False),
    ("5A", [("5A", 1)], [("6A_EXPWOP", 1)], "Exports without payment (LUT)", "GSTR-1 6A EXPWOP", True),
    ("5B", [("5B", 1)], [("6B_SEZWOP", 1)], "SEZ supplies without payment", "GSTR-1 6B SEZWOP", True),
    ("5C", [("5C", 1)], [("4B", 1)], "Supplies where recipient pays tax (RCM)", "GSTR-1 4B", True),
    ("5D", [("5D", 1)], [("8_EXEMPTED", 1)], "Exempted", "GSTR-1 Table 8 - Exempted", True),
    ("5E", [("5E", 1)], [("8_NIL", 1)], "Nil rated", "GSTR-1 Table 8 - Nil", True),
    ("5F", [("5F", 1)], [("8_NONGST", 1)], "Non-GST supply", "GSTR-1 Table 8 - Non-GST", True),
]
G9_LABEL = {"4A": "Table 4A", "4B": "Table 4B", "4C": "Table 4C", "4D": "Table 4D", "4E": "Table 4E", "4F": "Table 4F",
            "CDN": "(4J - 4I) + (5I - 5H)", "AMD": "(4K - 4L) + (5J - 5K)", "5A": "Table 5A", "5B": "Table 5B", "5C": "Table 5C",
            "5D": "Table 5D", "5E": "Table 5E", "5F": "Table 5F"}


def gstr1_year(files: list[dict], fy: str):
    """{table key: {head: paise}} summed over the GSTR-1 months read table-wise, and the list of months used."""
    months = S.fy_months(fy)
    tot, used = {}, []
    for f in files:
        if f.get("type") != "GSTR1" or not f.get("g1_rows") or f.get("period") not in months:
            continue
        used.append(f["period"])
        summ = G._summarise(f["g1_rows"])
        # split rows missing on a month where the parent total is zero: treat as zero
        for tab, subs in (("6A", ("6A_EXPWP", "6A_EXPWOP")), ("6B", ("6B_SEZWP", "6B_SEZWOP"))):
            if tab not in summ:
                continue
            if all((summ[tab].get(c) or 0) == 0 for c in HEADS):
                for sb in subs:
                    summ.setdefault(sb, {c: 0 for c in HEADS})
            have = [sb for sb in subs if sb in summ]
            if len(have) == 1:   # one part printed: the other is the total less that part
                other = subs[1 - subs.index(have[0])]
                summ[other] = {c: (summ[tab].get(c) or 0) - (summ[have[0]].get(c) or 0) for c in HEADS}
        for key, r in summ.items():
            d = tot.setdefault(key, {c: 0 for c in HEADS})
            for c in HEADS:
                d[c] += r.get(c) or 0
    return tot, sorted(set(used))


def _g9(g9: pd.DataFrame, row: str, head: str):
    from .finder import G9_ROWS

    desc = dict(G9_ROWS).get(row)
    col = {"VALUE": "Value", "IGST": "IGST", "CGST": "CGST", "SGST": "SGST", "CESS": "Cess"}[head]
    if desc is None or desc not in g9.index or pd.isna(g9.loc[desc, col]):
        return None
    return int(round(float(g9.loc[desc, col]) * 100))


def reconcile(files: list[dict], g9: pd.DataFrame, fy: str) -> tuple[pd.DataFrame, list[dict], dict]:
    """Category table (for display/export), comparison rows (for the deviation list), and info."""
    g1, used = gstr1_year(files, fy)
    info = {"months": len(used), "complete": len(used) == 12}
    table, comps = [], []
    if not used or g9 is None or g9.isna().all().all():
        return pd.DataFrame(), [], info
    for key, g9rows, g1tabs, name, src, value_only in CATS:
        heads = ["VALUE"] if value_only else HEADS
        line = {"Category": name, "GSTR-9 row": G9_LABEL[key], "GSTR-1 source": src}
        for h in heads:
            a_parts = [(_g9(g9, r, h), sg) for r, sg in g9rows]
            present = [(v, sg) for v, sg in a_parts if v is not None]
            a = sum(v * sg for v, sg in present) if present else None
            missing_g1 = [t for t, _ in g1tabs if t not in g1]
            b = sum(sg * g1.get(t, {}).get(h, 0) for t, sg in g1tabs) if len(missing_g1) < len(g1tabs) else None
            if b is None and all(t in ("9A_B2CL", "10", "11A_AMD", "11B_AMD", "9A_B2BRC") for t in missing_g1):
                b = 0
            hn = HEAD_NAME[h]
            line[f"GSTR-1 {hn}"] = None if b is None else b / 100
            line[f"GSTR-9 {hn}"] = None if a is None else a / 100
            line[f"Difference {hn}"] = None if (a is None or b is None) else (a - b) / 100
            if a is not None and b is not None:
                comps.append({"cat": key, "name": name, "head": hn, "a": a, "b": b, "src": src, "g9row": G9_LABEL[key],
                              "value_only": value_only})
        table.append(line)
    return pd.DataFrame(table), comps, info
