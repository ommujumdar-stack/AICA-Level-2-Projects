"""
Detailed analysis of every deviation found by finder.find_deviations().

For each deviation it gives:
  headline, the figures, % difference, severity, how it links to other deviations (monthly rows that make
  up a year total, timing differences that reverse in a later month, tax paid under the wrong head,
  GSTR-9 differences split into their GSTR-1 and GSTR-3B parts), likely causes, how to verify,
  action, an indicative interest estimate, the law that applies and practical notes.

Interest is INDICATIVE: simple interest at 18% p.a. (Sec 50(1), N/N 13/2017-CT) from the day after the
GSTR-3B due date (20th of the next month, monthly filer) to the report date. It assumes the shortfall is
still unpaid and is paid in cash. It does not know about DRC-03 payments already made.
All money is handled in paise (integers).
"""
from __future__ import annotations

from datetime import date, timedelta

import pandas as pd

from . import schema as S

RATE = 0.18
HEAD_COLS = {"IGST": "IGST", "CGST": "CGST", "SGST/UTGST": "SGST", "Cess": "Cess"}
TAX_HEADS = ["IGST", "CGST", "SGST/UTGST", "Cess"]
HARD_LOCK_FROM = "2025-07"   # GSTN advisory 07-06-2025: auto-populated liability in GSTR-3B non-editable from Jul-2025


def inr(p) -> str:
    return "Rs " + S.fmt_inr(p)


def _paise(x) -> int:
    return int(round(float(x) * 100))


def interest(amount_p: int, start: date, end: date) -> int:
    """Simple interest at 18% p.a. in paise; days counted from start to end, both inclusive."""
    days = max(0, (end - start).days + 1)
    return int(round(amount_p * RATE * days / 365))


def _start(period: str) -> date:
    """Interest runs from the day after the GSTR-3B due date (20th of the next month)."""
    return S.due_3b(period) + timedelta(days=1)


def _lab2per(fy: str) -> dict:
    return {S.period_label(p): p for p in S.fy_months(fy)}


# --------------------------------------------------------------------------- text library
CAUSES = {
    "M1+": ["GSTR-3B was filed before all invoices of the month were in GSTR-1; the tax was then paid (or not) in a later month.",
            "Liability under-declared in GSTR-3B Table 3.1 (possible only before the July 2025 hard-lock, or if GSTR-1 was filed after GSTR-3B).",
            "Credit notes / advances adjusted in GSTR-3B but not reported in GSTR-1 (or reported in a different month).",
            "Invoices duplicated or wrongly reported in GSTR-1 (wrong value, wrong rate, wrong place of supply)."],
    "M1-": ["Invoices taxed in GSTR-3B but missing from GSTR-1 - your customers do not see them in GSTR-2B and lose ITC.",
            "Advance received taxed in GSTR-3B, or a shortfall of an earlier month paid in this month's GSTR-3B (catch-up).",
            "Reverse-charge purchases wrongly included in 3.1(a) instead of 3.1(d).",
            "Credit notes reported in GSTR-1 but not reduced in GSTR-3B."],
    "A1+": ["Monthly short payments not caught up later in the year (see the monthly rows listed under 'How it links')."],
    "A1-": ["Tax paid in GSTR-3B for supplies never reported in GSTR-1, or excess tax paid during the year."],
    "A2+": ["Additional liability found during annual reconciliation and declared in GSTR-9 Table 4 but not paid through GSTR-3B.",
            "Monthly GSTR-1 vs GSTR-3B short payments (the GSTR-1 part of this difference)."],
    "A2-": ["GSTR-9 Table 4 omits supplies that were taxed in GSTR-3B, or GSTR-3B paid more than the true liability."],
    "A3+": ["Supplies added in GSTR-9 that were never reported in GSTR-1 (found in books during annual reconciliation).",
            "Reverse-charge liability in GSTR-9 differs from GSTR-3B 3.1(d)."],
    "A3-": ["Supplies in GSTR-1 dropped or reduced in GSTR-9 Table 4 - only acceptable where backed by amendments / credit notes (Tables 10/11)."],
    "A4+": ["GSTR-9 Table 6A is auto-populated from filed GSTR-3Bs and cannot be edited - a difference usually means one uploaded GSTR-3B PDF "
            "is not the final filed version, a month is from another GSTIN/year, or a figure in the GSTR-3B table was typed or read differently."],
    "A4-": ["Same as above: Table 6A is auto-populated from GSTR-3B. Check that all 12 GSTR-3B PDFs are the filed versions."],
    "A5+": ["Tax payable in GSTR-9 Table 9 exceeds tax paid - additional liability not yet paid through DRC-03."],
    "A5-": ["More tax shown as paid than payable in Table 9 - usually a data entry error in Table 9 or excess payment."],
    "A6+": ["ITC visible in GSTR-2B not claimed - invoices received late, ineligible ITC (Sec 17(5)), ITC on hold, or simply missed.",
            "ITC of this year claimed in the next year is reported in 8C; if not reported there, 8D overstates the lapse."],
    "A6-": ["ITC availed exceeds what suppliers reported in GSTR-2B - supplier non-filing, wrong GSTIN, ITC claimed on books basis, "
            "or ITC of imports / RCM wrongly included in 8B."],
}
CAUSES.update({
    "M2+": ["Nil-rated / exempt / non-GST sales reported in GSTR-1 Table 8 but left out of GSTR-3B 3.1(c)/(e) (or put in 3.1(a)).",
            "Non-GST supplies (e.g. petroleum, alcohol) reported in one return only."],
    "M2-": ["Exempt supplies reported in GSTR-3B but not in GSTR-1 Table 8.",
            "Taxable supplies wrongly shown as exempt in GSTR-3B 3.1(c) - check 3.1(a) for the same month."],
    "H1+": ["HSN summary prepared from a different source than the invoice tables (e.g. accounting software HSN report).",
            "Credit notes reduced in the invoice tables (9B) but not in the HSN summary, or the reverse."],
    "H1-": ["Credit notes / amendments reflected in the HSN summary but not in the invoice tables, or invoices missing from the HSN summary.",
            "Nil-rated / exempt supplies left out of the HSN summary."],
})
CAUSES.update({
    "C+": ["The auto-populated GSTR-9 figure was edited upward (e.g. supplies found in books but missed in GSTR-1).",
           "Supplies classified differently: moved into this category from another (B2B / B2C, with / without payment, exempt / nil).",
           "Amendments made in GSTR-1 of April-November of the next year shown here instead of Tables 10 / 11."],
    "C-": ["The auto-populated GSTR-9 figure was edited downward.",
           "Supplies moved to another GSTR-9 category - see 'How it links' for an offsetting difference.",
           "Credit notes / amendments reported in GSTR-9 in a different row than the portal auto-populates."],
})
VERIFY = {
    "M1": ["Open the GSTR-1 for {period}: compare B2B, B2CL, B2CS, export and credit/debit note totals with the sales register.",
           "Open the GSTR-3B for {period}: check Table 3.1(a)/(b) against the same sales register.",
           "Compare the filing dates (ARN dates) of GSTR-1 and GSTR-3B for {period} - if GSTR-1 was filed later, the liability flows into a later GSTR-3B.",
           "Look at the next two months in this report for an opposite difference in the same head (timing difference)."],
    "A1": ["Check the monthly rows listed under 'How it links' - the year difference is their sum.",
           "If no monthly row is a deviation, small differences under the tolerance have accumulated - review the GSTR-1 vs GSTR-3B summary on the portal."],
    "A2": ["Reconcile GSTR-9 Table 4 with the 12 GSTR-3B (3.1(a)+(b)+(d)) - the split under 'How it links' shows how much comes from GSTR-1 and how much was added in GSTR-9.",
           "Check whether the additional liability was paid through DRC-03 (DRC-03 payments are not visible in GSTR-3B)."],
    "A3": ["Reconcile GSTR-9 Table 4 with the GSTR-1 summary for the year plus GSTR-3B 3.1(d).",
           "Check Tables 10 and 11 of GSTR-9 (amendments made in the next year) and keep the working papers."],
    "A4": ["Compare GSTR-9 Table 6A with the 12 GSTR-3B Table 4A figures in the GSTR-3B table of this report.",
           "Re-download any GSTR-3B whose month looks different and replace the PDF."],
    "A5": ["Open GSTR-9 Table 9 and compare 'tax payable' with 'paid through cash' + 'paid through ITC' head by head.",
           "Match with DRC-03 challans paid for the year."],
    "C": ["Open the 'GSTR-1 vs GSTR-9 by category' table: compare the GSTR-1 year total of the source tables with the GSTR-9 row.",
          "Download the GSTR-9 system-computed summary (auto-populated values) and compare with the filed GSTR-9 - the difference is a manual edit.",
          "Trace the edited amount to the books / GSTR-1 of the next year (April-November) and keep the working."],
    "M2": ["Compare GSTR-1 Table 8 (nil / exempted / non-GST) for {period} with GSTR-3B 3.1(c) and 3.1(e) and with the sales register.",
           "Exempt turnover drives the common-credit reversal under Rule 42 / 43 - check the reversal used the correct figure."],
    "H1": ["Open GSTR-1 for {period}: compare Table 12 (HSN summary) with the Total Liability line and the invoice tables (4, 5, 6, 7, 8, 9B).",
           "Re-run the HSN report from the books for the month and identify the HSN codes that differ."],
    "A6": ["Download GSTR-2B for all 12 months and compare with the ITC register (purchase-wise).",
           "Check 8C (ITC of this year claimed in April-November of the next year) is complete."],
}
ACTION = {
    "M1+": ["If the shortfall was not paid in a later month: pay through DRC-03 (Rule 142(2)) with interest u/s 50(1) at 18% before any notice.",
            "If GSTR-1 is overstated: amend in a later GSTR-1 (Table 9A/9C) - allowed only up to 30 November after the year end (Sec 37(3)).",
            "Keep the reconciliation ready: the portal may issue DRC-01B (Rule 88C) and the reply (Part B) is due within 7 days."],
    "M1-": ["Report the missing invoices in the next GSTR-1 (before 30 November after the year end) so customers get ITC.",
            "If the excess is genuine excess payment: claim refund (RFD-01, 'excess payment of tax', within 2 years - Sec 54(1)), "
            "or adjust only where the law/portal still allows."],
    "A1+": ["Clear the open monthly shortfalls (see monthly rows) through DRC-03 with interest before filing GSTR-9."],
    "A1-": ["Report missing invoices in GSTR-1 before 30 November after the year end, or claim refund of excess tax paid."],
    "A2+": ["Pay the unpaid part through DRC-03 with interest before filing GSTR-9; GSTR-9 itself does not collect tax.",
            "Keep the DRC-03 ARN with the GSTR-9 working papers (it is also asked for in GSTR-9C, if applicable)."],
    "A2-": ["Re-check GSTR-9 Table 4 for omitted supplies before filing. If GSTR-9 is already filed, record the reason in the working papers."],
    "A3+": ["Make sure the additional tax is paid (see 'GSTR-9 vs GSTR-3B'); report the supplies in GSTR-1 if the 30 November window is still open."],
    "A3-": ["Do not report less in GSTR-9 than in GSTR-1 unless backed by credit notes / amendments; document the reason."],
    "A4+": ["Replace the GSTR-3B PDF(s) that do not match the final filed version and run again before concluding."],
    "A4-": ["Replace the GSTR-3B PDF(s) that do not match the final filed version and run again before concluding."],
    "A5+": ["Pay the balance through DRC-03 with interest before filing GSTR-9."],
    "A5-": ["Correct Table 9 before filing; if filed, keep the explanation."],
    "A6+": ["Claim eligible ITC in GSTR-3B before 30 November after the year end (Sec 16(4)); after that it lapses.",
            "For ITC that is ineligible or not claimable, record the reason (8D lapses - it is not 'carried forward')."],
    "A6-": ["Reverse ITC not supported by GSTR-2B through DRC-03 (or GSTR-3B Table 4B) with interest u/s 50(3) at 18% if it was utilised.",
            "Follow up with suppliers to file / correct their GSTR-1 where the purchase is genuine."],
}
ACTION.update({
    "C+": ["If the increase is additional tax not reported in GSTR-1 / GSTR-3B: pay through DRC-03 with interest before filing GSTR-9.",
           "If it is only a re-classification, make sure the offsetting category is reduced by the same amount and record why."],
    "C-": ["Do not report less in GSTR-9 than GSTR-1 unless supported by credit notes / amendments; keep the reconciliation.",
           "If supplies were moved to another category, check the offsetting difference and record the reason."],
    "M2+": ["No tax impact by itself. Keep GSTR-9 Table 5 (5D/5E/5F) consistent with GSTR-1 and the books; correct the Rule 42/43 reversal if exempt turnover was understated."],
    "M2-": ["If taxable supplies were shown as exempt, pay the tax with interest through DRC-03; otherwise align GSTR-9 Table 5 with the books."],
    "H1+": ["Table 12 has no amendment table: record the reconciliation and correct the annual HSN summary in GSTR-9 Table 17."],
    "H1-": ["Table 12 has no amendment table: record the reconciliation and correct the annual HSN summary in GSTR-9 Table 17."],
})
LEGAL = {
    "M1": ["Sec 37 (GSTR-1)", "Sec 39 (GSTR-3B)", "Sec 50(1) interest 18%", "Rule 88C / DRC-01B", "Rule 142(2) DRC-03"],
    "A1": ["Sec 37", "Sec 39", "Sec 50(1)", "Rule 88C / DRC-01B"],
    "A2": ["Sec 44 (GSTR-9)", "Sec 39", "Sec 50(1)", "Rule 142(2) DRC-03"],
    "A3": ["Sec 44", "Sec 37(3) (amendment window)", "Rule 80"],
    "A4": ["Sec 44", "GSTR-9 Table 6A (auto-populated)"],
    "A5": ["Sec 44", "Sec 50(1)", "Rule 142(2) DRC-03"],
    "C": ["Sec 44 (GSTR-9)", "Rule 80", "GSTR-9 Tables 4 and 5 (auto-populated from GSTR-1)"],
    "M2": ["Sec 37", "Sec 39", "Rule 42 / 43 (exempt turnover)", "GSTR-9 Table 5"],
    "H1": ["Sec 37", "Rule 59 (GSTR-1 Table 12)", "GSTR-9 Table 17"],
    "A6": ["Sec 16(2)(aa) (ITC only if in GSTR-2B)", "Sec 16(4) (30 November time limit)", "Sec 50(3) interest 18%", "Rule 88D / DRC-01C"],
}


def _severity(row, d_abs, pct):
    higher = row["Risk"] == "Higher"
    big = d_abs >= 1_00_000_00 or (pct is not None and abs(pct) >= 10)
    if higher:
        return "High" if big else ("Medium" if d_abs >= 10_000_00 else "Low")
    if row["code"] == "A6":  # ITC lapse: money lost, not a demand risk
        return "Medium" if d_abs >= 1_00_000_00 else "Low"
    return "Medium" if d_abs >= 5_00_000_00 else "Low"


def _down(sev):
    return {"High": "Medium", "Medium": "Low", "Low": "Low"}[sev]


# --------------------------------------------------------------------------- main
def analyse(dev: pd.DataFrame, g1: pd.DataFrame, b3: pd.DataFrame, g9: pd.DataFrame, fy: str,
            files: list[dict] | None = None, as_of: date | None = None) -> dict:
    """Returns {"items": [...], "summary": {...}}. One item per deviation row, in the order of dev."""
    as_of = as_of or date.today()
    files = files or []
    l2p = _lab2per(fy)
    if dev is None or dev.empty:
        return {"items": [], "summary": _summary([], fy, g9, as_of, files)}
    devs = dev[dev["Result"] == "Deviation"].reset_index(drop=True)
    alls = dev
    m1 = alls[alls["code"] == "M1"]
    filed = {}
    for f in files:
        if f.get("type") in ("GSTR1", "GSTR3B") and f.get("period") and (f.get("meta") or {}).get("filed_on"):
            filed[(f["type"], f["period"])] = f["meta"]["filed_on"]
    items = []
    for i, r in devs.iterrows():
        code, head, period = r["code"], r["Head"], r["Period"]
        a, b, d = _paise(r["A (Rs)"]), _paise(r["B (Rs)"]), _paise(r["A - B (Rs)"])
        pct = (d / b * 100) if b else None
        key = code + ("+" if d > 0 else "-")
        sev = _severity(r, abs(d), pct)
        links, notes = [], []
        intr = None
        per = l2p.get(period)

        # ---------------------------------------------------------------- monthly
        if code == "M1":
            others = m1[(m1["Period"] == period) & (m1["Head"] != head)]
            tax_dev = others[(others["Head"].isin(TAX_HEADS)) & (others["Result"] == "Deviation")]
            if head == "Taxable value":
                if tax_dev.empty and not others.empty:
                    links.append("Only the taxable value differs - every tax head matches for this month. The difference carries no tax: "
                                 "usually nil-rated / exempt / non-GST supplies, or zero-rated supplies without payment, reported in one "
                                 "return's taxable table and in another table of the other return.")
                    sev = "Low"
                else:
                    links.append("Tax heads also differ this month - see their rows; the taxable value difference is the base of that tax difference.")
                    if b and len(tax_dev):
                        tax_d = sum(_paise(x) for x in tax_dev["A - B (Rs)"])
                        if d:
                            links.append(f"Implied tax rate on the difference: {tax_d / d * 100:.1f}% (total tax difference {inr(tax_d)} on value {inr(d)}).")
            else:
                # tax under wrong head: IGST vs CGST+SGST in opposite directions with equal total
                if head in ("IGST", "CGST", "SGST/UTGST"):
                    m = m1[(m1["Period"] == period) & (m1["Head"].isin(["IGST", "CGST", "SGST/UTGST"]))]
                    dd = {h: _paise(v) for h, v in zip(m["Head"], m["A - B (Rs)"])}
                    if len(dd) == 3 and dd["IGST"] and abs(dd["IGST"] + dd["CGST"] + dd["SGST/UTGST"]) <= max(100, abs(dd["IGST"]) // 100) \
                            and (dd["IGST"] > 0) != (dd["CGST"] > 0):
                        links.append(f"Total tax matches but the split differs: IGST {inr(dd['IGST'])} vs CGST+SGST "
                                     f"{inr(dd['CGST'] + dd['SGST/UTGST'])}. This is tax paid under the wrong head (place of supply / "
                                     f"inter- vs intra-state), not a short payment.")
                        notes.append("Wrong-head payment: pay under the correct head and claim refund of the wrong head - Sec 77 CGST Act / "
                                     "Sec 19 IGST Act; no interest is payable on the correct-head tax under Sec 19(2) IGST / Sec 77(2) CGST.")
                        sev = "Medium" if abs(d) >= 1_00_000_00 else "Low"
                        key = "wronghead"
                # timing: opposite difference in the next 1-2 months, same head
                if per and key != "wronghead":
                    ms = list(l2p.items())
                    idx = [p for _, p in ms].index(per)
                    later = [lab for lab, _ in ms[idx + 1: idx + 3]]
                    opp = m1[(m1["Head"] == head) & (m1["Period"].isin(later))]
                    offset, where = 0, []
                    for _, o in opp.iterrows():
                        od = _paise(o["A - B (Rs)"])
                        if od and (od > 0) != (d > 0):
                            offset += od
                            where.append(f"{o['Period']} ({inr(od)})")
                    if where:
                        covered = min(1.0, abs(offset) / abs(d))
                        links.append(f"Reverses in {', '.join(where)} - {covered * 100:.0f}% of this difference is offset later: a timing difference.")
                        if covered >= 0.9:
                            sev = _down(sev)
                        if d > 0:
                            last_lab = where[-1].split(" ")[0]
                            catch = S.due_3b(l2p[last_lab])
                            amt = min(abs(d), abs(offset))
                            start = _start(per)
                            intr = {"amount": interest(amt, start, catch), "principal": amt, "from": start, "to": catch,
                                    "basis": f"Delay only: tax of {inr(amt)} due by {S.due_3b(per):%d-%m-%Y}, paid in the GSTR-3B of {last_lab} "
                                             f"(due {catch:%d-%m-%Y}). Interest u/s 50(1) is still payable for the delay."}
                            rest = abs(d) - amt
                            if rest > 0:
                                intr["amount"] += interest(rest, start, as_of)
                                intr["basis"] += f" Balance {inr(rest)} treated as still unpaid to {as_of:%d-%m-%Y}."
                if d > 0 and intr is None and per and key != "wronghead":
                    start = _start(per)
                    intr = {"amount": interest(d, start, as_of), "principal": d, "from": start, "to": as_of,
                            "basis": f"Assumes {inr(d)} is still unpaid: 18% p.a. from {start:%d-%m-%Y} (day after the GSTR-3B due date) to {as_of:%d-%m-%Y}."}
            if per and per >= HARD_LOCK_FROM:
                notes.append("From the July 2025 period GSTR-3B Table 3 liability is auto-populated from GSTR-1/1A/IFF and cannot be edited "
                             "(GSTN advisory 07-06-2025). A difference in this period usually means GSTR-1 was filed after GSTR-3B, or "
                             "GSTR-1 was changed later - corrections go through GSTR-1A before GSTR-3B is filed.")
            if per:
                f1, f3 = filed.get(("GSTR1", per)), filed.get(("GSTR3B", per))
                if f1 and f3:
                    if f1 > f3:
                        links.append(f"GSTR-1 was filed on {f1:%d-%m-%Y}, after GSTR-3B ({f3:%d-%m-%Y}) - this explains a timing difference.")
                    else:
                        links.append(f"GSTR-1 filed {f1:%d-%m-%Y}, GSTR-3B filed {f3:%d-%m-%Y}.")
                if f3 and f3 > S.due_3b(per):
                    notes.append(f"GSTR-3B for {period} was filed late ({f3:%d-%m-%Y}, due {S.due_3b(per):%d-%m-%Y}) - interest on the "
                                 "cash portion and late fee apply regardless of this difference.")
            if d > 0 and key != "wronghead" and head != "Taxable value":
                notes.append("Rule 88C: the portal compares GSTR-1 and GSTR-3B liability each month and may issue DRC-01B. The amount/percentage "
                             "trigger is not notified; differences of any size should be reconciled.")

        # ---------------------------------------------------------------- year
        elif code == "A1":
            mm = m1[(m1["Head"] == head)]
            parts = [(o["Period"], _paise(o["A - B (Rs)"])) for _, o in mm.iterrows() if _paise(o["A - B (Rs)"])]
            if parts:
                tot = sum(p for _, p in parts)
                links.append("Made up of the monthly differences: " + "; ".join(f"{p} {inr(v)}" for p, v in parts) + f" = {inr(tot)}.")
                small = [p for p, v in parts if (mm[mm["Period"] == p]["Result"] == "Matches").any()]
                if small:
                    links.append(f"{len(small)} month(s) are under the tolerance individually but still add to the year total.")
            notes.append("Interest is computed on the monthly rows; it is not added again here.")
        elif code in ("A2", "A3"):
            c = HEAD_COLS[head]
            g1y = g1[c].dropna().apply(_paise).sum() if c in g1 else 0
            out3b = b3[f"3.1(a+b) {c}"].dropna().apply(_paise).sum()
            rcm3b = b3[f"3.1(d) RCM {c}"].dropna().apply(_paise).sum()
            r4n = _paise(r["A (Rs)"])
            part_g1 = int(g1y - out3b)
            part_9 = int(r4n - (g1y + rcm3b))
            if code == "A2":
                links.append(f"Split of the difference {inr(d)}: (a) GSTR-1 vs GSTR-3B for the year {inr(part_g1)} + (b) added in GSTR-9 "
                             f"beyond GSTR-1 and 3.1(d) {inr(part_9)}.")
                if part_g1 and part_9 and abs(part_g1 + part_9 - d) <= 100:
                    links.append("Part (a) is the 'GSTR-1 vs GSTR-3B (year)' deviation and part (b) the 'GSTR-9 vs GSTR-1' deviation - "
                                 "settle those and this one closes.")
                if d > 0:
                    start = _start(f"{int(fy[:4]) + 1}-03")
                    unpaid9 = max(0, part_9)
                    if unpaid9:
                        intr = {"amount": interest(unpaid9, start, as_of), "principal": unpaid9, "from": start, "to": as_of,
                                "basis": f"Indicative minimum on part (b) {inr(unpaid9)} only, from {start:%d-%m-%Y} (after the March GSTR-3B due date) "
                                         f"to {as_of:%d-%m-%Y}. Actual interest runs from each month the supply belongs to - higher. "
                                         "Part (a) interest is in the monthly rows."}
            else:
                amend = 0
                for k, sign in (("10 Amendments added (next FY)", 1), ("11 Amendments reduced (next FY)", -1)):
                    if k in g9.index and pd.notna(g9.loc[k, c]):
                        amend += sign * _paise(g9.loc[k, c])
                if amend:
                    links.append(f"GSTR-9 Tables 10/11 show net amendments of {inr(amend)} (made in the next year); "
                                 f"unexplained after amendments: {inr(d - amend)}.")
                links.append("This is part (b) of the 'GSTR-9 vs GSTR-3B (tax)' deviation, if present.")
        elif code == "A4":
            months_with = b3[f"4A ITC {HEAD_COLS[head]}"].notna().sum()
            links.append(f"GSTR-3B side is the sum of Table 4A for {months_with} month(s).")
        elif code == "A5":
            if d > 0:
                start = _start(f"{int(fy[:4]) + 1}-03")
                intr = {"amount": interest(d, start, as_of), "principal": d, "from": start, "to": as_of,
                        "basis": f"Indicative minimum: {inr(d)} from {start:%d-%m-%Y} to {as_of:%d-%m-%Y}. Do not add to the "
                                 "'GSTR-9 vs GSTR-3B' interest - it is the same tax seen from Table 9."}
        elif code == "A6":
            dl = S.itc_deadline(fy)
            if d > 0:
                left = (dl - as_of).days
                notes.append(f"ITC time limit for FY {fy}: {dl:%d-%m-%Y} (Sec 16(4)) - " +
                             (f"{left} day(s) left to claim eligible ITC." if left >= 0 else "passed; unclaimed ITC has lapsed."))
            else:
                notes.append("Rule 88D / DRC-01C compares ITC in GSTR-3B with GSTR-2B every return period; the 50th GST Council recommended "
                             "a trigger of more than Rs 25 lakh and more than 20% (not notified as of the last check).")
                intr_amt = abs(d)
                start = _start(f"{int(fy[:4]) + 1}-03")
                intr = {"amount": interest(intr_amt, start, as_of), "principal": intr_amt, "from": start, "to": as_of,
                        "basis": f"Indicative minimum, only if the excess ITC was utilised: {inr(intr_amt)} at 18% (Sec 50(3)) from "
                                 f"{start:%d-%m-%Y} to {as_of:%d-%m-%Y}. Actual interest runs from the month of utilisation."}

        if code == "C":
            same = devs[(devs["code"] == "C") & (devs["Head"] == head) & (devs.index != i)]
            for _, o in same.iterrows():
                od = _paise(o["A - B (Rs)"])
                if od == -d:
                    links.append(f"Offset by an equal and opposite difference in '{o['Check']}' ({inr(od)}) - the total matches; "
                                 "this is a classification difference between GSTR-9 rows, not a missing supply.")
                    sev = "Low"
            if "Credit / debit" in r["Check"] or "Amendments" in r["Check"]:
                links.append("The filed GSTR-1 PDF prints credit / debit notes and amendments only as net figures, so GSTR-9 is compared "
                             "on the same net basis: (4J - 4I) + (5I - 5H) and (4K - 4L) + (5J - 5K).")
        if code == "H1":
            sev = "Medium" if abs(d) >= 1_00_000_00 else "Low"
            links.append("Internal check of one GSTR-1: no other return is involved. A difference here usually explains nothing else in this report.")
        ck = "M1" if code == "M1" else code
        vparams = {"period": period}
        if key == "wronghead":
            causes = ["Place of supply wrongly determined (inter-state treated as intra-state or the reverse) in one of the two returns."]
            action = ["Correct the head in the next GSTR-1 (amendment) and pay under the correct head; claim refund of the wrong head (RFD-01)."]
        else:
            causes = CAUSES.get(key, [])
            action = ACTION.get(key, [])
        pct_txt = f"{pct:+.1f}% of {r['Source B']}" if pct is not None else "B is zero"
        headline = (f"{r['Check']} - {head}, {period}: {r['Source A']} {inr(a)} vs {r['Source B']} {inr(b)}; "
                    f"difference {inr(d)} ({pct_txt}).")
        items.append({
            "no": i + 1, "code": code, "check": r["Check"], "period": period, "head": head,
            "a_name": r["Source A"], "a": a, "b_name": r["Source B"], "b": b, "diff": d, "pct": pct,
            "risk": r["Risk"], "severity": sev, "headline": headline, "meaning": r["What it means"],
            "links": links, "causes": causes, "verify": [v.format(**vparams) for v in VERIFY.get(ck, [])],
            "action": action, "interest": intr, "legal": LEGAL.get(ck, []), "notes": notes,
        })
    order = {"High": 0, "Medium": 1, "Low": 2}
    items.sort(key=lambda x: (order[x["severity"]], x["risk"] != "Higher", -abs(x["diff"])))
    for n, x in enumerate(items, 1):
        x["no"] = n
    return {"items": items, "summary": _summary(items, fy, g9, as_of, files)}


def _summary(items, fy, g9, as_of, files):
    sev = {k: sum(1 for x in items if x["severity"] == k) for k in ("High", "Medium", "Low")}
    m1_short = sum(x["diff"] for x in items if x["code"] == "M1" and x["diff"] > 0 and x["head"] in TAX_HEADS
                   and not any("wrong head" in l for l in x["links"]))
    int_m1 = sum((x["interest"] or {}).get("amount", 0) for x in items if x["code"] == "M1")
    a2_9 = sum((x["interest"] or {}).get("principal", 0) for x in items if x["code"] == "A2")
    int_a2 = sum((x["interest"] or {}).get("amount", 0) for x in items if x["code"] == "A2")
    a6_lapse = sum(x["diff"] for x in items if x["code"] == "A6" and x["diff"] > 0)
    a6_excess = sum(-x["diff"] for x in items if x["code"] == "A6" and x["diff"] < 0)
    dates = [("ITC claim / GSTR-1 amendment time limit (Sec 16(4), 37(3))", S.itc_deadline(fy)),
             ("GSTR-9 / GSTR-9C due date", S.annual_return_due(fy))]
    y0 = int(fy[:4])
    if y0 >= 2024:
        due = S.annual_return_due(fy)
        dates.append(("Sec 74A: last date for a show cause notice, non-fraud cases (42 months from GSTR-9 due date)", date(due.year + 4, 6, 30)))
    else:
        dates.append(("Sec 73: time limit for a demand order, non-fraud cases (3 years from GSTR-9 due date)",
                      date(S.annual_return_due(fy).year + 3, 12, 31)))
    turnover_note = None
    k = "5N Total turnover"
    if g9 is not None and k in g9.index and pd.notna(g9.loc[k, "Value"]):
        t = _paise(g9.loc[k, "Value"])
        if t <= 2_00_00_000_00:
            turnover_note = "Turnover per GSTR-9 5N is Rs 2 crore or less - GSTR-9 is optional for this GSTIN."
        elif t > 5_00_00_000_00:
            turnover_note = "Turnover per GSTR-9 5N is above Rs 5 crore - GSTR-9C (self-certified reconciliation) is also required."
    return {"as_of": as_of, "fy": fy, "count": len(items), "severity": sev,
            "monthly_short": m1_short, "interest_monthly": int_m1,
            "gstr9_added": a2_9, "interest_gstr9": int_a2, "itc_lapse": a6_lapse, "itc_excess": a6_excess,
            "dates": [(n, d, (d - as_of).days) for n, d in dates], "turnover_note": turnover_note}
