"""
Final reading of one filed PDF = two independent readers + the return's own arithmetic.

  text reader  : the page as a word stream (two text engines that must agree, watermark removed)
  table reader : the page as ruled tables - one row at a time, columns by their headings

Per figure:
  Verified  both readers give the same amount, or the return's own total proves it (GSTR-3B 4C = 4A - 4B,
            GSTR-9 8D = 8A - (8B + 8C))
  Read      only one reader found it and nothing contradicts it
  Check     the readers differ; the table reader read it from a ruled cell under its column heading, so its
            amount is used, and both readings are shown next to the picture of the row
  Type it   a figure's cell also held stray text (e.g. a watermark), or the readers differ and neither can be
            trusted - left blank, never guessed
Every figure carries the page and row it came from, for the evidence picture.
"""
from __future__ import annotations

import io
import re

from . import readers as R
from . import schema as S
from . import table_reader as T

TEXT = {"GSTR3B": lambda d: R.read_3b_pdf(d), "GSTR1": lambda d: R.read_g1_pdf(d), "GSTR9": lambda d: R.read_g9_pdf(d, "FILED")}
TABLE = {"GSTR3B": T.read_3b, "GSTR1": T.read_g1, "GSTR9": lambda rows: T.read_g9(rows, "FILED")}
RELIABLE = ("table", "lines-by-column")


def _check_group(code: str) -> str | None:
    """Which arithmetic check proves this figure: ('ITC', head) for 3B 4A/4B, ('8', head) for GSTR-9 8A-8D."""
    m = re.match(r"G3B_ITC_(AVL|REV)_(\w+)$", code)
    if m:
        return m.group(2)
    m = re.match(r"G9FILED_8[ABCD]_(\w+)$", code)
    return m.group(1) if m else None


def _final_checks(kind, vals):
    """Re-run the return's own arithmetic on the final figures. Returns {head: True/False}."""
    out = {}
    if kind == "GSTR9":
        for h in ("IGST", "CGST", "SGST", "CESS"):
            g = {x: vals.get(f"G9FILED_{x}_{h}") for x in ("8A", "8B", "8C", "8D")}
            if None not in (g["8A"], g["8B"], g["8D"]):
                out[h] = abs(g["8A"] - g["8B"] - (g["8C"] or 0) - g["8D"]) <= 100
    return out


def combine(kind: str, data: bytes, rows: list[dict], text_res: dict | None = None) -> dict:
    tr = text_res or TEXT[kind](data)
    tf = dict(tr.get("fields") or {})
    t_withheld = set(tr.get("disagree") or [])
    gf, gev, gbad, gchecks = TABLE[kind](rows)
    codes = list(dict.fromkeys(list(gf) + list(tf) + list(t_withheld) + list(gbad)))
    final, status = {}, {}
    for code in codes:
        t, g = tf.get(code), gf.get(code)
        ev = (gev.get(code) or [None])[0]
        src = (ev or {}).get("source", "")
        grp = _check_group(code)
        proved = bool(grp and gchecks.get(grp))
        if code in gbad:
            status[code] = {"status": "Type it", "note": "The cell holding this figure also contains other text (often a watermark). "
                                                          "Read it from the picture and type it.", "ev": ev}
            continue
        if g is not None and t is not None and g == t:
            final[code] = g
            status[code] = {"status": "Verified", "note": "Both readers read the same amount.", "ev": ev}
        elif g is not None and src in RELIABLE and (t is None or proved):
            final[code] = g
            status[code] = {"status": "Verified" if proved else "Read",
                            "note": ("Proved by the return's own total." if proved else "Read from the table cell under its column heading."), "ev": ev}
        elif g is not None and t is not None and src in RELIABLE:
            final[code] = g
            status[code] = {"status": "Check", "note": f"The two readers differ: table cell {S.fmt_inr(g)}, text stream {S.fmt_inr(t)}. "
                                                       + ("The table cell is used - " if src == "table" else "The figure under its column (found from the column alignment) is used - ") + "confirm it against the picture.", "ev": ev, "alt": t}
        elif g is None and t is not None:
            final[code] = t
            status[code] = {"status": "Read", "note": "Read from the text of the page (both text engines agree).", "ev": ev}
        elif g is not None and t is None and src not in RELIABLE:
            status[code] = {"status": "Type it", "note": "Found only in a table without column lines, where the column is uncertain.", "ev": ev}
        else:
            status[code] = {"status": "Type it", "note": "The readers could not settle this figure.", "ev": ev,
                            "alt": t if t is not None else g}
    # the return's own arithmetic on the final figures: if it fails, the figures it covers are not used
    for h, ok in _final_checks(kind, final).items():
        if not ok:
            for x in ("8A", "8B", "8C", "8D"):
                c = f"G9FILED_{x}_{h}"
                if c in final:
                    final.pop(c)
                    status[c] = {**status.get(c, {}), "status": "Type it", "note": "Table 8 does not add up (8D should be 8A - (8B + 8C))."}
    # intra-state tax splits equally: CGST and SGST on the same line must match
    for pre in ("G3B_OUT", "G3B_RCM", "G3B_ITC_AVL", "G3B_ITC_REV", "G1", "G9FILED_4N", "G9FILED_6A"):
        c_, s_ = f"{pre}_CGST", f"{pre}_SGST"
        if c_ in final and s_ in final and abs(final[c_] - final[s_]) > 100:
            for c in (c_, s_):
                if status[c]["status"] != "Verified":
                    final.pop(c)
                    status[c] = {**status[c], "status": "Type it", "note": "CGST and SGST should be equal on this line but were read differently."}
    for code, st in status.items():
        if code in final and not st.get("ev"):
            st["ev"] = None
    meta = tr.get("meta") or {}
    return {"fields": final, "status": status, "meta": meta, "watermark": tr.get("watermark") or {}, "text_ok": tr.get("ok", False),
            "table_found": len(gf)}


def find_amount(rows_words, paise):
    """Best-effort page/position of a printed amount (for figures found only by the text reader)."""
    target = S.fmt_inr(paise / 100 if paise else 0, paise=False)
    for pi, words in rows_words:
        for w in words:
            if w["text"].replace(".00", "") == target or w["text"] == f"{target}.00":
                return {"page": pi, "bbox": (w["x0"] - 120, w["top"] - 2, w["x1"] + 4, w["bottom"] + 2), "label": "", "source": "text"}
    return None


def page_words(data):
    import pdfplumber

    out = []
    with pdfplumber.open(io.BytesIO(data)) as pdf:
        for pi, p in enumerate(pdf.pages):
            out.append((pi, p.extract_words()))
    return out
