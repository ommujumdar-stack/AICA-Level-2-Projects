"""
Table reader - the second, independent way of reading a filed return.

The text reader treats a page as a stream of words. This reader treats it as what the portal prints:
ruled tables. Each table row is read as one unit, so
  * a label that wraps over two or three lines inside its cell is joined back together,
  * every figure is taken from its own cell, and must be a clean number - a cell that also contains
    stray characters (a watermark landing on it) is rejected, never half-read,
  * the column a figure belongs to is decided by the column heading (Integrated / Central / State/UT /
    Cess / Taxable value), not by assumed order.
Watermark characters are removed first, using the same detection as the text reader.
Every figure keeps its page and row position so the app can show the exact row as evidence.
"""
from __future__ import annotations

import io
import re

from . import readers as R
from . import schema as S

NUMBER = re.compile(r"^\(?-?[\d,]+(?:\.\d{1,2})?\)?$")
AMOUNT = re.compile(r"^-?[\d,]+\.\d{2}$")      # without cell borders only a printed amount (with paise) counts as a figure


def _amt(word: str):
    t = word.replace("₹", "").strip()
    return S.to_paise(t) if AMOUNT.match(t) else None


def _norm(s: str) -> str:
    s = (s or "").lower().replace("&", " ")
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _num(cell: str):
    """Returns paise, 'dash' for a not-applicable cell, None for empty, or 'bad' for a polluted cell."""
    t = (cell or "").replace("\n", " ").replace("₹", "").replace("Rs.", "").replace("Rs", "").strip()
    if not t:
        return None
    if t in ("-", "--", "—", "NA", "N.A.", "N/A"):
        return "dash"
    t2 = t.replace(" ", "")
    if NUMBER.match(t2):
        neg = t2.startswith("(") and t2.endswith(")")
        v = S.to_paise(t2.strip("()"))
        return -v if neg else v
    if re.search(r"\d", t):
        return "bad"
    return None


def _head_key(h: str) -> str | None:
    n = _norm(h)
    if not n:
        return None
    if "payable" in n:
        return "PAY"
    if "cash" in n:
        return "CASH"
    itc = "itc" in n
    if "integrated" in n or n in ("igst",) or n.endswith(" igst"):
        return "ITC_IGST" if itc else "IGST"
    if "central" in n or n in ("cgst",) or n.endswith(" cgst"):
        return "ITC_CGST" if itc else "CGST"
    if "state" in n or "sgst" in n or "utgst" in n:
        return "ITC_SGST" if itc else "SGST"
    if "cess" in n:
        return "ITC_CESS" if itc else "CESS"
    if "taxable" in n or n in ("value", "total value", "turnover"):
        return "TXVAL"
    return None


# --------------------------------------------------------------------------- page -> rows
def read_rows(data: bytes) -> tuple[list[dict], dict]:
    """All table rows of the document, watermark removed.
    Row = {page, top, bottom, x0, x1, label, values: {head_key: paise|'dash'|'bad'}, cells: [...], header_keys: [...]}"""
    import pdfplumber

    import copy

    pdfium_pages = copy.deepcopy(R.pdfium_flags(data))
    rows: list[dict] = []
    removed = 0
    last_header: dict[int, list] = {}          # column count -> heading keys of the last table seen
    with pdfplumber.open(io.BytesIO(data)) as pdf:
        for pi, page in enumerate(pdf.pages):
            pchars = R._flag_plumber(list(page.chars))
            fchars = pdfium_pages[pi] if pi < len(pdfium_pages) else []
            R._merge_flags(pchars, fchars)
            wm = {id(c) for c in pchars if c["_wm"]}
            removed += len(wm)
            clean = page.filter(lambda o: not (o.get("object_type") == "char" and id(o) in wm))
            tables = clean.find_tables(table_settings={"vertical_strategy": "lines", "horizontal_strategy": "lines",
                                                       "snap_tolerance": 3, "join_tolerance": 3, "intersection_tolerance": 4})
            if tables:
                for t in sorted(tables, key=lambda t: t.bbox[1]):
                    rows.extend(_rows_from_table(t, pi, last_header))
            else:
                rows.extend(_rows_from_lines(clean, pi))
    return rows, {"chars_removed": removed}


def _rows_from_table(t, pi, last_header) -> list[dict]:
    out = []
    data = t.extract()
    ncol = max((len(r) for r in data), default=0)
    header_keys = last_header.get(ncol)          # a table continued from the previous page keeps its headings
    for ri, (cells, rowobj) in enumerate(zip(data, t.rows)):
        cells = [c if c is not None else "" for c in cells]
        keys = [_head_key(c) for c in cells]
        is_header = sum(k is not None for k in keys[1:]) >= 2 and not any(isinstance(_num(c), int) for c in cells[1:])
        if is_header:
            header_keys = keys
            last_header[ncol] = keys
            continue
        label_parts, values = [], {}
        for ci, c in enumerate(cells):
            v = _num(c)
            if v is None or (isinstance(v, str) and v not in ("dash", "bad")):
                if c.strip():
                    label_parts.append(c.replace("\n", " "))
                continue
            key = header_keys[ci] if header_keys and ci < len(header_keys) else None
            if key is None:
                if v == "bad":
                    label_parts.append(c.replace("\n", " "))
                continue
            values[key] = v
        bbox = rowobj.bbox
        out.append({"page": pi, "x0": bbox[0], "top": bbox[1], "x1": bbox[2], "bottom": bbox[3], "label": " ".join(label_parts),
                    "norm": _norm(" ".join(label_parts)), "values": values, "cells": cells, "header_keys": header_keys,
                    "source": "table" if header_keys else "table-no-heading"})
    return out


def _rows_from_lines(page, pi) -> list[dict]:
    """No ruled table on the page. Words are grouped into lines; a line that names two or more columns
    (Integrated / Central / State / Cess / Taxable ...) is a heading and starts a block.
    Columns are found from the amounts themselves: right-aligned amounts in one column share a right edge,
    so the right edges of all amounts in the block are clustered. When the number of clusters equals the
    number of headings, cluster i is heading i (left to right) - 'lines-by-column'. Otherwise the figures
    are kept but marked 'lines-uncertain', and the app never uses them unless the text reader agrees."""
    words = page.extract_words(keep_blank_chars=False, x_tolerance=1.5, y_tolerance=2)
    lines: list[list[dict]] = []
    for w in sorted(words, key=lambda w: (round(w["top"]), w["x0"])):
        if lines and abs(lines[-1][0]["top"] - w["top"]) <= 2.5:
            lines[-1].append(w)
        else:
            lines.append([w])
    blocks, cur = [], {"anchors": None, "lines": []}
    for ln in lines:
        ln.sort(key=lambda w: w["x0"])
        head = _heading_anchors(ln)
        if head:
            blocks.append(cur)
            cur = {"anchors": head, "lines": []}
        elif cur["lines"] and ln[0]["top"] - max(w["bottom"] for w in cur["lines"][-1]) > 60:
            # a large vertical gap ends the table: page footers / margin stamps far below are not table rows
            blocks.append(cur)
            cur = {"anchors": None, "lines": [ln]}
        else:
            cur["lines"].append(ln)
    blocks.append(cur)
    out = []
    for bl in blocks:
        anchors = bl["anchors"]
        edges = sorted(w["x1"] for ln in bl["lines"] for w in ln if _amt(w["text"]) is not None)
        clusters = []
        for e in edges:
            if clusters and e - clusters[-1][-1] <= 6:
                clusters[-1].append(e)
            else:
                clusters.append([e])
        centres = [sum(c) / len(c) for c in clusters]
        order = sorted(anchors, key=anchors.get) if anchors else []
        exact = bool(anchors) and len(centres) == len(order)
        for ln in bl["lines"]:
            toks = [(w, _amt(w["text"])) for w in ln]
            nums = [(w, v) for w, v in toks if v is not None]
            label = " ".join(w["text"] for w, v in toks if v is None)
            values, source = {}, "lines-in-order"
            if anchors and nums:
                if exact:
                    source = "lines-by-column"
                    for w, v in nums:
                        k = min(range(len(centres)), key=lambda i: abs(centres[i] - w["x1"]))
                        values[order[k]] = v
                else:
                    source = "lines-uncertain"
                    for (w, v), key in zip(nums, order[-len(nums):] if len(nums) <= len(order) else order):
                        values[key] = v
            else:
                values = {f"#{i}": v for i, (_, v) in enumerate(nums)}
            out.append({"page": pi, "x0": min(w["x0"] for w in ln), "top": min(w["top"] for w in ln), "x1": max(w["x1"] for w in ln),
                        "bottom": max(w["bottom"] for w in ln), "label": label, "norm": _norm(label), "values": values,
                        "cells": [w["text"] for w in ln], "header_keys": order or None, "source": source})
    merged = []
    for r in out:
        if merged and not r["values"] and merged[-1]["values"] and len(r["label"]) < 160 and not _looks_like_title(r["norm"]):
            m = merged[-1]
            m["label"] += " " + r["label"]
            m["norm"] = _norm(m["label"])
            m["bottom"] = r["bottom"]
            continue
        merged.append(r)
    return merged


def _looks_like_title(n: str) -> bool:
    return bool(re.match(r"^(\d+(\.\d+)?|pt [ivx]+)\b", n))


def _heading_anchors(ln) -> dict | None:
    """{key: x-centre} when this line is a column heading line."""
    text = " ".join(w["text"] for w in ln).lower()
    if any(_amt(w["text"]) is not None for w in ln):
        return None
    marks = {}
    for i, w in enumerate(ln):
        t = w["text"].lower().strip("/:")
        nxt = ln[i + 1]["text"].lower() if i + 1 < len(ln) else ""
        key = None
        if t in ("integrated", "igst"):
            key = "IGST"
        elif t in ("central", "cgst"):
            key = "CGST"
        elif t in ("state", "sgst", "sgst/utgst", "state/ut") and "SGST" not in marks:
            key = "SGST"
        elif t == "cess":
            key = "CESS"
        elif t in ("taxable",) or (t == "value" and "TXVAL" not in marks):
            key = "TXVAL"
        elif t == "payable":
            key = "PAY"
        elif t == "cash":
            key = "CASH"
        if key and key not in marks:
            marks[key] = (w["x0"] + w["x1"]) / 2 if key not in ("SGST",) or nxt not in ("tax",) else (w["x0"] + ln[i + 1]["x1"]) / 2
    return marks if len(marks) >= 2 and ("tax" in text or "cess" in text or "value" in text) else None


# --------------------------------------------------------------------------- row definitions per return
# (key, regex on the normalised label, must-not-contain, columns in printed order used only when there is no heading)
DEF_3B = [
    ("31a", r"outward taxable supplies other than zero rated", None, ["TXVAL", "IGST", "CGST", "SGST", "CESS"]),
    ("31b", r"outward taxable supplies zero rated", None, ["TXVAL", "IGST", "CESS"]),
    ("31c", r"other outward supplies nil rated", None, ["TXVAL"]),
    ("31d", r"inward supplies liable to reverse charge", r"other than 1|other than 1 2", ["TXVAL", "IGST", "CGST", "SGST", "CESS"]),
    ("31e", r"non gst outward supplies", None, ["TXVAL"]),
    ("4A1", r"import of goods", None, ["IGST", "CGST", "SGST", "CESS"]),
    ("4A2", r"import of services", None, ["IGST", "CGST", "SGST", "CESS"]),
    ("4A3", r"inward supplies liable to reverse charge other than 1", None, ["IGST", "CGST", "SGST", "CESS"]),
    ("4A4", r"inward supplies from isd", None, ["IGST", "CGST", "SGST", "CESS"]),
    ("4A5", r"all other itc", None, ["IGST", "CGST", "SGST", "CESS"]),
    ("4B1", r"as per rules? (38 )?42 (and )?43", None, ["IGST", "CGST", "SGST", "CESS"]),
    ("4B2", r"^(2 |b ?2 )?others$|^2 others", None, ["IGST", "CGST", "SGST", "CESS"]),
    ("4C", r"net itc available", None, ["IGST", "CGST", "SGST", "CESS"]),
]
DEF_G1 = [("TOT", r"total liability outward supplies other than reverse charge", None, ["TXVAL", "IGST", "CGST", "SGST", "CESS"])]
DEF_G9 = [
    ("4N", r"supplies and advances on which tax is to be paid", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("5N", r"total turnover including advances", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("6A", r"total amount of input tax credit availed through form gstr 3b", None, ["CGST", "SGST", "IGST", "CESS"]),
    ("7I", r"total itc reversed", None, ["CGST", "SGST", "IGST", "CESS"]),
    ("8A", r"itc as per gstr 2[ab]", None, ["CGST", "SGST", "IGST", "CESS"]),
    ("8B", r"itc as per sum total", None, ["CGST", "SGST", "IGST", "CESS"]),
    ("8C", r"itc on inward supplies other than imports .*(availed|received during)", None, ["CGST", "SGST", "IGST", "CESS"]),
    ("8D", r"difference a b c", None, ["CGST", "SGST", "IGST", "CESS"]),
    ("10", r"supplies tax declared through amendments.*net of debit notes", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("11", r"supplies tax reduced through amendments.*net of credit notes", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    # Table 4 / Table 5 category rows (compared with GSTR-1 category-wise)
    ("4A", r"supplies made to un ?registered persons b2c", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("4B", r"supplies made to registered persons b2b", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("4C", r"zero rated supply export on payment of tax", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("4D", r"supply to sezs? on payment of tax", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("4E", r"(^| )deemed exports?$", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("4F", r"advances on which tax has been paid but invoice has not been issued", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("4G", r"inward supplies on which tax is to be paid on reverse charge basis", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("4I", r"credit notes issued in respect of transactions specified in b to e", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("4J", r"debit notes issued in respect of transactions specified in b to e", None, ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("4K", r"supplies tax declared through amendments", r"net of", ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("4L", r"supplies tax reduced through amendments", r"net of", ["TXVAL", "CGST", "SGST", "IGST", "CESS"]),
    ("5A", r"zero rated supply export without payment of tax", None, ["TXVAL"]),
    ("5B", r"supply to sezs? without payment of tax", None, ["TXVAL"]),
    ("5C", r"supplies on which tax is to be paid by the recipient on reverse charge", None, ["TXVAL"]),
    ("5D", r"(^| )exempted$", None, ["TXVAL"]),
    ("5E", r"(^| )nil rated$", None, ["TXVAL"]),
    ("5F", r"non gst supply", None, ["TXVAL"]),
    ("5H", r"credit notes issued in respect of transactions specified in a to f", None, ["TXVAL"]),
    ("5I", r"debit notes issued in respect of transactions specified in a to f", None, ["TXVAL"]),
    ("5J", r"(^| )supplies declared through amendments", None, ["TXVAL"]),
    ("5K", r"(^| )supplies reduced through amendments", None, ["TXVAL"]),
]
T9_LABELS = {"IGST": r"^integrated tax$", "CGST": r"^central tax$", "SGST": r"^state ?ut tax$|^state tax ut tax$", "CESS": r"^cess$"}


def _match(rows, defs):
    """First row matching each definition -> {key: (values dict by head, row)}."""
    found = {}
    for key, pat, neg, cols in defs:
        for r in rows:
            if re.search(pat, r["norm"]) and not (neg and re.search(neg, r["norm"])):
                vals = dict(r["values"])
                if vals and all(k.startswith("#") for k in vals):        # no heading: use printed order
                    nums = [vals[k] for k in sorted(vals, key=lambda x: int(x[1:]))]
                    vals = dict(zip(cols, nums)) if len(nums) >= len(cols) else {}
                found[key] = (vals, r)
                break
    return found


def _ev(row):
    return {"page": row["page"], "bbox": (row["x0"], row["top"], row["x1"], row["bottom"]), "label": row["label"][:160],
            "source": row.get("source", "table")}


def read_3b(rows):
    f = _match(rows, DEF_3B)
    out, ev, bad = {}, {}, []

    def put(code, key, h, sign=1, acc=False):
        if key not in f or code in bad:
            return
        vals, row = f[key]
        v = vals.get(h)
        if v == "bad":
            bad.append(code)
            out.pop(code, None)
            ev[code] = [_ev(row)]   # where the polluted cell is, for the picture
            return
        if v is None or v == "dash":
            v = 0 if (v == "dash" or vals) else None
        if v is None:
            return
        out[code] = out.get(code, 0) + sign * v if acc else v
        ev.setdefault(code, []).append(_ev(row))

    for h in ("TXVAL", "IGST", "CGST", "SGST", "CESS"):
        put(f"G3B_OUT_{h}", "31a", h)
        if "31b" in f:
            put(f"G3B_OUT_{h}", "31b", h, acc=True)
    put("G3B_EXEMPT", "31c", "TXVAL")
    put("G3B_EXEMPT", "31e", "TXVAL", acc=True)
    for h in ("IGST", "CGST", "SGST", "CESS"):
        put(f"G3B_RCM_{h}", "31d", h)
        for k in ("4A1", "4A2", "4A3", "4A4", "4A5"):
            put(f"G3B_ITC_AVL_{h}", k, h, acc=True)
        for k in ("4B1", "4B2"):
            put(f"G3B_ITC_REV_{h}", k, h, acc=True)
    checks = {}
    if "4C" in f:   # the return's own arithmetic: 4C = 4A - 4B
        vals, _ = f["4C"]
        for h in ("IGST", "CGST", "SGST", "CESS"):
            c = vals.get(h)
            a, b = out.get(f"G3B_ITC_AVL_{h}"), out.get(f"G3B_ITC_REV_{h}")
            if isinstance(c, int) and a is not None and b is not None:
                checks[h] = (a - b == c)
    return out, ev, bad, checks


def read_g1(rows):
    f = _match(rows, DEF_G1)
    out, ev, bad = {}, {}, []
    if "TOT" in f:
        vals, row = f["TOT"]
        for h in ("TXVAL", "IGST", "CGST", "SGST", "CESS"):
            v = vals.get(h)
            if v == "bad":
                bad.append(f"G1_{h}")
                ev[f"G1_{h}"] = [_ev(row)]
            elif v is not None:
                out[f"G1_{h}"] = 0 if v == "dash" else v
                ev[f"G1_{h}"] = [_ev(row)]
    return out, ev, bad, {}


def read_g9(rows, ver="FILED"):
    f = _match(rows, DEF_G9)
    out, ev, bad = {}, {}, []
    for key, (vals, row) in f.items():
        cols = next(c for k, _, _, c in DEF_G9 if k == key)
        for h in cols:
            v = vals.get(h)
            code = f"G9{ver}_{key}_{h}"
            if v == "bad":
                bad.append(code)
                ev[code] = [_ev(row)]
            elif v is not None:
                out[code] = 0 if v == "dash" else v
                ev[code] = [_ev(row)]
    # Table 9: rows labelled Integrated Tax / Central Tax / State/UT Tax / Cess under a heading with 'payable'
    for r in rows:
        hk = r.get("header_keys") or []
        if "PAY" not in hk:
            continue
        for h, pat in T9_LABELS.items():
            if re.search(pat, r["norm"]) and f"G9{ver}_9P_{h}" not in out:
                vals = r["values"]
                pay = vals.get("PAY")
                rest = [v for k, v in vals.items() if k != "PAY"]
                if pay == "bad" or any(v == "bad" for v in rest):
                    bad += [f"G9{ver}_9P_{h}", f"G9{ver}_9D_{h}"]
                    ev[f"G9{ver}_9P_{h}"] = ev[f"G9{ver}_9D_{h}"] = [_ev(r)]
                    continue
                if isinstance(pay, int):
                    out[f"G9{ver}_9P_{h}"] = pay
                    out[f"G9{ver}_9D_{h}"] = sum(v for v in rest if isinstance(v, int))
                    ev[f"G9{ver}_9P_{h}"] = ev[f"G9{ver}_9D_{h}"] = [_ev(r)]
    checks = {}
    for h in ("CGST", "SGST", "IGST", "CESS"):
        k = {x: out.get(f"G9{ver}_{x}_{h}") for x in ("8A", "8B", "8C", "8D")}
        if None not in (k["8A"], k["8B"], k["8D"]):
            checks[h] = (k["8A"] - k["8B"] - (k["8C"] or 0) == k["8D"])
    return out, ev, bad, checks
