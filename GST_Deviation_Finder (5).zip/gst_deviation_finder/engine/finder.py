"""
GST Deviation Finder - engine.

1. read_pdf(): works out which return a PDF is (GSTR-1, GSTR-3B or GSTR-9) by running all three
   readers and keeping the one that recognises the PDF; returns its figures, period, GSTIN and FY.
2. build_tables(): puts every file's figures into three editable tables (GSTR-1 monthly, GSTR-3B
   monthly, GSTR-9 annual) in rupees.
3. find_deviations(): compares the tables and returns one row per comparison.

All arithmetic is done in paise (integers), so there are no rounding surprises.
"""
from __future__ import annotations

import math

import pandas as pd

from . import readers as R
from . import schema as S

HEADS = ["IGST", "CGST", "SGST", "CESS"]
HL = {"IGST": "IGST", "CGST": "CGST", "SGST": "SGST/UTGST", "CESS": "Cess"}
TYPE_LABEL = {"GSTR1": "GSTR-1", "GSTR3B": "GSTR-3B", "GSTR9": "GSTR-9"}

# columns of the three tables (rupees)
G1_COLS = ["Taxable value", "IGST", "CGST", "SGST", "Cess", "Table 8 Nil/Exempt/Non-GST",
           "Table 12 HSN value", "Table 12 HSN IGST", "Table 12 HSN CGST", "Table 12 HSN SGST", "Table 12 HSN Cess"]
B3_COLS = (["3.1(a+b) Taxable value", "3.1(a+b) IGST", "3.1(a+b) CGST", "3.1(a+b) SGST", "3.1(a+b) Cess",
            "3.1(c)+(e) Nil/Exempt/Non-GST",
            "3.1(d) RCM IGST", "3.1(d) RCM CGST", "3.1(d) RCM SGST", "3.1(d) RCM Cess",
            "4A ITC IGST", "4A ITC CGST", "4A ITC SGST", "4A ITC Cess"])
G9_ROWS = [("4A", "4A B2C supplies"), ("4B", "4B B2B supplies"), ("4C", "4C Exports with payment"), ("4D", "4D SEZ with payment"),
           ("4E", "4E Deemed exports"), ("4F", "4F Advances (tax paid, no invoice)"), ("4G", "4G Inward supplies under RCM"),
           ("4I", "4I Credit notes (-)"), ("4J", "4J Debit notes (+)"), ("4K", "4K Amendments (+)"), ("4L", "4L Amendments (-)"),
           ("4N", "4N Tax payable on outward supplies (incl. RCM)"),
           ("5A", "5A Exports without payment"), ("5B", "5B SEZ without payment"), ("5C", "5C Supplies - recipient pays (RCM)"),
           ("5D", "5D Exempted"), ("5E", "5E Nil rated"), ("5F", "5F Non-GST"), ("5H", "5H Credit notes (-)"), ("5I", "5I Debit notes (+)"),
           ("5J", "5J Amendments (+)"), ("5K", "5K Amendments (-)"), ("5N", "5N Total turnover"),
           ("6A", "6A ITC availed through GSTR-3B"), ("8A", "8A ITC as per GSTR-2B"), ("8B", "8B ITC availed (6B + 6H)"),
           ("8C", "8C ITC availed in next FY"), ("8D", "8D Difference 8A - (8B + 8C)"),
           ("9P", "9 Tax payable"), ("9D", "9 Tax paid (cash + ITC)"),
           ("10", "10 Amendments added (next FY)"), ("11", "11 Amendments reduced (next FY)")]
G9_COLS = ["Value", "IGST", "CGST", "SGST", "Cess"]

_G1_MAP = {"G1_TXVAL": "Taxable value", "G1_IGST": "IGST", "G1_CGST": "CGST", "G1_SGST": "SGST", "G1_CESS": "Cess",
           "G1_NIL": "Table 8 Nil/Exempt/Non-GST", "G1_HSN_VALUE": "Table 12 HSN value", "G1_HSN_IGST": "Table 12 HSN IGST",
           "G1_HSN_CGST": "Table 12 HSN CGST", "G1_HSN_SGST": "Table 12 HSN SGST", "G1_HSN_CESS": "Table 12 HSN Cess",
           "G1_TOTVAL": None}
_B3_MAP = {"G3B_OUT_TXVAL": "3.1(a+b) Taxable value", **{f"G3B_OUT_{h}": f"3.1(a+b) {HL[h].split('/')[0] if h != 'CESS' else 'Cess'}" for h in HEADS},
           **{f"G3B_RCM_{h}": f"3.1(d) RCM {HL[h].split('/')[0] if h != 'CESS' else 'Cess'}" for h in HEADS},
           **{f"G3B_ITC_AVL_{h}": f"4A ITC {HL[h].split('/')[0] if h != 'CESS' else 'Cess'}" for h in HEADS},
           "G3B_EXEMPT": "3.1(c)+(e) Nil/Exempt/Non-GST"}


# --------------------------------------------------------------------------- reading
def read_pdf(data: bytes, name: str = "") -> dict:
    """Recognise and read one filed PDF with both readers (see engine/reader.py). Never guesses:
    an unrecognised PDF gets type None, an uncertain figure is left blank with the reason."""
    from . import g1_portal as G1P
    from . import reader as RD
    from . import table_reader as T

    # the portal's own GSTR-1 layout: read table by table
    try:
        g1r = G1P.parse(data)
    except Exception:  # noqa: BLE001 - fall back to the general readers
        g1r = None
    if g1r and "TOTAL" in g1r["tables"]:
        fields, fst, notes = G1P.figures(g1r)
        meta = g1r["meta"]
        period = None
        if meta.get("month") and meta.get("fy"):
            y0 = int(meta["fy"][:4])
            period = f"{y0 + (meta['month'] < 4)}-{meta['month']:02d}"
        check = [c for c, v in fst.items() if v["status"] == "Check"]
        msg = "" if period else "Financial year / tax period not found on the PDF - the month could not be placed."
        return {"name": name, "type": "GSTR1", "status": "Read - table-wise" + (f", {len(check)} to glance at" if check else ""),
                "fields": fields, "withheld": [], "check": check, "fstatus": fst, "meta": meta, "period": period, "fy": meta.get("fy"),
                "gstin": meta.get("gstin"), "message": msg, "watermark": {}, "checks": notes, "g1_rows": g1r["rows"]}

    try:
        rows, tinfo = T.read_rows(data)
    except Exception:  # noqa: BLE001 - an unreadable table layer still leaves the text reader
        rows, tinfo = [], {}
    results = {}
    for kind in ("GSTR3B", "GSTR1", "GSTR9"):
        text_res = RD.TEXT[kind](data)
        if "no text layer" in (text_res.get("message") or ""):
            return {"name": name, "type": None, "status": "Scanned PDF - no text to read", "fields": {}, "withheld": [], "check": [],
                    "fstatus": {}, "meta": {}, "message": text_res["message"], "watermark": {}, "checks": []}
        results[kind] = RD.combine(kind, data, rows, text_res)
    best = max(results, key=lambda k: len(results[k]["fields"]) + 0.5 * sum(1 for s in results[k]["status"].values() if s["status"] == "Type it"))
    res = results[best]
    if len(res["fields"]) < 3:
        return {"name": name, "type": None, "status": "Not recognised", "fields": {}, "withheld": [], "check": [], "fstatus": {},
                "meta": res.get("meta") or {},
                "message": "This PDF does not look like a filed GSTR-1, GSTR-3B or GSTR-9 from the portal. Its figures can be typed in the tables.",
                "watermark": {}, "checks": []}
    # evidence position for figures found only in the text stream
    words = None
    for code, st in res["status"].items():
        if code in res["fields"] and not st.get("ev"):
            words = words or RD.page_words(data)
            st["ev"] = RD.find_amount(words, res["fields"][code])
    meta = dict(res.get("meta") or {})
    fd = filing_date(data)
    if fd:
        meta["filed_on"] = fd
    period = None
    if best in ("GSTR1", "GSTR3B") and meta.get("month") and meta.get("fy"):
        y0 = int(meta["fy"][:4])
        m = meta["month"]
        period = f"{y0 + (m < 4)}-{m:02d}"
    withheld = [c for c, s in res["status"].items() if s["status"] == "Type it"]
    check = [c for c, s in res["status"].items() if s["status"] == "Check"]
    status = "Read" if not withheld and not check else (
        f"Read - {len(withheld)} to type" if withheld and not check else
        f"Read - {len(check)} to glance at" if check and not withheld else f"Read - {len(withheld)} to type, {len(check)} to glance at")
    wm = res.get("watermark") or {}
    if tinfo.get("chars_removed") and not wm.get("chars_removed"):
        wm = {"chars_removed": tinfo["chars_removed"], "sample": ""}
    return {"name": name, "type": best, "status": status, "fields": res["fields"], "withheld": withheld, "check": check,
            "fstatus": res["status"], "meta": meta, "period": period, "fy": meta.get("fy"), "gstin": meta.get("gstin"),
            "message": "", "watermark": wm, "checks": []}


def filing_date(data: bytes):
    """Date of filing / ARN date printed on the filed return, if any (used to explain timing differences)."""
    import re
    from datetime import date

    try:
        text = R.extract_clean_text(data)[0]
    except Exception:  # noqa: BLE001
        return None
    m = re.search(r"(?:date\s+of\s+ARN|ARN\s+date|date\s+of\s+filing|filing\s+date|filed\s+on)\s*[:\-]?\s*(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})",
                  text, re.I)
    if not m:
        return None
    try:
        return date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    except ValueError:
        return None


_HEAD_TXT = {"TXVAL": "Taxable value", "IGST": "IGST", "CGST": "CGST", "SGST": "SGST/UTGST", "CESS": "Cess"}


def field_label(code: str) -> str:
    """Readable name of a field code, e.g. G3B_OUT_IGST -> 'GSTR-3B 3.1(a+b) IGST'."""
    if code == "G1_TOTVAL":
        return "GSTR-1 Total Liability value (incl. Table 8)"
    if code == "G1_TXVAL":
        return "GSTR-1 taxable value (Total Liability less Table 8)"
    if code in _G1_MAP:
        return f"GSTR-1 {_G1_MAP[code]}" if _G1_MAP[code].startswith("Table") else f"GSTR-1 total liability - {_G1_MAP[code]}"
    if code in _B3_MAP:
        return "GSTR-3B " + _B3_MAP[code]
    if code.startswith("G9FILED_"):
        _, row, col = code.split("_", 2)
        desc = dict(G9_ROWS).get(row, f"Table {row}")
        return f"GSTR-9 {desc} - {_HEAD_TXT.get(col, col)}"
    f = {**S.all_monthly_fields(), **S.all_annual_fields()}.get(code)
    return f.label if f else code


# --------------------------------------------------------------------------- tables
def months(fy: str) -> list[str]:
    return S.fy_months(fy)


def label(period: str) -> str:
    return S.period_label(period)


def build_tables(files: list[dict], fy: str) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Three tables in rupees; blank (NaN) where nothing was read."""
    ms = months(fy)
    g1 = pd.DataFrame(index=[label(p) for p in ms], columns=G1_COLS, dtype=float)
    b3 = pd.DataFrame(index=[label(p) for p in ms], columns=B3_COLS, dtype=float)
    g9 = pd.DataFrame(index=[d for _, d in G9_ROWS], columns=G9_COLS, dtype=float)
    for f in files:
        if f.get("type") in ("GSTR1", "GSTR3B") and f.get("period") in ms:
            row = label(f["period"])
            tab, mp = (g1, _G1_MAP) if f["type"] == "GSTR1" else (b3, _B3_MAP)
            for code, v in f["fields"].items():
                if mp.get(code):
                    tab.loc[row, mp[code]] = v / 100
        elif f.get("type") == "GSTR9":
            for code, v in f["fields"].items():
                _, row, col = code.split("_", 2)  # G9FILED_4N_IGST
                desc = dict(G9_ROWS).get(row)
                c = {"TXVAL": "Value", "IGST": "IGST", "CGST": "CGST", "SGST": "SGST", "CESS": "Cess"}[col]
                if desc:
                    g9.loc[desc, c] = v / 100
    for t in (g1, b3, g9):
        t.index.name = "Month" if t is not g9 else "GSTR-9 table"
    return g1, b3, g9


# --------------------------------------------------------------------------- checks
def _p(x) -> int | None:
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return None
    return S.to_paise(x)


def _sum(vals):
    v = [x for x in vals if x is not None]
    return sum(v) if v else None


MEANING = {
    "M1+": "GSTR-1 shows more tax than was paid through GSTR-3B - possible short payment; interest under Sec 50 runs.",
    "M1-": "GSTR-3B paid more than GSTR-1 reports - excess payment, or invoices missing from GSTR-1 (buyers lose credit).",
    "A1+": "Over the year, GSTR-1 reports more tax than GSTR-3B paid - pay the shortfall by DRC-03 with interest.",
    "A1-": "Over the year, GSTR-3B paid more than GSTR-1 reports - check for missing invoices in GSTR-1 or adjust the excess.",
    "A2+": "GSTR-9 declares more tax than was paid in GSTR-3B - payable by DRC-03 with interest before filing GSTR-9.",
    "A2-": "GSTR-3B paid more than GSTR-9 declares - check Table 4 of GSTR-9.",
    "A3+": "GSTR-9 Table 4 is higher than GSTR-1 - tax added in the annual return; check it was paid (see GSTR-9 vs GSTR-3B) and keep the reason.",
    "A3-": "GSTR-9 Table 4 is lower than GSTR-1 - supplies dropped from the annual return; check Tables 10/11.",
    "A4+": "ITC in GSTR-9 is higher than GSTR-3B - check Table 6A1 (prior-year ITC) and manual edits.",
    "A4-": "ITC in GSTR-9 is lower than GSTR-3B - a manual edit; record why.",
    "A5+": "GSTR-9 Table 9 shows tax payable not fully paid - pay by DRC-03 with interest.",
    "A5-": "GSTR-9 Table 9 shows more paid than payable - check the figures.",
    "A6+": "ITC in GSTR-2B was not availed - it lapses after 30 November of the next year unless claimed.",
    "A6-": "ITC availed is more than GSTR-2B - likely to be questioned in scrutiny; reverse unless supported.",
    "C+": "GSTR-9 shows more in this category than the 12 GSTR-1s - the auto-populated figure was increased, or supplies were moved here from another category.",
    "C-": "GSTR-9 shows less in this category than the 12 GSTR-1s - the auto-populated figure was reduced, or supplies were moved to another category.",
    "M2+": "GSTR-1 Table 8 shows more nil/exempt/non-GST supplies than GSTR-3B 3.1(c)+(e) - exempt turnover under-reported in GSTR-3B.",
    "M2-": "GSTR-3B 3.1(c)+(e) shows more nil/exempt/non-GST supplies than GSTR-1 Table 8.",
    "H1+": "GSTR-1 HSN summary (Table 12) is higher than the return's Total Liability - HSN summary and invoice tables do not agree.",
    "H1-": "GSTR-1 HSN summary (Table 12) is lower than the return's Total Liability - HSN summary and invoice tables do not agree.",
}
CHECK_NAME = {
    "M1": "GSTR-1 vs GSTR-3B (monthly)", "A1": "GSTR-1 vs GSTR-3B (year)", "A2": "GSTR-9 vs GSTR-3B (tax)",
    "A3": "GSTR-9 vs GSTR-1 (tax)", "A4": "GSTR-9 vs GSTR-3B (ITC)", "A5": "GSTR-9 Table 9 payable vs paid",
    "A6": "GSTR-9 Table 8D (ITC in 2B not availed)", "M2": "GSTR-1 vs GSTR-3B (nil/exempt/non-GST)",
    "H1": "GSTR-1 HSN (Table 12) vs Total Liability", "C": "GSTR-9 vs GSTR-1 by category",
}


def find_deviations(g1: pd.DataFrame, b3: pd.DataFrame, g9: pd.DataFrame, tolerance: float = 1.0,
                    files: list[dict] | None = None, fy: str | None = None) -> pd.DataFrame:
    """One row per comparison made. 'Result' is Deviation / Matches / Not compared."""
    tol = S.to_paise(tolerance)
    rows = []

    def add(check, period, head, a_name, a, b_name, b, risky_when_positive=True, extra="", label=None):
        if a is None or b is None:
            return
        d = a - b
        dev = abs(d) > tol
        key = check + ("+" if d > 0 else "-")
        rows.append({"Check": label or CHECK_NAME[check], "code": check, "Period": period, "Head": head,
                     "Source A": a_name, "A (Rs)": a / 100, "Source B": b_name, "B (Rs)": b / 100, "A - B (Rs)": d / 100,
                     "Result": "Deviation" if dev else "Matches",
                     "Risk": ("Lower" if risky_when_positive is None else ("Higher" if (d > 0) == risky_when_positive else "Lower")) if dev else "",
                     "What it means": (MEANING.get(key, "") + (" " + extra if extra else "")) if dev else ""})

    def cell(t, r, c):
        return _p(t.loc[r, c]) if (r in t.index and c in t.columns) else None

    # M1 monthly GSTR-1 vs GSTR-3B 3.1(a+b); M2 nil/exempt; H1 GSTR-1 HSN vs total liability
    for m in g1.index:
        if not g1.loc[m, G1_COLS[:5]].isna().all():
            add("H1", m, "Taxable value", "GSTR-1 Table 12 HSN value", cell(g1, m, "Table 12 HSN value"), "GSTR-1 Total Liability value",
                None if cell(g1, m, "Taxable value") is None else cell(g1, m, "Taxable value") + (cell(g1, m, "Table 8 Nil/Exempt/Non-GST") or 0),
                risky_when_positive=None)
            for h, c in (("IGST", "IGST"), ("CGST", "CGST"), ("SGST/UTGST", "SGST"), ("Cess", "Cess")):
                add("H1", m, h, "GSTR-1 Table 12 HSN", cell(g1, m, f"Table 12 HSN {c}"), "GSTR-1 Total Liability", cell(g1, m, c),
                    risky_when_positive=None)
        if g1.loc[m, G1_COLS[:5]].isna().all() or b3.loc[m, B3_COLS[:5]].isna().all():
            continue
        add("M2", m, "Nil/Exempt/Non-GST", "GSTR-1 Table 8", cell(g1, m, "Table 8 Nil/Exempt/Non-GST"), "GSTR-3B 3.1(c)+(e)",
            cell(b3, m, "3.1(c)+(e) Nil/Exempt/Non-GST"))
        add("M1", m, "Taxable value", "GSTR-1", cell(g1, m, "Taxable value"), "GSTR-3B 3.1(a+b)", cell(b3, m, "3.1(a+b) Taxable value"))
        for h, c in (("IGST", "IGST"), ("CGST", "CGST"), ("SGST/UTGST", "SGST"), ("Cess", "Cess")):
            add("M1", m, h, "GSTR-1", cell(g1, m, c), "GSTR-3B 3.1(a+b)", cell(b3, m, f"3.1(a+b) {c}"))

    # year totals (only months present in both, so a missing month is not reported as a deviation)
    both = [m for m in g1.index if not g1.loc[m, G1_COLS[:5]].isna().all() and not b3.loc[m, B3_COLS[:5]].isna().all()]
    yr = lambda t, c, ms=None: _sum([cell(t, m, c) for m in (ms if ms is not None else t.index)])  # noqa: E731
    for h, c in (("IGST", "IGST"), ("CGST", "CGST"), ("SGST/UTGST", "SGST"), ("Cess", "Cess")):
        add("A1", "Year", h, f"GSTR-1 ({len(both)} months)", yr(g1, c, both), f"GSTR-3B 3.1(a+b) ({len(both)} months)", yr(b3, f"3.1(a+b) {c}", both))

    # GSTR-9 comparisons (use all months of each return)
    has9 = not g9.isna().all().all()
    # annual GSTR-9 checks add up 12 months; with a month missing the sum is short and would show a false deviation
    full_b3 = all(not b3.loc[m, B3_COLS[:5]].isna().all() for m in b3.index)
    full_g1 = all(not g1.loc[m, G1_COLS[:5]].isna().all() for m in g1.index)
    if has9:
        r4n, r6a, r9p, r9d = (dict(G9_ROWS)[k] for k in ("4N", "6A", "9P", "9D"))
        r10, r11 = dict(G9_ROWS)["10"], dict(G9_ROWS)["11"]
        for h, c in (("IGST", "IGST"), ("CGST", "CGST"), ("SGST/UTGST", "SGST"), ("Cess", "Cess")):
            out3b, rcm3b = yr(b3, f"3.1(a+b) {c}"), yr(b3, f"3.1(d) RCM {c}")
            b3_total = None if out3b is None else out3b + (rcm3b or 0)
            if full_b3:
                add("A2", "Year", h, "GSTR-9 4N", cell(g9, r4n, c), "GSTR-3B 3.1(a+b) + 3.1(d)", b3_total)
            g1y = yr(g1, c)
            amend = (cell(g9, r10, c) or 0) - (cell(g9, r11, c) or 0)
            if full_g1 and full_b3:
                add("A3", "Year", h, "GSTR-9 4N", cell(g9, r4n, c), "GSTR-1 + GSTR-3B 3.1(d)", None if g1y is None else g1y + (rcm3b or 0),
                risky_when_positive=False,
                extra=(f"Tables 10/11 show net amendments of Rs {S.fmt_inr(amend)} that may explain part of it." if amend else ""))
            if full_b3:
                add("A4", "Year", h, "GSTR-9 6A", cell(g9, r6a, c), "GSTR-3B 4A (12 months)", yr(b3, f"4A ITC {c}"))
            add("A5", "Year", h, "GSTR-9 Table 9 payable", cell(g9, r9p, c), "GSTR-9 Table 9 paid", cell(g9, r9d, c))
            r8a, r8b, r8c = (dict(G9_ROWS)[k] for k in ("8A", "8B", "8C"))
            a8, b8, c8 = cell(g9, r8a, c), cell(g9, r8b, c), cell(g9, r8c, c)
            if a8 is not None and b8 is not None:
                add("A6", "Year", h, "GSTR-9 8A (GSTR-2B)", a8, "8B + 8C (availed)", b8 + (c8 or 0), risky_when_positive=False)
    # GSTR-9 Table 4 / 5 vs GSTR-1 category-wise (needs all 12 GSTR-1 read table-wise)
    if files and fy and has9:
        from . import category as CT

        _, comps, info = CT.reconcile(files, g9, fy)
        if info["complete"]:
            for c in comps:
                add("C", "Year", c["head"], f"GSTR-9 {c['g9row']}", c["a"], c["src"], c["b"],
                    risky_when_positive=None if c["value_only"] else False, label=f"GSTR-9 vs GSTR-1: {c['name']}")
    out = pd.DataFrame(rows)
    if not out.empty:
        out["_o"] = out["Result"].map({"Deviation": 0, "Matches": 1})
        out["_r"] = out["Risk"].map({"Higher": 0, "Lower": 1}).fillna(2)
        out["_a"] = -out["A - B (Rs)"].abs()
        out = out.sort_values(["_o", "_r", "_a"]).drop(columns=["_o", "_r", "_a"]).reset_index(drop=True)
    return out


def coverage(files: list[dict], fy: str) -> dict:
    """Which months / returns are present, and identity problems (mixed GSTINs or years)."""
    ms = months(fy)
    have = {t: sorted({f["period"] for f in files if f.get("type") == t and f.get("period") in ms}) for t in ("GSTR1", "GSTR3B")}
    missing = {t: [label(p) for p in ms if p not in have[t]] for t in have}
    gstins = sorted({f["gstin"] for f in files if f.get("gstin")})
    fys = sorted({f["fy"] for f in files if f.get("fy")})
    dup = {}
    for f in files:
        if f.get("type") in ("GSTR1", "GSTR3B") and f.get("period"):
            dup.setdefault((f["type"], f["period"]), []).append(f["name"])
    dups = {f"{TYPE_LABEL[t]} {label(p)}": n for (t, p), n in dup.items() if len(n) > 1}
    return {"missing": missing, "gstins": gstins, "fys": fys, "has9": any(f.get("type") == "GSTR9" for f in files), "duplicates": dups}


def guess_fy(files: list[dict]) -> str:
    fys = [f["fy"] for f in files if f.get("fy")]
    return max(set(fys), key=fys.count) if fys else "2025-26"


def to_excel(dev: pd.DataFrame, g1: pd.DataFrame, b3: pd.DataFrame, g9: pd.DataFrame, files: list[dict], header: str,
             analysis: dict | None = None, extra: list | None = None) -> bytes:
    import io

    from . import report as RP

    bio = io.BytesIO()
    with pd.ExcelWriter(bio, engine="xlsxwriter") as xw:
        wb = xw.book
        hdr = wb.add_format({"bold": True, "font_color": "white", "bg_color": "#C2410C", "border": 1, "text_wrap": True, "valign": "vcenter"})
        title = wb.add_format({"bold": True, "font_size": 14, "font_color": "#C2410C"})
        money = wb.add_format({"num_format": "#,##,##0.00;(#,##,##0.00);-", "border": 1})
        red = wb.add_format({"bg_color": "#FDE4E1", "font_color": "#B42318", "bold": True, "border": 1})
        green = wb.add_format({"bg_color": "#E6F0E2", "font_color": "#2F6B3B", "border": 1})
        devs = dev[dev["Result"] == "Deviation"] if not dev.empty else dev
        wrap = wb.add_format({"text_wrap": True, "valign": "top", "border": 1})
        sheets = ([("Detailed analysis", RP.analysis_frame(analysis))] if analysis is not None else []) + [("Deviations", devs), ("All comparisons", dev), ("GSTR-1 figures", g1.reset_index()), ("GSTR-3B figures", b3.reset_index()),
                  ("GSTR-9 figures", g9.reset_index()),
                  ("Files read", pd.DataFrame([{"File": f["name"], "Return": TYPE_LABEL.get(f.get("type"), "-"),
                                                "Period": label(f["period"]) if f.get("period") else ("FY " + f["fy"] if f.get("fy") else "-"),
                                                "GSTIN": f.get("gstin") or "-",
                                                "Filed on": (f.get("meta") or {}).get("filed_on").strftime("%d-%m-%Y") if (f.get("meta") or {}).get("filed_on") else "-",
                                                "Status": f["status"],
                                                "Figures to check / type": ", ".join(f.get("check", []) + f.get("withheld", []))} for f in files]))]
        sheets += [(n, fr) for n, fr in (extra or []) if fr is not None and len(fr)]
        for name, frame in sheets:
            frame = frame.drop(columns=["code"], errors="ignore")
            frame.to_excel(xw, sheet_name=name, index=False, startrow=2)
            ws = xw.sheets[name]
            ws.write(0, 0, f"{name} - {header}", title)
            for j, col in enumerate(frame.columns):
                ws.write(2, j, col, hdr)
                is_money = "(Rs)" in str(col) or (name.endswith("figures") and j > 0) or \
                    (name.startswith("GSTR-1 tables") and col in ("Value", "IGST", "CGST", "SGST/UTGST", "Cess")) or \
                    (name == "GSTR-1 vs GSTR-9 categories" and str(col).startswith(("GSTR-1 ", "GSTR-9 ", "Difference ")))
                width = 15 if is_money else min(70, max(10, int(frame[col].astype(str).str.len().quantile(0.9)) + 2 if len(frame) else 12))
                ws.set_column(j, j, width, money if is_money else None)
            if "Result" in frame.columns and len(frame):
                k = list(frame.columns).index("Result")
                ws.conditional_format(3, k, 2 + len(frame), k, {"type": "cell", "criteria": "==", "value": '"Deviation"', "format": red})
                ws.conditional_format(3, k, 2 + len(frame), k, {"type": "cell", "criteria": "==", "value": '"Matches"', "format": green})
            if name == "Detailed analysis":
                widths = {"#": 4, "Severity": 9, "Check": 22, "Period": 8, "Head": 11, "A": 18, "B": 18, "% of B": 8, "Risk": 8,
                          "What it means": 40, "How it links": 55, "Likely causes": 60, "How to verify": 60, "Action": 60,
                          "Interest basis": 50, "Law": 30, "Notes": 60}
                for j, col in enumerate(frame.columns):
                    if col in widths:
                        ws.set_column(j, j, widths[col], wrap)
                for r in range(len(frame)):
                    ws.set_row(3 + r, 150)
                if "Severity" in frame.columns and len(frame):
                    k = list(frame.columns).index("Severity")
                    for sv, fmt in (("High", red), ("Low", green)):
                        ws.conditional_format(3, k, 2 + len(frame), k, {"type": "cell", "criteria": "==", "value": f'"{sv}"', "format": fmt})
                    ws.conditional_format(3, k, 2 + len(frame), k, {"type": "cell", "criteria": "==", "value": '"Medium"',
                                                                   "format": wb.add_format({"bg_color": "#FCEBD2", "font_color": "#B45309", "bold": True, "border": 1})})
            ws.freeze_panes(3, 0)
    return bio.getvalue()
