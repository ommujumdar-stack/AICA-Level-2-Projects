"""
Optional, easier routes for books data and a PDF assist for GSTR-3B.

1. ERP / Tally / SAP register export -> monthly books totals.
   The user picks which column is the date and which columns hold taxable
   value, IGST, CGST, SGST, Cess. The app adds them up by month. The mapping
   is remembered per client, so next month it is upload-and-confirm.

2. GSTR-3B PDF -> Table 3.1 / 4 / 6.1 figures, read by two independent text
   engines (pdfplumber and pypdfium2). A figure is accepted only when both
   engines read the same number; the user then confirms against the page image.
"""
from __future__ import annotations

import io
import re

import pandas as pd

from . import schema as S

# ----------------------------------------------------------------------------
# 1. Register export -> monthly totals
# ----------------------------------------------------------------------------
BOOK_TARGETS = {
    "sales": [("BK_OUT_TXVAL", "Taxable value"), ("BK_OUT_IGST", "IGST"), ("BK_OUT_CGST", "CGST"),
              ("BK_OUT_SGST", "SGST/UTGST"), ("BK_OUT_CESS", "Cess"), ("BK_EXEMPT", "Exempt / nil / non-GST value")],
    "purchase": [("BK_ITC_IGST", "IGST (ITC)"), ("BK_ITC_CGST", "CGST (ITC)"), ("BK_ITC_SGST", "SGST/UTGST (ITC)"),
                 ("BK_ITC_CESS", "Cess (ITC)"), ("BK_RCM_TAX", "RCM tax payable")],
}

_GUESS = {
    "BK_OUT_TXVAL": ["taxable", "assessable", "value"],
    "BK_OUT_IGST": ["igst", "integrated"], "BK_ITC_IGST": ["igst", "integrated"],
    "BK_OUT_CGST": ["cgst", "central"], "BK_ITC_CGST": ["cgst", "central"],
    "BK_OUT_SGST": ["sgst", "utgst", "state"], "BK_ITC_SGST": ["sgst", "utgst", "state"],
    "BK_OUT_CESS": ["cess"], "BK_ITC_CESS": ["cess"],
    "BK_EXEMPT": ["exempt", "nil", "non-gst", "non gst"],
    "BK_RCM_TAX": ["rcm", "reverse"],
}


def read_any_table(data: bytes, name: str) -> dict[str, pd.DataFrame]:
    n = name.lower()
    if n.endswith(".csv"):
        return {"CSV": pd.read_csv(io.BytesIO(data))}
    xl = pd.ExcelFile(io.BytesIO(data))
    return {s: xl.parse(s) for s in xl.sheet_names}


def find_header_row(df: pd.DataFrame) -> pd.DataFrame:
    """ERP exports often have title rows above the real header. Pick the first
    row within the top 15 that has at least 3 text cells and a date-like word."""
    for i in range(min(15, len(df))):
        row = df.iloc[i].astype(str).str.lower()
        if row.str.contains("date").any() and (row != "nan").sum() >= 3:
            new = df.iloc[i + 1:].copy()
            new.columns = [str(c).strip() for c in df.iloc[i]]
            return new.reset_index(drop=True)
    return df


def guess_mapping(columns: list[str], kind: str) -> dict:
    cols_l = {c: str(c).lower() for c in columns}
    m = {"date": next((c for c, l in cols_l.items() if "date" in l), None)}
    used = set()
    for code, _ in BOOK_TARGETS[kind]:
        hit = None
        for c, l in cols_l.items():
            if c in used:
                continue
            if any(k in l for k in _GUESS[code]):
                if code == "BK_OUT_TXVAL" and any(x in l for x in ("igst", "cgst", "sgst", "cess", "total", "invoice value")):
                    continue
                hit = c
                break
        m[code] = hit
        if hit:
            used.add(hit)
    return m


def aggregate_register(df: pd.DataFrame, mapping: dict, fy: str, kind: str) -> tuple[pd.DataFrame, list[str]]:
    """Returns (monthly table with field codes as columns, issues)."""
    issues = []
    dcol = mapping.get("date")
    if not dcol or dcol not in df.columns:
        raise ValueError("Choose the date column.")
    d = pd.to_datetime(df[dcol], errors="coerce", dayfirst=True)
    bad = int(d.isna().sum())
    work = df.copy()
    work["_period"] = d.dt.strftime("%Y-%m")
    months = S.fy_months(fy)
    outside = int((~work["_period"].isin(months) & d.notna()).sum())
    if bad:
        issues.append(f"{bad} row(s) have no readable date (totals/blank rows are normal) - excluded.")
    if outside:
        issues.append(f"{outside} row(s) fall outside FY {fy} - excluded.")
    work = work[work["_period"].isin(months)]
    res = pd.DataFrame({"Period": months})
    for code, _ in BOOK_TARGETS[kind]:
        col = mapping.get(code)
        if not col:
            continue
        vals = pd.to_numeric(work[col].astype(str).str.replace(",", "").str.replace("₹", "").str.strip()
                             .replace({"": None, "nan": None, "-": None}), errors="coerce")
        nonnum = int(vals.isna().sum() - work[col].isna().sum())
        if nonnum > 0:
            issues.append(f"Column '{col}': {nonnum} non-numeric cell(s) treated as zero.")
        s = vals.fillna(0).groupby(work["_period"]).sum()
        res[code] = res["Period"].map(s).fillna(0.0).round(2)
    return res, issues


# ----------------------------------------------------------------------------
# 2. GSTR-3B PDF reader
# ----------------------------------------------------------------------------
NUM = r"-?[\d,]+\.\d{2}"
_MONTHS = {m.lower(): i for i, m in enumerate(
    ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], start=1)}

# label regex -> (field codes in order of the numbers on that line)
_3B_LINES = [
    ("31a", r"\(a\)\s*Outward taxable supplies \(other than zero rated", ["TXVAL", "IGST", "CGST", "SGST", "CESS"]),
    ("31b", r"\(b\)\s*Outward taxable supplies \(zero rated", ["TXVAL", "IGST", "CESS"]),
    ("31c", r"\(c\)\s*Other outward supplies \(Nil rated, exempted", ["TXVAL"]),
    ("31d", r"\(d\)\s*Inward supplies \(liable to reverse charge", ["TXVAL", "IGST", "CGST", "SGST", "CESS"]),
    ("31e", r"\(e\)\s*Non-GST outward supplies", ["TXVAL"]),
    ("4A1", r"\(1\)\s*Import of goods", ["IGST", "CGST", "SGST", "CESS"]),
    ("4A2", r"\(2\)\s*Import of services", ["IGST", "CGST", "SGST", "CESS"]),
    ("4A3", r"\(3\)\s*Inward supplies liable to reverse charge", ["IGST", "CGST", "SGST", "CESS"]),
    ("4A4", r"\(4\)\s*Inward supplies from ISD", ["IGST", "CGST", "SGST", "CESS"]),
    ("4A5", r"\(5\)\s*All other ITC", ["IGST", "CGST", "SGST", "CESS"]),
    ("4B1", r"\(1\)\s*As per rules? (?:38,\s*)?42\s*&\s*43", ["IGST", "CGST", "SGST", "CESS"]),
    ("4B2", r"\(2\)\s*Others", ["IGST", "CGST", "SGST", "CESS"]),
]


def _numbers_after(text: str, pattern: str, n: int) -> list[int] | None:
    m = re.search(pattern, text, flags=re.IGNORECASE)
    if not m:
        return None
    tail = text[m.end(): m.end() + 600]
    nums = re.findall(NUM, tail)
    if len(nums) < n:
        return None
    return [S.to_paise(x) for x in nums[:n]]


def _parse_meta(t: str) -> dict:
    meta = {}
    g = re.search(r"GSTIN(?:\s*of the supplier)?\s*[:\-]?\s*([0-9]{2}[A-Z0-9]{13})", t)
    if g:
        meta["gstin"] = g.group(1)
    y = re.search(r"Year\s*[:\-]?\s*(20\d{2}\s*-\s*\d{2})", t, re.I)
    if y:
        meta["fy"] = re.sub(r"\s", "", y.group(1))
    p = re.search(r"Period\s*[:\-]?\s*(January|February|March|April|May|June|July|August|September|October|November|December)", t, re.I)
    if p:
        meta["month"] = _MONTHS[p.group(1).lower()]
    return meta


def _parse_rows(t: str, rowdefs) -> dict:
    """rowdefs: [(key, label regex, [column names in printed order])].
    Each row reads only the text between its own label and the NEXT row label found on the page,
    so a row printed blank can never pick up the following row's figures. Fewer numbers than
    columns = row left unread (the user types it)."""
    hits = []
    for key, pat, cols in rowdefs:
        m = re.search(pat, t, flags=re.IGNORECASE)
        if m:
            hits.append((m.start(), m.end(), key, cols))
    hits.sort()
    lines = {}
    for i, (st_, en, key, cols) in enumerate(hits):
        stop = hits[i + 1][0] if i + 1 < len(hits) else len(t)
        nums = re.findall(NUM, t[en:min(stop, en + 800)])
        if len(nums) >= len(cols):
            lines[key] = dict(zip(cols, [S.to_paise(x) for x in nums[:len(cols)]]))
    return lines


def _parse_3b_text(text: str) -> dict:
    t = re.sub(r"[ \t]+", " ", text)
    return {"meta": _parse_meta(t), "lines": _parse_rows(t, _3B_LINES)}


# ---------------------------------------------------------------------------
# Watermark removal.
# A watermark is text that is (a) rotated, (b) transparent, (c) far larger than the
# body text, or (d) light grey. Each engine flags what it can see; pdfplumber cannot
# see transparency, pdfium can. The two flag sets are merged by character position,
# then each engine reads the numbers independently from its own cleaned text, so the
# two-engine agreement rule still holds.
# ---------------------------------------------------------------------------
_GREY_LO, _GREY_HI = 0.60, 0.97   # lightness band of a grey watermark (1.0 = white, kept: header text)
_ALPHA_MAX = 0.60                 # fill opacity below this = watermark
_SIZE_X = 2.5                     # font size above this multiple of the median = watermark


def _is_light_grey(rgb) -> bool:
    if not rgb or len(rgb) != 3:
        return False
    lo, hi = min(rgb), max(rgb)
    light = sum(rgb) / 3
    return (hi - lo) < 0.08 and _GREY_LO <= light <= _GREY_HI


def _plumber_rgb(col):
    if col is None or isinstance(col, str):
        return None
    col = tuple(float(x) for x in col) if isinstance(col, (list, tuple)) else (float(col),)
    if len(col) == 1:
        return (col[0],) * 3
    if len(col) == 3:
        return col
    if len(col) == 4:  # CMYK
        c, m, y, k = col
        return ((1 - c) * (1 - k), (1 - m) * (1 - k), (1 - y) * (1 - k))
    return None


def _median(xs):
    xs = sorted(xs)
    return xs[len(xs) // 2] if xs else 0


def _pdfium_chars(data: bytes):
    """Per page: list of dicts with char, centre, flags from pdfium's own view."""
    import ctypes

    import pypdfium2 as pdfium
    import pypdfium2.raw as P

    doc = pdfium.PdfDocument(data)
    pages = []
    for pi in range(len(doc)):
        tp = doc[pi].get_textpage()
        raw = tp.raw
        out = []
        for i in range(P.FPDFText_CountChars(raw)):
            u = P.FPDFText_GetUnicode(raw, i)
            gen = P.FPDFText_IsGenerated(raw, i) == 1
            # loose box = font box (advance width x ascent/descent), the same basis pdfplumber uses,
            # so punctuation (comma, full stop) lines up between the two engines
            rect = P.FS_RECTF()
            if P.FPDFText_GetLooseCharBox(raw, i, ctypes.byref(rect)):
                l, r, b, t = (ctypes.c_double(v) for v in (rect.left, rect.right, rect.bottom, rect.top))
            else:
                l, r, b, t = (ctypes.c_double() for _ in range(4))
                P.FPDFText_GetCharBox(raw, i, ctypes.byref(l), ctypes.byref(r), ctypes.byref(b), ctypes.byref(t))
            cr, cg, cb, ca = (ctypes.c_uint() for _ in range(4))
            okc = P.FPDFText_GetFillColor(raw, i, ctypes.byref(cr), ctypes.byref(cg), ctypes.byref(cb), ctypes.byref(ca))
            ang = P.FPDFText_GetCharAngle(raw, i)
            out.append({
                "u": chr(u) if u else "", "gen": gen, "cx": (l.value + r.value) / 2, "cy": (b.value + t.value) / 2,
                "size": P.FPDFText_GetFontSize(raw, i), "angle": ang,
                "rgb": (cr.value / 255, cg.value / 255, cb.value / 255) if okc else None, "alpha": ca.value / 255 if okc else 1.0,
            })
        pages.append(out)
    return pages


def _flag_pdfium(chars):
    body = [c["size"] for c in chars if not c["gen"] and c["u"].strip() and c["size"] > 0]
    med = _median(body) or 1
    for c in chars:
        if c["gen"] or not c["u"].strip():
            c["wm"] = False
            continue
        a = c["angle"]
        rotated = a > 0 and min(abs(a), abs(a - 6.283185307)) > 0.035  # > 2 degrees (radians; -1 = unknown)
        c["wm"] = bool(rotated or c["alpha"] < _ALPHA_MAX or c["size"] > _SIZE_X * med or _is_light_grey(c["rgb"]))
    return chars


def _flag_plumber(chars):
    body = [c["size"] for c in chars if c["text"].strip()]
    med = _median(body) or 1
    for c in chars:
        a, b, cc, d = c["matrix"][:4]
        rotated = abs(b) > 0.035 * max(abs(a), 1e-9) or abs(cc) > 0.035 * max(abs(d), 1e-9)
        c["_wm"] = bool(rotated or c["size"] > _SIZE_X * med or _is_light_grey(_plumber_rgb(c.get("non_stroking_color"))))
    return chars


def _pc(c):
    return (c["x0"] + c["x1"]) / 2, (c["y0"] + c["y1"]) / 2


def _grid(items, xy, glyph):
    """Index items by (glyph, x-bucket, y-bucket) so neighbours are found without scanning the page."""
    g = {}
    for i, it in enumerate(items):
        x, y = xy(it)
        g.setdefault((glyph(it), int(x // 2), int(y // 2)), []).append(i)
    return g


def _near_idx(grid, glyph, x, y):
    out = []
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            out.extend(grid.get((glyph, int(x // 2) + dx, int(y // 2) + dy), ()))
    return out


def _merge_flags(pchars, fchars, tol=0.6, tol_y=1.3):
    """One-to-one match of watermark characters between the engines.
    pdfium-flagged -> pdfplumber, and pdfplumber-flagged -> pdfium. A character is matched only
    once, to the nearest candidate with the same glyph, and only if it is unambiguous: when two
    candidates are equally close (stacked identical digits) one of them is the body copy, so the
    pair is matched by drawing order instead (the k-th watermark copy to the k-th candidate from
    the watermark's own side of the stream). Neighbours are looked up in a position index."""
    used_p, used_f = set(), set()
    pgrid = _grid(pchars, _pc, lambda c: c["text"])
    body_before = []
    seen_body = False
    for f in fchars:
        body_before.append(seen_body)
        if not f["wm"]:
            seen_body = True
    for fi, f in enumerate(fchars):
        if not f["wm"] or not f["u"].strip():
            continue
        cands = []
        for pi in _near_idx(pgrid, f["u"], f["cx"], f["cy"]):
            if pi in used_p:
                continue
            x, y = _pc(pchars[pi])
            if abs(x - f["cx"]) <= tol and abs(y - f["cy"]) <= tol_y:
                cands.append((abs(x - f["cx"]) + abs(y - f["cy"]), pi))
        if not cands:
            continue
        cands.sort()
        if any(pchars[pi]["_wm"] for _, pi in cands):
            pi = next(pi for _, pi in cands if pchars[pi]["_wm"])
        elif len(cands) > 1 and abs(cands[0][0] - cands[1][0]) < 0.05:
            pi = max(p for _, p in cands) if body_before[fi] else min(p for _, p in cands)
        else:
            pi = cands[0][1]
        pchars[pi]["_wm"] = True
        used_p.add(pi)
        used_f.add(fi)
    fgrid = _grid(fchars, lambda f: (f["cx"], f["cy"]), lambda f: f["u"])
    for pi, c in enumerate(pchars):
        if not c["_wm"] or pi in used_p:
            continue
        x, y = _pc(c)
        cands = sorted((abs(fchars[fi]["cx"] - x) + abs(fchars[fi]["cy"] - y), fi) for fi in _near_idx(fgrid, c["text"], x, y)
                       if fi not in used_f and not fchars[fi]["wm"] and abs(fchars[fi]["cx"] - x) <= tol and abs(fchars[fi]["cy"] - y) <= tol_y)
        if cands and (len(cands) == 1 or abs(cands[0][0] - cands[1][0]) >= 0.05):
            fchars[cands[0][1]]["wm"] = True
            used_f.add(cands[0][1])
    # a space drawn between two watermark characters (content-stream order) belongs to the watermark
    for seq, key, txt in ((pchars, "_wm", "text"), (fchars, "wm", "u")):
        n = len(seq)
        prev_wm, nxt_wm = [False] * n, [False] * n
        last = None
        for i in range(n):
            prev_wm[i] = bool(last is not None and seq[last][key])
            if seq[i][txt].strip():
                last = i
        last = None
        for i in range(n - 1, -1, -1):
            nxt_wm[i] = bool(last is not None and seq[last][key])
            if seq[i][txt].strip():
                last = i
        for i in range(1, n - 1):
            if not seq[i][txt].strip() and not seq[i][key] and prev_wm[i] and nxt_wm[i]:
                seq[i][key] = True


_CACHE: dict = {}


def _cached(kind, data, fn):
    """Small per-process cache: the watermark analysis of a PDF is done once, not once per reader."""
    import hashlib

    key = (kind, hashlib.sha1(data).hexdigest())
    if key not in _CACHE:
        if len(_CACHE) > 64:
            _CACHE.clear()
        _CACHE[key] = fn()
    return _CACHE[key]


def pdfium_flags(data):
    return _cached("pdfium", data, lambda: [_flag_pdfium(p) for p in _pdfium_chars(data)])


def extract_clean_text(data: bytes) -> tuple[str, str, dict]:
    """Returns (pdfplumber text, pdfium text, watermark info) with watermark characters removed. Cached per PDF."""
    return _cached("clean", data, lambda: _extract_clean_text(data))


def _extract_clean_text(data: bytes) -> tuple[str, str, dict]:
    import copy
    import pdfplumber

    pdfium_pages = copy.deepcopy(pdfium_flags(data))
    t_plumber, t_pdfium = [], []
    removed_text, removed = [], 0
    with pdfplumber.open(io.BytesIO(data)) as pdf:
        for pi, page in enumerate(pdf.pages):
            pchars = _flag_plumber(list(page.chars))
            fchars = pdfium_pages[pi] if pi < len(pdfium_pages) else []
            ph = float(page.height)
            # Merge flags both ways by position (both engines use PDF bottom-left coordinates).
            # Strictly one-to-one: each flagged character marks only the single nearest unflagged
            # character with the same glyph on the other side, so a watermark digit lying on top of
            # an identical body digit can never take the body digit with it.
            _merge_flags(pchars, fchars)
            wm_ids = {id(c) for c in pchars if c["_wm"]}
            removed += len(wm_ids)
            removed_text.append("".join(c["text"] for c in pchars if c["_wm"]))
            clean = page.filter(lambda o: not (o.get("object_type") == "char" and id(o) in wm_ids))
            t_plumber.append(clean.extract_text() or "")
            t_pdfium.append("".join(f["u"] for f in fchars if not f["wm"]))
            _ = ph
    sample = re.sub(r"\s+", " ", " ".join(removed_text)).strip()
    info = {"chars_removed": removed, "sample": sample[:120]}
    return "\n".join(t_plumber), "\n".join(t_pdfium), info


def _text_pdfplumber(data: bytes) -> str:
    import pdfplumber

    with pdfplumber.open(io.BytesIO(data)) as pdf:
        return "\n".join((pg.extract_text() or "") for pg in pdf.pages)


def render_pages(data: bytes, scale: float = 1.4):
    import pypdfium2 as pdfium

    doc = pdfium.PdfDocument(data)
    return [doc[i].render(scale=scale).to_pil() for i in range(len(doc))]


def _to_fields(lines: dict) -> dict[str, int]:
    """Map parsed lines to the app's GSTR-3B field codes."""
    f: dict[str, int] = {}

    def g(k, c):
        return (lines.get(k) or {}).get(c, 0) or 0

    if "31a" in lines or "31b" in lines:
        f["G3B_OUT_TXVAL"] = g("31a", "TXVAL") + g("31b", "TXVAL")
        f["G3B_OUT_IGST"] = g("31a", "IGST") + g("31b", "IGST")
        f["G3B_OUT_CGST"] = g("31a", "CGST")
        f["G3B_OUT_SGST"] = g("31a", "SGST")
        f["G3B_OUT_CESS"] = g("31a", "CESS") + g("31b", "CESS")
    if "31c" in lines or "31e" in lines:
        f["G3B_EXEMPT"] = g("31c", "TXVAL") + g("31e", "TXVAL")
    if "31d" in lines:
        for h in S.HEADS:
            f[f"G3B_RCM_{h}"] = g("31d", h)
    if any(k in lines for k in ("4A1", "4A2", "4A3", "4A4", "4A5")):
        for h in S.HEADS:
            f[f"G3B_ITC_AVL_{h}"] = sum(g(k, h) for k in ("4A1", "4A2", "4A3", "4A4", "4A5"))
    if "4B1" in lines or "4B2" in lines:
        for h in S.HEADS:
            f[f"G3B_ITC_REV_{h}"] = g("4B1", h) + g("4B2", h)
    return f


def _cs_guard(agreed, disagree, prefixes):
    """Intra-state tax splits equally: if CGST and SGST on the same line differ, withhold both."""
    for pre in prefixes:
        c_, s_ = f"{pre}_CGST", f"{pre}_SGST"
        if c_ in agreed and s_ in agreed and abs(agreed[c_] - agreed[s_]) > 100:
            for k in (c_, s_):
                agreed.pop(k)
                disagree.append(k)


def _rate_guard(agreed, disagree, checks, tv_code, pre, where):
    tv = agreed.get(tv_code)
    tax = sum(agreed.get(f"{pre}_{h}", 0) for h in ("IGST", "CGST", "SGST"))
    if tv and tax and not (0.1 <= tax / tv * 100 <= 40.5):
        checks.append(f"{where}: effective rate is {tax / tv * 100:.2f}% - outside 0.1%-40%. A digit may have been added or lost; "
                      "compare with the page image.")
        for k in [tv_code] + [f"{pre}_{h}" for h in ("IGST", "CGST", "SGST")]:
            if k in agreed:
                agreed.pop(k)
                disagree.append(k)


def _read_pdf(data: bytes, parse, to_fields, expected: list[str], form: str, guards) -> dict:
    """Shared reader: text layer check, watermark removal, two independent engines, field-by-field
    agreement, then form-specific arithmetic guards that withhold any figure that does not add up."""
    try:
        t1 = _text_pdfplumber(data)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "message": f"Could not open the PDF ({e})."}
    if len(t1.strip()) < 50:
        return {"ok": False, "message": "This PDF has no text layer (looks scanned). Download the PDF again from the portal, or type the figures in the grid."}
    wm = {"chars_removed": 0, "sample": ""}
    try:
        t1, t2, wm = extract_clean_text(data)
    except Exception:  # noqa: BLE001 - fall back to plain text; the agreement rule still protects the values
        t2 = ""
    a, b = parse(t1), parse(t2)
    fa, fb = to_fields(a["lines"]), to_fields(b["lines"])
    agreed, disagree = {}, []
    for code, v in fa.items():
        if code in fb and fb[code] == v:
            agreed[code] = v
        else:
            disagree.append(code)
    checks: list[str] = []
    guards(agreed, disagree, checks)
    missing = [c for c in expected if c not in fa]
    meta = a["meta"] or b["meta"]
    msg = "Both engines agree on every figure read." if not disagree else f"{len(disagree)} figure(s) withheld - type them from the page image."
    if wm["chars_removed"]:
        msg = f"Watermark detected and ignored ({wm['chars_removed']} characters, e.g. \"{wm['sample'][:60]}\"). " + msg
    if not agreed:
        return {"ok": False, "meta": meta, "fields": {}, "disagree": disagree, "missing": missing, "watermark": wm, "checks": checks,
                "message": f"No {form} tables recognised in this PDF. The reader is calibrated to the portal's {form} layout; "
                           "type the figures in the grid, and send a sample PDF so the reader can be calibrated to it."}
    return {"ok": True, "meta": meta, "fields": agreed, "disagree": disagree, "missing": missing, "message": msg,
            "watermark": wm, "checks": checks}


def read_3b_pdf(data: bytes) -> dict:
    """GSTR-3B (monthly). Returns {'ok', 'meta', 'fields' {code: paise}, 'disagree', 'missing', 'message', 'watermark', 'checks'}."""
    def guards(agreed, disagree, checks):
        _cs_guard(agreed, disagree, ("G3B_OUT", "G3B_RCM", "G3B_ITC_AVL", "G3B_ITC_REV"))
        _rate_guard(agreed, disagree, checks, "G3B_OUT_TXVAL", "G3B_OUT", "Table 3.1")
    expected = [f.code for f in S.GSTR3B_FIELDS if not f.code.startswith("G3B_PAID")]
    return _read_pdf(data, _parse_3b_text, _to_fields, expected, "GSTR-3B", guards)


# ----------------------------------------------------------------------------
# 3. GSTR-1 PDF reader (monthly summary)
# GSTR-1 tables print Integrated, Central, State/UT, Cess - IGST first, like GSTR-3B.
# Read from the summary line 'Total Liability (Outward supplies other than Reverse charge)',
# which already nets amendments, credit and debit notes. 'Value' on that line is taken as the
# taxable value - the review screen asks the user to confirm it.
# ----------------------------------------------------------------------------
_G1_LINES = [
    ("TOT", r"Total\s+Liability\s*\(?\s*Outward\s+supplies\s+other\s+than\s+Reverse\s+charge\s*\)?",
     ["TXVAL", "IGST", "CGST", "SGST", "CESS"]),
]


def _parse_g1_text(text: str) -> dict:
    t = re.sub(r"[ \t]+", " ", text)
    return {"meta": _parse_meta(t), "lines": _parse_rows(t, _G1_LINES)}


def _g1_fields(lines: dict) -> dict:
    if "TOT" not in lines:
        return {}
    return {f"G1_{k}": v for k, v in lines["TOT"].items()}


def read_g1_pdf(data: bytes) -> dict:
    def guards(agreed, disagree, checks):
        _cs_guard(agreed, disagree, ("G1",))
        _rate_guard(agreed, disagree, checks, "G1_TXVAL", "G1", "GSTR-1 total liability")
    return _read_pdf(data, _parse_g1_text, _g1_fields, [f.code for f in S.GSTR1_FIELDS], "GSTR-1 summary", guards)


# ----------------------------------------------------------------------------
# 4. GSTR-9 PDF reader (system computed or filed)
# Column order per the notified FORM GSTR-9 - NOT the GSTR-3B order:
#   Tables 4, 5, 10, 11: Taxable Value, Central Tax, State/UT Tax, Integrated Tax, Cess
#   Tables 6, 7, 8:      Central Tax, State/UT Tax, Integrated Tax, Cess
#   Table 9 rows (Integrated/Central/State-UT/Cess): Tax payable, Paid through cash,
#                        Paid through ITC - Central, State/UT, Integrated, Cess
# ----------------------------------------------------------------------------
_V_CSIC = ["TXVAL", "CGST", "SGST", "IGST", "CESS"]
_CSIC = ["CGST", "SGST", "IGST", "CESS"]
_G9_LINES = [
    ("4A", r"Supplies\s+made\s+to\s+un-?\s*registered\s+persons\s*\(\s*B2C\s*\)", _V_CSIC),
    ("4B", r"Supplies\s+made\s+to\s+registered\s+persons\s*\(\s*B2B\s*\)", _V_CSIC),
    ("4C", r"Zero\s+rated\s+supply\s*\(\s*Export\s*\)\s+on\s+payment\s+of\s+tax(?:\s*\(\s*except\s+supplies\s+to\s+SEZs\s*\))?", _V_CSIC),
    ("4D", r"Supply\s+to\s+SEZs\s+on\s+payment\s+of\s+tax", _V_CSIC),
    ("4E", r"(?<![A-Za-z])Deemed\s+Exports", _V_CSIC),
    ("4F", r"Advances\s+on\s+which\s+tax\s+has\s+been\s+paid\s+but\s+invoice\s+has\s+not\s+been\s+issued"
           r"(?:\s*\(\s*not\s+covered\s+under\s*\(\s*A\s*\)\s*to\s*\(\s*E\s*\)\s*above\s*\))?", _V_CSIC),
    ("4G", r"Inward\s+supplies\s+on\s+which\s+tax\s+is\s+to\s+be\s+paid\s+on\s+reverse\s+charge\s+basis", _V_CSIC),
    ("4H", r"Sub-?\s*total\s*\(\s*A\s+to\s+G\s+above\s*\)", None),
    ("4I", r"Credit\s+Notes\s+issued\s+in\s+respect\s+of\s+transactions\s+specified\s+in\s*\(\s*B\s*\)\s*to\s*\(\s*E\s*\)\s*above\s*\(\s*-\s*\)", _V_CSIC),
    ("4J", r"Debit\s+Notes\s+issued\s+in\s+respect\s+of\s+transactions\s+specified\s+in\s*\(\s*B\s*\)\s*to\s*\(\s*E\s*\)\s*above\s*\(\s*\+\s*\)", _V_CSIC),
    ("4K", r"Supplies\s*/\s*tax\s+declared\s+through\s+Amendments\s*\(\s*\+\s*\)(?!\s*\(\s*net)", _V_CSIC),
    ("4L", r"Supplies\s*/\s*tax\s+reduced\s+through\s+Amendments\s*\(\s*-\s*\)(?!\s*\(\s*net)", _V_CSIC),
    ("4M", r"Sub-?\s*total\s*\(\s*I\s+to\s+L\s+above\s*\)", None),
    ("5A", r"Zero\s+rated\s+supply\s*\(\s*Export\s*\)\s+without\s+payment\s+of\s+tax", ["TXVAL"]),
    ("5B", r"Supply\s+to\s+SEZs\s+without\s+payment\s+of\s+tax", ["TXVAL"]),
    ("5C", r"Supplies\s+on\s+which\s+tax\s+is\s+to\s+be\s+paid\s+by\s+the\s+recipient\s+on\s+reverse\s+charge\s+basis", ["TXVAL"]),
    ("5D", r"\bExempted\b", ["TXVAL"]),
    ("5E", r"\bNil\s+Rated\b", ["TXVAL"]),
    ("5F", r"Non-GST\s+supply(?:\s*\(\s*includes\s+'?no\s+supply'?\s*\))?", ["TXVAL"]),
    ("5G", r"Sub-?\s*total\s*\(\s*A\s+to\s+F\s+above\s*\)", None),
    ("5H", r"Credit\s+Notes\s+issued\s+in\s+respect\s+of\s+transactions\s+specified\s+in\s*\(?\s*A\s*\)?\s*to\s*\(?\s*F\s*\)?\s*above\s*\(\s*-\s*\)", ["TXVAL"]),
    ("5I", r"Debit\s+Notes\s+issued\s+in\s+respect\s+of\s+transactions\s+specified\s+in\s*\(?\s*A\s*\)?\s*to\s*\(?\s*F\s*\)?\s*above\s*\(\s*\+\s*\)", ["TXVAL"]),
    ("5J", r"(?<!/\s)(?<!tax\s)Supplies\s+declared\s+through\s+Amendments\s*\(\s*\+\s*\)", ["TXVAL"]),
    ("5K", r"(?<!/\s)(?<!tax\s)Supplies\s+reduced\s+through\s+Amendments\s*\(\s*-\s*\)", ["TXVAL"]),
    ("5L", r"Sub-?\s*Total\s*\(\s*H\s+to\s+K\s+above\s*\)", None),
    ("5M", r"Turnover\s+on\s+which\s+tax\s+is\s+not\s+to\s+be\s+paid", None),
    ("4N", r"Supplies\s+and\s+advances\s+on\s+which\s+tax\s+is\s+to\s+be\s+paid\s*\(\s*H\s*\+\s*M\s*\)\s*(?:above)?", _V_CSIC),
    ("5N", r"Total\s+Turnover\s*\(\s*including\s+advances\s*\)\s*(?:\(\s*4N\s*\+\s*5M\s*-\s*4G\s*(?:above)?\s*\))?", _V_CSIC),
    ("6A", r"Total\s+amount\s+of\s+input\s+tax\s+credit\s+availed\s+through\s+FORM\s+GSTR-?3B\s*(?:\([^)]*\))?", _CSIC),
    ("6B", r"Inward\s+supplies\s*\(\s*other\s+than\s+imports\s+and\s+inward\s+supplies\s+liable\s+to\s+reverse\s+charge", None),
    ("7I", r"Total\s+ITC\s+Reversed\s*\(\s*Sum\s+of\s+[A-Z\d]+\s+to\s+[A-Z\d]+\s*(?:above)?\s*\)", _CSIC),
    ("8A", r"ITC\s+as\s+per\s+GSTR-?2[AB]\s*(?:\([^)]*\))?", _CSIC),
    ("8B", r"ITC\s+as\s+per\s+sum\s+total\s+(?:of\s+)?6\s*\(?B\)?(?:\s+and\s+6\s*\(?H\)?)?\s*(?:above)?", _CSIC),
    # 8C's label carries years (e.g. 'received during 2025-26 but availed during April 2026 to ...'); years have
    # no decimals, so they are never read as figures - the row reads up to the 8D label.
    ("8C", r"ITC\s+on\s+inward\s+supplies\s*\(\s*other\s+than\s+imports", _CSIC),
    ("8D", r"Difference\s*\[\s*A\s*-\s*\(\s*B\s*\+\s*C\s*\)\s*\]", _CSIC),
    ("8E", r"ITC\s+available\s+but\s+not\s+availed", None),
    ("9H", r"Details\s+of\s+tax\s+paid\s+as\s+declared\s+in\s+returns", None),
    ("10", r"Supplies\s*/\s*tax\s+declared\s+through\s+Amendments\s*\(\s*\+\s*\)\s*\(\s*net\s+of\s+debit\s+notes\s*\)", _V_CSIC),
    ("11", r"Supplies\s*/\s*tax\s+reduced\s+through\s+Amendments\s*\(\s*-\s*\)\s*\(\s*net\s+of\s+credit\s+notes\s*\)", _V_CSIC),
    ("12", r"Reversal\s+of\s+ITC\s+availed\s+during\s+previous\s+financial\s+year", None),
]
_G9_TAB9 = [("IGST", r"Integrated\s+Tax"), ("CGST", r"Central\s+Tax"), ("SGST", r"State\s*/\s*UT\s+Tax"), ("CESS", r"Cess")]


def _parse_g9_text(text: str) -> dict:
    t = re.sub(r"[ \t]+", " ", text)
    # rows with cols=None are boundaries only (they stop the row above from reading into them)
    lines = {k: v for k, v in _parse_rows(t, [(k, p, c or []) for k, p, c in _G9_LINES]).items()
             if dict(_G9_COLS).get(k)}
    # Table 9: between its heading and Table 10, one line per tax head with exactly 6 figures
    pat = {k: p for k, p, _ in _G9_LINES}
    m9 = re.search(pat["9H"], t, re.I)
    m10 = re.search(pat["10"], t, re.I)
    if m9:
        block = t[m9.end(): m10.start() if m10 and m10.start() > m9.end() else m9.end() + 3000]
        for head, pat in _G9_TAB9:
            for mm in re.finditer(rf"(?:^|\n)\s*{pat}\b([^\n]*)", block, re.I):
                nums = re.findall(NUM, mm.group(1))
                if len(nums) == 6:
                    v = [S.to_paise(x) for x in nums]
                    lines[f"9_{head}"] = {"PAY": v[0], "PAID": sum(v[1:])}
                    break
    return {"meta": _parse_meta(t), "lines": lines}


_G9_COLS = [(k, c) for k, _, c in _G9_LINES]


def _g9_fields_for(ver: str):
    def conv(lines: dict) -> dict:
        f = {}
        for row in ("4A", "4B", "4C", "4D", "4E", "4F", "4G", "4I", "4J", "4K", "4L", "5A", "5B", "5C", "5D", "5E", "5F", "5H", "5I",
                    "5J", "5K", "4N", "5N", "6A", "7I", "8A", "8B", "8C", "8D", "10", "11"):
            for col, v in (lines.get(row) or {}).items():
                f[f"G9{ver}_{row}_{col}"] = v
        for h in S.HEADS:
            r9 = lines.get(f"9_{h}")
            if r9:
                f[f"G9{ver}_9P_{h}"] = r9["PAY"]
                f[f"G9{ver}_9D_{h}"] = r9["PAID"]
        return f
    return conv


def read_g9_pdf(data: bytes, version: str = "FILED") -> dict:
    """version 'SYS' (system computed) or 'FILED'."""
    ver = version

    def guards(agreed, disagree, checks):
        # Table 8: 8D must equal 8A - (8B + 8C), head by head; otherwise withhold all four.
        for h in S.HEADS:
            k = {r: f"G9{ver}_{r}_{h}" for r in ("8A", "8B", "8C", "8D")}
            if all(k[r] in agreed for r in ("8A", "8B", "8D")):
                exp = agreed[k["8A"]] - agreed[k["8B"]] - agreed.get(k["8C"], 0)
                if abs(exp - agreed[k["8D"]]) > 100:
                    checks.append(f"Table 8 {S.HEAD_LABEL[h]}: 8D read as {S.fmt_inr(agreed[k['8D']])} but 8A - (8B + 8C) = "
                                  f"{S.fmt_inr(exp)}. Table 8 figures for this head are withheld - type them from the page image.")
                    for r in k.values():
                        if r in agreed:
                            agreed.pop(r)
                            disagree.append(r)
        # Table 5N turnover cannot be below Table 4N taxable value
        a4, a5 = agreed.get(f"G9{ver}_4N_TXVAL"), agreed.get(f"G9{ver}_5N_TXVAL")
        if a4 is not None and a5 is not None and a5 < a4:
            checks.append("Table 5N turnover is lower than Table 4N - the two rows may have been read the wrong way round. Both withheld.")
            for r in (f"G9{ver}_4N_TXVAL", f"G9{ver}_5N_TXVAL"):
                agreed.pop(r)
                disagree.append(r)
        _cs_guard(agreed, disagree, [f"G9{ver}_{r}" for r in ("4N", "6A", "8A", "8B", "8D")])
        _rate_guard(agreed, disagree, checks, f"G9{ver}_4N_TXVAL", f"G9{ver}_4N", "Table 4N")

    expected = [f.code for f in S.gstr9_fields(ver)]
    return _read_pdf(data, _parse_g9_text, _g9_fields_for(ver), expected, "GSTR-9", guards)
